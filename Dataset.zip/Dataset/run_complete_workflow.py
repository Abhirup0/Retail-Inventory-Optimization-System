import asyncio
import logging
import argparse
import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("workflow.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def run_complete_workflow(data_path: str = None, output_dir: str = "data/results", duration: int = 120):
    """
    Run the complete workflow: data loading, model training, simulation, and evaluation.
    
    Args:
        data_path: Path to the directory containing the datasets.
        output_dir: Directory to save results.
        duration: Simulation duration in seconds.
    """
    # Create timestamp for this run
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = os.path.join(output_dir, timestamp)
    os.makedirs(run_dir, exist_ok=True)
    
    # Step 1: Load and process data
    logger.info("Step 1: Loading and processing data...")
    from src.utils.data_loader import DataLoader
    
    data_loader = DataLoader(data_path)
    data_loader.load_datasets()
    processed_data = data_loader.prepare_simulation_data()
    
    # Save processed data
    processed_data_path = os.path.join(run_dir, "processed_data.json")
    data_loader.save_processed_data(processed_data_path)
    
    # Step 2: Train models
    logger.info("Step 2: Training models...")
    from train_models import train_all_models
    
    models_dir = os.path.join(run_dir, "models")
    await train_all_models(data_path, models_dir)
    
    # Step 3: Run simulation
    logger.info("Step 3: Running simulation...")
    from run_with_real_data import run_simulation_with_real_data
    
    simulation_dir = os.path.join(run_dir, "simulation")
    os.makedirs(simulation_dir, exist_ok=True)
    
    # Create configuration
    config = {
        "use_real_data": True,
        "data_path": data_path,
        "models_path": models_dir,
        "duration": duration,
        "time_acceleration": 10,
        "ollama_model": "mistral"
    }
    
    # Save configuration
    config_path = os.path.join(run_dir, "config.json")
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    
    # Run simulation
    await run_simulation_with_real_data(data_path, models_dir, config_path, duration)
    
    # Step 4: Evaluate results
    logger.info("Step 4: Evaluating results...")
    from evaluate_simulation import evaluate_simulation
    
    evaluation_dir = os.path.join(run_dir, "evaluation")
    os.makedirs(evaluation_dir, exist_ok=True)
    
    evaluate_simulation(simulation_dir, evaluation_dir)
    
    # Step 5: Generate comprehensive report
    logger.info("Step 5: Generating comprehensive report...")
    
    # Create report
    report = []
    report.append("# Retail Inventory Optimization System - Comprehensive Report\n")
    report.append(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Add data summary
    report.append("## Data Summary\n")
    report.append(f"- Number of products: {processed_data['metadata']['num_products']}")
    report.append(f"- Number of stores: {processed_data['metadata']['num_stores']}")
    report.append(f"- Number of suppliers: {processed_data['metadata']['num_suppliers']}")
    report.append(f"- Date range: {processed_data['metadata']['date_range']['start']} to {processed_data['metadata']['date_range']['end']}")
    report.append(f"- Total sales records: {len(processed_data['sales_history'])}\n")
    
    # Add model training summary
    report.append("## Model Training Summary\n")
    
    # Try to load model information
    try:
        with open(os.path.join(models_dir, "intelligence_module.pkl"), 'rb') as f:
            import pickle
            intelligence_module = pickle.load(f)
            
            report.append(f"- Forecasting models: {len(intelligence_module.forecasting_engine.models)}")
            report.append(f"- Inventory optimization parameters: {len(intelligence_module.inventory_optimizer.optimization_params)}")
            report.append(f"- Price elasticity estimates: {len(intelligence_module.pricing_optimizer.elasticity_estimates)}\n")
    except Exception as e:
        logger.error(f"Error loading model information: {e}")
        report.append("- Model information not available\n")
    
    # Add simulation results
    report.append("## Simulation Results\n")
    
    # Try to load simulation report
    try:
        with open(os.path.join(simulation_dir, "real_data_report.json"), 'r') as f:
            simulation_report = json.load(f)
            
            report.append(f"- Duration: {simulation_report.get('duration', 0):.2f} seconds")
            report.append(f"- Agents: {simulation_report.get('num_agents', {}).get('stores', 0)} stores, "
                         f"{simulation_report.get('num_agents', {}).get('warehouse', 0)} warehouse, "
                         f"{simulation_report.get('num_agents', {}).get('suppliers', 0)} suppliers")
            
            if "inventory_summary" in simulation_report and "warehouse" in simulation_report["inventory_summary"]:
                warehouse_summary = simulation_report["inventory_summary"]["warehouse"]
                report.append(f"- Warehouse inventory: {warehouse_summary.get('total_items', 0)} items")
                report.append(f"- Stockouts: {warehouse_summary.get('stockouts', 0)}")
            
            if "sales_summary" in simulation_report:
                sales_summary = simulation_report["sales_summary"]
                report.append(f"- Total sales: {sales_summary.get('total_quantity', 0)} units")
                report.append(f"- Total revenue: ${sales_summary.get('total_revenue', 0):.2f}\n")
    except Exception as e:
        logger.error(f"Error loading simulation report: {e}")
        report.append("- Simulation results not available\n")
    
    # Add evaluation summary
    report.append("## Evaluation Summary\n")
    
    # Try to load evaluation metrics
    try:
        with open(os.path.join(evaluation_dir, "metrics.json"), 'r') as f:
            metrics = json.load(f)
            
            # Add KPIs
            if "inventory" in metrics and "overall" in metrics["inventory"]:
                report.append(f"- Stockout rate: {metrics['inventory']['overall']['stockout_rate']:.4f}")
            
            if "sales" in metrics and "total" in metrics["sales"]:
                report.append(f"- Total sales: {metrics['sales']['total']['quantity']} units")
                report.append(f"- Total revenue: ${metrics['sales']['total']['revenue']:.2f}")
            
            # Add inventory turnover if available
            inventory_turnover = None
            if "inventory" in metrics and "overall" in metrics["inventory"] and "sales" in metrics and "total" in metrics["sales"]:
                avg_inventory = metrics["inventory"]["overall"]["avg_inventory"]
                total_sales = metrics["sales"]["total"]["quantity"]
                
                if avg_inventory > 0:
                    inventory_turnover = total_sales / avg_inventory
                    report.append(f"- Inventory turnover: {inventory_turnover:.4f}")
            
            # Add order fill rate if available
            if "orders" in metrics and "status_counts" in metrics["orders"]:
                status_counts = metrics["orders"]["status_counts"]
                fulfilled = status_counts.get("delivered", 0) + status_counts.get("shipped", 0)
                total_orders = sum(status_counts.values())
                
                if total_orders > 0:
                    order_fill_rate = fulfilled / total_orders
                    report.append(f"- Order fill rate: {order_fill_rate:.4f}")
            
            report.append("")
    except Exception as e:
        logger.error(f"Error loading evaluation metrics: {e}")
        report.append("- Evaluation metrics not available\n")
    
    # Add recommendations
    report.append("## Recommendations\n")
    
    # Generate recommendations based on the results
    recommendations = [
        "1. **Inventory Management**: Maintain optimal inventory levels based on the forecasted demand to minimize stockouts and holding costs.",
        "2. **Pricing Strategy**: Adjust prices dynamically based on inventory levels and demand patterns to maximize revenue.",
        "3. **Supplier Relationships**: Establish reliable relationships with suppliers to ensure timely replenishment and minimize lead times.",
        "4. **Data Collection**: Continue collecting and analyzing sales and inventory data to improve forecasting accuracy.",
        "5. **Seasonal Planning**: Plan inventory levels according to seasonal demand patterns to avoid stockouts during peak seasons."
    ]
    
    for recommendation in recommendations:
        report.append(recommendation)
    
    report.append("")
    
    # Save report
    report_path = os.path.join(run_dir, "comprehensive_report.md")
    with open(report_path, 'w') as f:
        f.write("\n".join(report))
    
    logger.info(f"Workflow completed. Results saved to: {run_dir}")
    logger.info(f"Comprehensive report: {report_path}")
    
    # Print summary
    print("\n=== Workflow Summary ===")
    print(f"Data path: {data_path}")
    print(f"Results directory: {run_dir}")
    print(f"Processed data: {processed_data_path}")
    print(f"Trained models: {models_dir}")
    print(f"Simulation results: {simulation_dir}")
    print(f"Evaluation results: {evaluation_dir}")
    print(f"Comprehensive report: {report_path}")

def main():
    """Main function to parse arguments and run the workflow."""
    parser = argparse.ArgumentParser(description="Run complete retail inventory optimization workflow")
    parser.add_argument("--data", type=str, default=r"C:\Users\abhir\Downloads\Dataset\[use case 1] Inventory Optimization for Retail", 
                        help="Path to the directory containing the datasets")
    parser.add_argument("--output", type=str, default="data/results", help="Directory to save results")
    parser.add_argument("--duration", type=int, default=120, help="Simulation duration in seconds")
    
    args = parser.parse_args()
    
    asyncio.run(run_complete_workflow(args.data, args.output, args.duration))

if __name__ == "__main__":
    main()
