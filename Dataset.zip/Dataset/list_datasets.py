import os
import pandas as pd

# Path to the datasets
dataset_path = r"C:\Users\abhir\Downloads\Dataset\[use case 1] Inventory Optimization for Retail"

# List all files in the directory
print("Files in the directory:")
for file in os.listdir(dataset_path):
    file_path = os.path.join(dataset_path, file)
    print(f"- {file} ({os.path.getsize(file_path)} bytes)")

# Try to read each CSV file and print basic info
print("\nDataset information:")
for file in os.listdir(dataset_path):
    if file.endswith('.csv'):
        file_path = os.path.join(dataset_path, file)
        try:
            df = pd.read_csv(file_path)
            print(f"\nFile: {file}")
            print(f"Shape: {df.shape}")
            print("Columns:")
            for col in df.columns:
                print(f"  - {col}")
            print("Sample data:")
            print(df.head(2))
        except Exception as e:
            print(f"Error reading {file}: {e}")
