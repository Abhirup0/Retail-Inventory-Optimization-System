import asyncio
import logging
import argparse
import json
import os
import sys
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.utils.data_loader import DataLoader
from src.models.intelligence_module import IntelligenceModule
from src.simulation.simulation_environment import SimulationEnvironment

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("real_data_simulation.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def run_simulation_with_real_data(data_path: str = None, 
                                       models_path: str = "data/models", 
                                       config_file: str = None,
                                       duration: int = 120):
    """
    Run simulation using real data and trained models.
    
    Args:
        data_path: Path to the directory containing the datasets.
        models_path: Path to the directory containing trained models.
        config_file: Path to simulation configuration file.
        duration: Simulation duration in seconds.
    """
    # Load configuration if provided
    config = {}
    if config_file:
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            logger.info(f"Loaded configuration from {config_file}")
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            config = {}
    
    # Set use_real_data flag
    config["use_real_data"] = True
    config["data_path"] = data_path
    config["models_path"] = models_path
    
    # Load data
    data_loader = DataLoader(data_path)
    processed_data = data_loader.prepare_simulation_data()
    
    # Update configuration with metadata from the data
    config["num_stores"] = processed_data["metadata"]["num_stores"]
    config["num_products"] = processed_data["metadata"]["num_products"]
    config["num_suppliers"] = processed_data["metadata"]["num_suppliers"]
    
    # Load trained models if available
    intelligence_module = None
    intelligence_module_path = os.path.join(models_path, "intelligence_module.pkl")
    
    if os.path.exists(intelligence_module_path):
        try:
            intelligence_module = IntelligenceModule()
            intelligence_module.load_models(intelligence_module_path)
            logger.info(f"Loaded intelligence module from {intelligence_module_path}")
        except Exception as e:
            logger.error(f"Error loading intelligence module: {e}")
            intelligence_module = IntelligenceModule()
    else:
        logger.warning(f"Intelligence module not found at {intelligence_module_path}. Using default.")
        intelligence_module = IntelligenceModule()
    
    # Create simulation environment
    simulation = SimulationEnvironment(config)
    
    # Set real data and intelligence module
    simulation.real_data = processed_data
    simulation.intelligence_module = intelligence_module
    
    # Initialize simulation
    await simulation.initialize()
    
    # Run simulation
    await simulation.run(duration)
    
    # Generate report
    report = simulation.generate_report()
    
    # Save report
    report_path = "data/simulation/real_data_report.json"
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)
    
    logger.info(f"Simulation completed. Report saved to {report_path}")
    
    # Print summary
    print("\n=== Real Data Simulation Results ===")
    print(f"Duration: {report['duration']:.2f} seconds")
    print(f"Agents: {report['num_agents']['stores']} stores, {report['num_agents']['warehouse']} warehouse, "
          f"{report['num_agents']['suppliers']} suppliers, {report['num_agents']['customers']} customers")
    
    if "inventory_summary" in report and "warehouse" in report["inventory_summary"]:
        warehouse_summary = report["inventory_summary"]["warehouse"]
        print(f"\nWarehouse Inventory:")
        print(f"  Total items: {warehouse_summary['total_items']}")
        print(f"  Products: {warehouse_summary['num_products']}")
        print(f"  Stockouts: {warehouse_summary['stockouts']}")
    
    if "sales_summary" in report and "total_quantity" in report["sales_summary"]:
        print(f"\nSales:")
        print(f"  Total quantity: {report['sales_summary']['total_quantity']}")
        print(f"  Total revenue: ${report['sales_summary']['total_revenue']:.2f}")
    
    print(f"\nDetailed report saved to {report_path}")

def main():
    """Main function to parse arguments and run simulation with real data."""
    parser = argparse.ArgumentParser(description="Run simulation with real data")
    parser.add_argument("--data", type=str, default=r"C:\Users\abhir\Downloads\Dataset\[use case 1] Inventory Optimization for Retail", 
                        help="Path to the directory containing the datasets")
    parser.add_argument("--models", type=str, default="data/models", 
                        help="Path to the directory containing trained models")
    parser.add_argument("--config", type=str, help="Path to simulation configuration file")
    parser.add_argument("--duration", type=int, default=120, help="Simulation duration in seconds")
    
    args = parser.parse_args()
    
    asyncio.run(run_simulation_with_real_data(args.data, args.models, args.config, args.duration))

if __name__ == "__main__":
    main()
