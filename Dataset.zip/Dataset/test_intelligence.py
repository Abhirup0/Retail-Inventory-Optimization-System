import sys
import os
import asyncio
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.models.intelligence_module import IntelligenceModule

async def generate_sample_data():
    """Generate sample sales data for testing."""
    # Create sample sales data
    num_samples = 100
    start_date = datetime.now() - timedelta(days=100)
    
    # Generate dates
    dates = [start_date + timedelta(days=i) for i in range(num_samples)]
    
    # Generate product IDs
    product_ids = [1, 2, 3]
    
    # Generate store IDs
    store_ids = [1, 2]
    
    # Generate customer IDs
    customer_ids = list(range(1, 11))
    
    # Create sample data
    data = []
    
    for _ in range(num_samples * 3):  # Multiple samples per day
        date = np.random.choice(dates)
        product_id = np.random.choice(product_ids)
        store_id = np.random.choice(store_ids)
        customer_id = np.random.choice(customer_ids)
        
        # Base quantity and price
        if product_id == 1:
            base_quantity = 10
            base_price = 50.0
        elif product_id == 2:
            base_quantity = 5
            base_price = 100.0
        else:
            base_quantity = 20
            base_price = 25.0
        
        # Add seasonality
        month = date.month
        if month in [11, 12, 1]:  # Winter
            if product_id == 1:
                seasonal_factor = 1.5  # Product 1 sells better in winter
            else:
                seasonal_factor = 0.8
        elif month in [6, 7, 8]:  # Summer
            if product_id == 2:
                seasonal_factor = 1.3  # Product 2 sells better in summer
            else:
                seasonal_factor = 0.9
        else:
            seasonal_factor = 1.0
        
        # Add price elasticity
        price_factor = np.random.uniform(0.8, 1.2)
        price = base_price * price_factor
        
        # Calculate quantity with price elasticity
        if product_id == 1:
            elasticity = -1.5  # More elastic
        elif product_id == 2:
            elasticity = -0.8  # Less elastic
        else:
            elasticity = -1.2
        
        quantity_factor = (price_factor ** elasticity)
        quantity = max(1, int(base_quantity * seasonal_factor * quantity_factor * np.random.uniform(0.8, 1.2)))
        
        # Add to data
        data.append({
            'sale_id': len(data) + 1,
            'date': date,
            'product_id': product_id,
            'store_id': store_id,
            'customer_id': customer_id,
            'quantity': quantity,
            'price': price,
            'category': 'Electronics' if product_id == 1 else 'Home Goods' if product_id == 2 else 'Clothing'
        })
    
    # Convert to DataFrame
    df = pd.DataFrame(data)
    
    return df

async def test_forecasting():
    """Test the forecasting functionality."""
    print("\n=== Testing Forecasting ===")
    
    # Create intelligence module
    intelligence_module = IntelligenceModule(ollama_model="mistral")
    
    # Generate sample data
    sales_data = await generate_sample_data()
    
    # Test forecasting for a product
    product_id = 1
    forecast_result = await intelligence_module.forecast_demand(
        product_id=product_id,
        sales_data=sales_data,
        forecast_days=14
    )
    
    # Print results
    print(f"Forecast for Product {product_id}:")
    print(f"Average daily demand: {sum(forecast_result['forecast']) / len(forecast_result['forecast']):.2f} units")
    print(f"Peak demand: {max(forecast_result['forecast']):.2f} units")
    print(f"Minimum demand: {min(forecast_result['forecast']):.2f} units")
    
    if 'summary' in forecast_result:
        print("\nForecast Summary:")
        print(forecast_result['summary'])
    
    return forecast_result

async def test_inventory_optimization():
    """Test the inventory optimization functionality."""
    print("\n=== Testing Inventory Optimization ===")
    
    # Create intelligence module
    intelligence_module = IntelligenceModule(ollama_model="mistral")
    
    # Generate sample data
    sales_data = await generate_sample_data()
    
    # Test inventory optimization for a product
    product_id = 1
    cost = 30.0
    current_inventory = 15
    
    optimization_result = await intelligence_module.optimize_inventory(
        product_id=product_id,
        cost=cost,
        current_inventory=current_inventory,
        sales_data=sales_data,
        lead_time_days=5
    )
    
    # Print results
    print(f"Inventory Optimization for Product {product_id}:")
    print(f"Current inventory: {current_inventory} units")
    print(f"Reorder point: {optimization_result['optimization']['reorder_point']} units")
    print(f"Economic order quantity: {optimization_result['optimization']['economic_order_quantity']} units")
    print(f"Safety stock: {optimization_result['optimization']['safety_stock']} units")
    
    print("\nSimulation Results:")
    print(f"Average inventory: {optimization_result['simulation']['avg_inventory']:.2f} units")
    print(f"Stockout rate: {optimization_result['simulation']['stockout_rate'] * 100:.2f}%")
    print(f"Service level: {optimization_result['simulation']['service_level'] * 100:.2f}%")
    
    if 'recommendations' in optimization_result:
        print("\nRecommendations:")
        print(optimization_result['recommendations'])
    
    return optimization_result

async def test_pricing_optimization():
    """Test the pricing optimization functionality."""
    print("\n=== Testing Pricing Optimization ===")
    
    # Create intelligence module
    intelligence_module = IntelligenceModule(ollama_model="mistral")
    
    # Generate sample data
    sales_data = await generate_sample_data()
    
    # Test pricing optimization for a product
    product_id = 1
    cost = 30.0
    current_price = 50.0
    current_inventory = 50
    target_inventory = 30
    
    pricing_result = await intelligence_module.optimize_pricing(
        product_id=product_id,
        cost=cost,
        current_price=current_price,
        current_inventory=current_inventory,
        target_inventory=target_inventory,
        sales_data=sales_data
    )
    
    # Print results
    print(f"Pricing Optimization for Product {product_id}:")
    print(f"Current price: ${current_price:.2f}")
    print(f"Optimal price: ${pricing_result['optimal_price']:.2f}")
    print(f"Price change: {pricing_result['price_change_pct']:.2f}%")
    print(f"Reason: {pricing_result['price_change_reason']}")
    
    print("\nExpected Impact:")
    print(f"Demand change: {pricing_result['expected_demand_change_pct']:.2f}%")
    print(f"New margin: {pricing_result['new_margin'] * 100:.2f}%")
    
    if 'promotions' in pricing_result and pricing_result['promotions']:
        print("\nPromotion Recommendations:")
        for promo in pricing_result['promotions'][:2]:  # Show first 2 promotions
            print(f"- {promo['type']}: {promo['discount_percentage']}% discount ({promo['reason']})")
    
    if 'recommendations' in pricing_result:
        print("\nRecommendations:")
        print(pricing_result['recommendations'])
    
    return pricing_result

async def main():
    """Run all tests."""
    try:
        # Test forecasting
        await test_forecasting()
        
        # Test inventory optimization
        await test_inventory_optimization()
        
        # Test pricing optimization
        await test_pricing_optimization()
        
    except Exception as e:
        print(f"Error in tests: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
