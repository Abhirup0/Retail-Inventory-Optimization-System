import asyncio
import logging
import argparse
import json
from pathlib import Path
import sys

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.simulation.simulation_environment import SimulationEnvironment

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("simulation.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def run_simulation(config_file: str = None, duration: int = 60, use_intelligence: bool = True):
    """
    Run the retail inventory optimization simulation.
    
    Args:
        config_file: Path to configuration file.
        duration: Duration in seconds.
        use_intelligence: Whether to use the intelligence module.
    """
    # Load configuration
    config = {}
    if config_file:
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            logger.info(f"Loaded configuration from {config_file}")
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            config = {}
    
    # Override configuration with command-line arguments
    config["use_intelligence_module"] = use_intelligence
    
    # Create simulation environment
    simulation = SimulationEnvironment(config)
    
    try:
        # Initialize simulation
        await simulation.initialize()
        
        # Run simulation
        await simulation.run(duration)
        
        # Generate report
        report = simulation.generate_report()
        
        # Print report summary
        print("\n=== Simulation Report ===")
        print(f"Duration: {report['duration']:.2f} seconds")
        print(f"Agents: {report['num_agents']['stores']} stores, {report['num_agents']['warehouse']} warehouse, "
              f"{report['num_agents']['suppliers']} suppliers, {report['num_agents']['customers']} customers")
        
        if "inventory_summary" in report and "warehouse" in report["inventory_summary"]:
            warehouse_summary = report["inventory_summary"]["warehouse"]
            print(f"\nWarehouse Inventory:")
            print(f"  Total items: {warehouse_summary['total_items']}")
            print(f"  Products: {warehouse_summary['num_products']}")
            print(f"  Stockouts: {warehouse_summary['stockouts']}")
        
        if "sales_summary" in report and "total_quantity" in report["sales_summary"]:
            print(f"\nSales:")
            print(f"  Total quantity: {report['sales_summary']['total_quantity']}")
            print(f"  Total revenue: ${report['sales_summary']['total_revenue']:.2f}")
        
        if "order_summary" in report and "total_orders" in report["order_summary"]:
            print(f"\nOrders:")
            print(f"  Total orders: {report['order_summary']['total_orders']}")
            if "status_counts" in report["order_summary"]:
                print(f"  Status counts: {report['order_summary']['status_counts']}")
        
        if "performance_metrics" in report and "warehouse" in report["performance_metrics"]:
            warehouse_metrics = report["performance_metrics"]["warehouse"]
            print(f"\nWarehouse Performance Metrics:")
            for metric, value in warehouse_metrics.items():
                print(f"  {metric}: {value:.4f}")
        
        # Save report to file
        report_path = "data/simulation/report.json"
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\nDetailed report saved to {report_path}")
        print(f"Simulation data saved to data/simulation/ directory")
        
    except Exception as e:
        logger.error(f"Error in simulation: {e}", exc_info=True)

def main():
    """Main function to parse arguments and run the simulation."""
    parser = argparse.ArgumentParser(description="Run retail inventory optimization simulation")
    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument("--duration", type=int, default=60, help="Simulation duration in seconds")
    parser.add_argument("--no-intelligence", action="store_true", help="Disable intelligence module")
    
    args = parser.parse_args()
    
    asyncio.run(run_simulation(
        config_file=args.config,
        duration=args.duration,
        use_intelligence=not args.no_intelligence
    ))

if __name__ == "__main__":
    main()
