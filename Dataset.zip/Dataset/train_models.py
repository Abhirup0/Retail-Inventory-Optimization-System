import asyncio
import logging
import argparse
import json
import os
import sys
from pathlib import Path
import pandas as pd
import numpy as np
from datetime import datetime

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.utils.data_loader import DataLoader
from src.models.forecasting_engine import ForecastingEngine
from src.models.inventory_optimizer import InventoryOptimizer
from src.models.pricing_optimizer import PricingOptimizer
from src.models.intelligence_module import IntelligenceModule

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("training.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def train_forecasting_models(data_loader: DataLoader, output_dir: str = "data/models"):
    """
    Train forecasting models on the dataset.
    
    Args:
        data_loader: DataLoader instance with loaded data.
        output_dir: Directory to save trained models.
    """
    logger.info("Training forecasting models...")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Initialize forecasting engine
    forecasting_engine = ForecastingEngine()
    
    # Get sales history data
    sales_history = data_loader.get_sales_history()
    
    # Convert to DataFrame
    sales_df = pd.DataFrame(sales_history)
    
    # Convert date strings to datetime
    sales_df['date'] = pd.to_datetime(sales_df['date'])
    
    # Get unique products
    unique_products = sales_df['product_id'].unique()
    
    # Train models for each product
    for product_id in unique_products:
        # Filter data for this product
        product_sales = sales_df[sales_df['product_id'] == product_id].copy()
        
        if len(product_sales) < 10:
            logger.warning(f"Insufficient data for product {product_id}. Skipping.")
            continue
        
        # Train model
        model_info = forecasting_engine.train_model(product_id, product_sales)
        
        if model_info:
            logger.info(f"Trained forecasting model for product {product_id} with performance: {model_info['performance']}")
    
    # Save models
    forecasting_engine.save_models(os.path.join(output_dir, "forecasting_models.pkl"))
    
    logger.info(f"Trained and saved forecasting models for {len(forecasting_engine.models)} products")
    
    return forecasting_engine

async def train_inventory_models(data_loader: DataLoader, forecasting_engine: ForecastingEngine, output_dir: str = "data/models"):
    """
    Train inventory optimization models on the dataset.
    
    Args:
        data_loader: DataLoader instance with loaded data.
        forecasting_engine: Trained forecasting engine.
        output_dir: Directory to save trained models.
    """
    logger.info("Training inventory optimization models...")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Initialize inventory optimizer
    inventory_optimizer = InventoryOptimizer(forecasting_engine=forecasting_engine)
    
    # Get inventory data
    inventory_data = data_loader.inventory_data
    
    if inventory_data is None or inventory_data.empty:
        logger.warning("No inventory data available. Skipping inventory model training.")
        return inventory_optimizer
    
    # Get unique products
    unique_products = inventory_data['Product ID'].unique()
    
    # Train models for each product
    for product_id in unique_products:
        # Filter data for this product
        product_inventory = inventory_data[inventory_data['Product ID'] == product_id].copy()
        
        if len(product_inventory) < 5:
            logger.warning(f"Insufficient inventory data for product {product_id}. Skipping.")
            continue
        
        # Get average values
        avg_stock = product_inventory['Stock Levels'].mean()
        avg_lead_time = product_inventory['Supplier Lead Time (days)'].mean()
        avg_reorder_point = product_inventory['Reorder Point'].mean()
        
        # Get sales data for this product
        sales_history = data_loader.get_sales_history()
        sales_df = pd.DataFrame([s for s in sales_history if s['product_id'] == product_id])
        
        if sales_df.empty:
            logger.warning(f"No sales data for product {product_id}. Skipping.")
            continue
        
        # Convert date strings to datetime
        sales_df['date'] = pd.to_datetime(sales_df['date'])
        
        # Calculate average daily demand
        sales_df['day'] = sales_df['date'].dt.date
        daily_demand = sales_df.groupby('day')['quantity'].sum().mean()
        
        # Train inventory model
        try:
            # Use the optimizer to calculate optimal inventory parameters
            product_data = data_loader.get_product_data().get(product_id, {})
            cost = product_data.get('cost', 50.0)
            
            # Generate demand forecast
            start_date = datetime.now()
            future_dates = [start_date + pd.Timedelta(days=i) for i in range(30)]
            
            # Check if we have a forecasting model for this product
            if product_id in forecasting_engine.models:
                demand_forecast = forecasting_engine.predict_demand(product_id, future_dates)
            else:
                # Use average daily demand as a simple forecast
                demand_forecast = [daily_demand] * 30
            
            # Optimize inventory levels
            optimization_result = inventory_optimizer.optimize_inventory_levels(
                product_id=product_id,
                demand_forecast=demand_forecast,
                lead_time_days=int(avg_lead_time),
                unit_cost=cost,
                current_inventory=int(avg_stock)
            )
            
            logger.info(f"Optimized inventory parameters for product {product_id}: "
                       f"Reorder point: {optimization_result['reorder_point']}, "
                       f"EOQ: {optimization_result['economic_order_quantity']}")
            
            # Store optimization parameters
            inventory_optimizer.optimization_params[product_id] = {
                'reorder_point': optimization_result['reorder_point'],
                'economic_order_quantity': optimization_result['economic_order_quantity'],
                'safety_stock': optimization_result['safety_stock'],
                'lead_time_days': int(avg_lead_time),
                'unit_cost': cost
            }
        
        except Exception as e:
            logger.error(f"Error optimizing inventory for product {product_id}: {e}")
    
    # Save models
    inventory_optimizer.save_params(os.path.join(output_dir, "inventory_params.pkl"))
    
    logger.info(f"Trained and saved inventory parameters for {len(inventory_optimizer.optimization_params)} products")
    
    return inventory_optimizer

async def train_pricing_models(data_loader: DataLoader, forecasting_engine: ForecastingEngine, output_dir: str = "data/models"):
    """
    Train pricing optimization models on the dataset.
    
    Args:
        data_loader: DataLoader instance with loaded data.
        forecasting_engine: Trained forecasting engine.
        output_dir: Directory to save trained models.
    """
    logger.info("Training pricing optimization models...")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Initialize pricing optimizer
    pricing_optimizer = PricingOptimizer(forecasting_engine=forecasting_engine)
    
    # Get pricing data
    pricing_data = data_loader.pricing_data
    
    if pricing_data is None or pricing_data.empty:
        logger.warning("No pricing data available. Skipping pricing model training.")
        return pricing_optimizer
    
    # Get unique products
    unique_products = pricing_data['Product ID'].unique()
    
    # Train models for each product
    for product_id in unique_products:
        # Filter data for this product
        product_pricing = pricing_data[pricing_data['Product ID'] == product_id].copy()
        
        if len(product_pricing) < 5:
            logger.warning(f"Insufficient pricing data for product {product_id}. Skipping.")
            continue
        
        # Get sales history for this product
        sales_history = data_loader.get_sales_history()
        sales_df = pd.DataFrame([s for s in sales_history if s['product_id'] == product_id])
        
        if sales_df.empty:
            logger.warning(f"No sales data for product {product_id}. Skipping.")
            continue
        
        # Estimate price elasticity
        try:
            elasticity = pricing_optimizer.estimate_price_elasticity(product_id, sales_df)
            
            # Store elasticity
            pricing_optimizer.elasticity_estimates[product_id] = elasticity
            
            logger.info(f"Estimated price elasticity for product {product_id}: {elasticity:.2f}")
            
            # Get product data
            product_data = data_loader.get_product_data().get(product_id, {})
            cost = product_data.get('cost', 50.0)
            current_price = product_data.get('base_price', 100.0)
            
            # Calculate optimal price
            optimal_price = pricing_optimizer.calculate_optimal_price_simple(
                cost=cost,
                price_elasticity=elasticity
            )
            
            # Store optimal price
            pricing_optimizer.optimal_prices[product_id] = {
                'optimal_price': optimal_price,
                'cost': cost,
                'elasticity': elasticity,
                'current_price': current_price
            }
            
            logger.info(f"Calculated optimal price for product {product_id}: ${optimal_price:.2f} (current: ${current_price:.2f})")
        
        except Exception as e:
            logger.error(f"Error optimizing pricing for product {product_id}: {e}")
    
    # Save models
    pricing_optimizer.save_params(os.path.join(output_dir, "pricing_params.pkl"))
    
    logger.info(f"Trained and saved pricing parameters for {len(pricing_optimizer.elasticity_estimates)} products")
    
    return pricing_optimizer

async def train_all_models(data_path: str = None, output_dir: str = "data/models"):
    """
    Train all models on the datasets.
    
    Args:
        data_path: Path to the directory containing the datasets.
        output_dir: Directory to save trained models.
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Load data
    data_loader = DataLoader(data_path)
    data_loader.load_datasets()
    
    # Save processed data
    data_loader.save_processed_data(os.path.join(output_dir, "processed_data.json"))
    
    # Train forecasting models
    forecasting_engine = await train_forecasting_models(data_loader, output_dir)
    
    # Train inventory models
    inventory_optimizer = await train_inventory_models(data_loader, forecasting_engine, output_dir)
    
    # Train pricing models
    pricing_optimizer = await train_pricing_models(data_loader, forecasting_engine, output_dir)
    
    # Create intelligence module with trained models
    intelligence_module = IntelligenceModule()
    intelligence_module.forecasting_engine = forecasting_engine
    intelligence_module.inventory_optimizer = inventory_optimizer
    intelligence_module.pricing_optimizer = pricing_optimizer
    
    # Save intelligence module
    intelligence_module.save_models(os.path.join(output_dir, "intelligence_module.pkl"))
    
    logger.info("All models trained and saved successfully")
    
    # Print summary
    print("\n=== Model Training Summary ===")
    print(f"Data path: {data_path or data_loader.data_path}")
    print(f"Output directory: {output_dir}")
    print(f"Forecasting models: {len(forecasting_engine.models)}")
    print(f"Inventory optimization parameters: {len(inventory_optimizer.optimization_params)}")
    print(f"Price elasticity estimates: {len(pricing_optimizer.elasticity_estimates)}")
    print("\nTraining completed successfully. Models saved to:")
    print(f"- Forecasting models: {os.path.join(output_dir, 'forecasting_models.pkl')}")
    print(f"- Inventory parameters: {os.path.join(output_dir, 'inventory_params.pkl')}")
    print(f"- Pricing parameters: {os.path.join(output_dir, 'pricing_params.pkl')}")
    print(f"- Intelligence module: {os.path.join(output_dir, 'intelligence_module.pkl')}")
    print(f"- Processed data: {os.path.join(output_dir, 'processed_data.json')}")

def main():
    """Main function to parse arguments and train models."""
    parser = argparse.ArgumentParser(description="Train models on retail datasets")
    parser.add_argument("--data", type=str, help="Path to the directory containing the datasets")
    parser.add_argument("--output", type=str, default="data/models", help="Directory to save trained models")
    
    args = parser.parse_args()
    
    asyncio.run(train_all_models(args.data, args.output))

if __name__ == "__main__":
    main()
