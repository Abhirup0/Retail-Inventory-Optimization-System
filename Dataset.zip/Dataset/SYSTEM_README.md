# Retail Inventory Optimization System

A multi-agent system for optimizing retail inventory management using AI-powered forecasting, inventory optimization, and pricing strategies.

## Overview

This system uses a multi-agent architecture to simulate and optimize a retail supply chain, including stores, warehouses, suppliers, and customers. The agents interact with each other to make decisions about inventory management, pricing, and ordering.

The system includes:

- **Intelligent forecasting** for demand prediction
- **Inventory optimization** algorithms for optimal stocking levels
- **Dynamic pricing** strategies based on inventory and demand
- **Multi-echelon inventory management** across stores and warehouses
- **Simulation environment** for testing different scenarios
- **Evaluation framework** for measuring performance

## Architecture

The system is built using a modular architecture:

1. **Agents**: Autonomous entities that make decisions and interact with each other
   - Store Agents: Manage store inventory and pricing
   - Warehouse Agent: Manages central inventory and distribution
   - Supplier Agents: Provide products to the warehouse
   - Customer Agents: Generate demand for products
   - Coordinator Agent: Oversees and coordinates all agents

2. **Intelligence Modules**: Provide advanced decision-making capabilities
   - Forecasting Engine: Predicts future demand
   - Inventory Optimizer: Determines optimal inventory levels
   - Pricing Optimizer: Sets optimal prices based on inventory and demand

3. **Simulation Environment**: Provides a controlled environment for testing
   - Scenario configuration
   - Metrics collection
   - Event generation

4. **Evaluation Framework**: Analyzes system performance
   - Performance metrics calculation
   - Visualization tools
   - Scenario comparison

## Getting Started

### Prerequisites

- Python 3.8 or higher
- Ollama (for LLM integration)

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/retail-inventory-optimization.git
   cd retail-inventory-optimization
   ```

2. Create a virtual environment:
   ```
   python -m venv inventory_env
   source inventory_env/bin/activate  # On Windows: inventory_env\\Scripts\\activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Install Ollama and download the required model:
   ```
   # Follow instructions at https://ollama.ai/
   ollama pull mistral
   ```

### Running the System

1. Run a basic simulation:
   ```
   python run_simulation.py --duration 60
   ```

2. Run with a specific configuration:
   ```
   python run_simulation.py --config simulation_config.json
   ```

3. Run multiple scenarios:
   ```
   python run_scenarios.py --config scenario_config.json
   ```

4. Evaluate simulation results:
   ```
   python evaluate_simulation.py --data data/simulation
   ```

5. Run a comprehensive evaluation:
   ```
   python comprehensive_evaluation.py --config scenario_config.json
   ```

## Configuration

The system can be configured using JSON configuration files:

- `simulation_config.json`: Basic simulation configuration
- `scenario_config.json`: Multiple scenario configurations

Example configuration:
```json
{
  "num_stores": 3,
  "num_suppliers": 3,
  "num_customers": 10,
  "num_products": 20,
  "time_acceleration": 10,
  "ollama_model": "mistral",
  "use_intelligence_module": true,
  "random_seed": 42,
  "simulation_scenarios": [
    {
      "name": "baseline",
      "description": "Baseline scenario with default parameters",
      "duration": 120
    },
    {
      "name": "high_demand",
      "description": "High demand scenario with increased customer activity",
      "duration": 120,
      "customer_activity_multiplier": 2.0
    }
  ]
}
```

## Evaluation

The system includes a comprehensive evaluation framework:

1. **Performance Metrics**:
   - Inventory turnover
   - Stockout rate
   - Order fill rate
   - Sales revenue
   - Profit margin

2. **Visualization Tools**:
   - Inventory levels over time
   - Sales by store and product
   - Stockout rates
   - Order status distribution

3. **Scenario Comparison**:
   - Compare KPIs across different scenarios
   - Identify optimal configurations

## Project Structure

```
retail-inventory-optimization/
├── src/
│   ├── agents/                 # Agent implementations
│   │   ├── base_agent.py       # Base agent class
│   │   ├── store_agent.py      # Store agent
│   │   ├── warehouse_agent.py  # Warehouse agent
│   │   ├── supplier_agent.py   # Supplier agent
│   │   ├── customer_agent.py   # Customer agent
│   │   └── coordinator_agent.py # Coordinator agent
│   ├── models/                 # Intelligence modules
│   │   ├── forecasting_engine.py # Demand forecasting
│   │   ├── inventory_optimizer.py # Inventory optimization
│   │   ├── pricing_optimizer.py # Price optimization
│   │   └── intelligence_module.py # Integration module
│   ├── simulation/             # Simulation environment
│   │   └── simulation_environment.py # Simulation environment
│   ├── evaluation/             # Evaluation tools
│   │   ├── metrics.py          # Performance metrics
│   │   └── visualization.py    # Visualization tools
│   ├── utils/                  # Utility functions
│   │   ├── message_bus.py      # Agent communication
│   │   └── llm_integration.py  # LLM integration
│   ├── api/                    # API and dashboard
│   │   └── dashboard.py        # Web dashboard
│   └── main.py                 # Main application
├── data/                       # Data directory
│   ├── simulation/             # Simulation data
│   ├── models/                 # Saved models
│   └── evaluation/             # Evaluation results
├── run_simulation.py           # Run simulation script
├── run_scenarios.py            # Run scenarios script
├── evaluate_simulation.py      # Evaluation script
├── comprehensive_evaluation.py # Comprehensive evaluation
├── test_intelligence.py        # Test intelligence modules
├── test_integration.py         # Test integration
├── simulation_config.json      # Simulation configuration
├── scenario_config.json        # Scenario configuration
├── requirements.txt            # Dependencies
└── README.md                   # This file
```

## Future Improvements

- Integration with real-world data sources
- More sophisticated forecasting models
- Advanced optimization algorithms
- Real-time monitoring and alerting
- Web-based dashboard for visualization
- Integration with existing inventory management systems

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- This project was developed as part of a hackathon focused on multi-agent AI systems.
- Uses Ollama for on-premise LLM capabilities.
