import sys
import os
import asyncio
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.database.init_db import init_database
from src.database.generate_data import generate_data

async def initialize():
    """Initialize the database and generate sample data."""
    # Initialize database
    init_database()
    
    # Generate sample data
    generate_data()
    
    print("Database initialization and data generation completed successfully.")

if __name__ == "__main__":
    asyncio.run(initialize())
