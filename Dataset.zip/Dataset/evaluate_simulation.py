import asyncio
import logging
import argparse
import json
import os
import sys
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.evaluation.metrics import PerformanceMetrics
from src.evaluation.visualization import MetricsVisualizer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("evaluation.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

def evaluate_simulation(data_path: str, output_dir: str = "data/evaluation", compare_with: str = None):
    """
    Evaluate simulation results and generate reports.
    
    Args:
        data_path: Path to the directory containing simulation data.
        output_dir: Directory to save evaluation results.
        compare_with: Path to metrics file to compare with.
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Initialize metrics calculator
    metrics_calculator = PerformanceMetrics()
    
    # Load simulation data
    metrics_calculator.load_data(data_path)
    
    # Calculate metrics
    metrics = metrics_calculator.calculate_all_metrics()
    
    # Calculate KPIs
    kpis = metrics_calculator.calculate_kpis()
    
    # Save metrics to file
    metrics_calculator.save_metrics(f"{output_dir}/metrics.json")
    
    # Generate report
    metrics_calculator.generate_report(f"{output_dir}/report.md")
    
    # Initialize visualizer
    visualizer = MetricsVisualizer(metrics_data=metrics)
    
    # Load simulation data for visualizations
    visualizer.load_simulation_data(data_path)
    
    # Generate visualizations
    visualizer.generate_all_visualizations(f"{output_dir}/visualizations")
    
    # Compare with another scenario if specified
    if compare_with:
        try:
            with open(compare_with, 'r') as f:
                comparison_metrics = json.load(f)
            
            # Generate comparison report
            comparison = metrics_calculator.compare_scenarios(comparison_metrics)
            
            # Save comparison to file
            with open(f"{output_dir}/comparison.json", 'w') as f:
                json.dump(comparison, f, indent=2)
            
            # Generate comparison visualization
            visualizer.plot_comparison(
                comparison_metrics,
                scenario_name="Current",
                other_name="Baseline",
                save_path=f"{output_dir}/visualizations/comparison.png"
            )
            
            logger.info(f"Generated comparison with {compare_with}")
        except Exception as e:
            logger.error(f"Error comparing with {compare_with}: {e}")
    
    # Print summary
    print("\n=== Evaluation Summary ===")
    print(f"Data path: {data_path}")
    print(f"Output directory: {output_dir}")
    print("\nKey Performance Indicators (KPIs):")
    for kpi, value in kpis.items():
        print(f"- {kpi.replace('_', ' ').title()}: {value:.4f}")
    
    print("\nEvaluation completed. Reports and visualizations saved to:")
    print(f"- Metrics: {output_dir}/metrics.json")
    print(f"- Report: {output_dir}/report.md")
    print(f"- Visualizations: {output_dir}/visualizations/")
    
    if compare_with:
        print(f"- Comparison: {output_dir}/comparison.json")
        print(f"- Comparison visualization: {output_dir}/visualizations/comparison.png")

def main():
    """Main function to parse arguments and run evaluation."""
    parser = argparse.ArgumentParser(description="Evaluate simulation results")
    parser.add_argument("--data", type=str, default="data/simulation", help="Path to simulation data directory")
    parser.add_argument("--output", type=str, default="data/evaluation", help="Output directory for evaluation results")
    parser.add_argument("--compare", type=str, help="Path to metrics file to compare with")
    
    args = parser.parse_args()
    
    try:
        evaluate_simulation(
            data_path=args.data,
            output_dir=args.output,
            compare_with=args.compare
        )
    except Exception as e:
        logger.error(f"Error in evaluation: {e}", exc_info=True)

if __name__ == "__main__":
    main()
