# Retail Inventory Optimization with Multi-Agent AI

This project implements a multi-agent AI system for optimizing retail inventory management. The system uses autonomous agents representing stores, warehouses, suppliers, and customers to collaborate and make intelligent decisions about inventory levels, restocking, pricing, and more.

## Project Structure

```
retail-inventory-optimization/
├── data/                      # Data directory for SQLite database and other data files
├── src/                       # Source code
│   ├── agents/                # Agent implementations
│   │   ├── base_agent.py      # Base agent class
│   │   ├── store_agent.py     # Store agent implementation
│   │   ├── warehouse_agent.py # Warehouse agent implementation
│   │   └── ...                # Other agent implementations
│   ├── database/              # Database-related code
│   │   ├── database.py        # Database connection and session management
│   │   ├── models.py          # SQLAlchemy models
│   │   ├── init_db.py         # Database initialization script
│   │   └── generate_data.py   # Data generation script
│   ├── models/                # ML models for forecasting and optimization
│   ├── utils/                 # Utility functions
│   ├── api/                   # API endpoints
│   └── main.py                # Main application entry point
├── tests/                     # Test directory
├── requirements.txt           # Python dependencies
└── README.md                  # Project documentation
```

## Setup Instructions

1. Create a virtual environment:
   ```
   python -m venv inventory_env
   ```

2. Activate the virtual environment:
   - Windows: `.\inventory_env\Scripts\activate`
   - macOS/Linux: `source inventory_env/bin/activate`

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Initialize the database:
   ```
   python -m src.database.init_db
   ```

5. Generate sample data:
   ```
   python -m src.database.generate_data
   ```

6. Run the application:
   ```
   python -m src.main
   ```

## Agent Architecture

The system consists of the following agent types:

1. **Store Agent**: Represents a retail store, manages local inventory, and interacts with customers.
2. **Warehouse Agent**: Manages central inventory and coordinates with stores and suppliers.
3. **Supplier Agent**: Represents external product suppliers and manages the supply chain.
4. **Customer Agent**: Models customer behavior and preferences to predict demand.
5. **Coordinator Agent**: Orchestrates communication between agents and ensures system-wide optimization.

Each agent has its own state, memory, and decision-making capabilities. Agents communicate with each other through a message-passing system.

## Features

- **Demand Forecasting**: Predicts future product demand based on historical sales data.
- **Inventory Optimization**: Determines optimal inventory levels to minimize costs while avoiding stockouts.
- **Dynamic Pricing**: Adjusts prices based on inventory levels and demand.
- **Cross-Store Inventory Balancing**: Redistributes inventory between stores to optimize overall availability.
- **Supplier Order Optimization**: Determines when and how much to order from suppliers.
- **Real-time Monitoring**: Tracks inventory levels, sales, and other metrics in real-time.

## Technologies Used

- **Python**: Primary programming language
- **SQLite**: Database for storing inventory, sales, and other data
- **SQLAlchemy**: ORM for database interactions
- **Ollama**: Local LLM integration for agent intelligence
- **AsyncIO**: Asynchronous programming for agent concurrency
- **FastAPI**: API framework (for future web dashboard)

## Future Enhancements

- Integration with real POS systems
- Mobile app for store managers
- Advanced forecasting with external factors (weather, events, etc.)
- Reinforcement learning for agent decision-making
- Supplier negotiation capabilities
- Customer-facing recommendations

## License

This project is licensed under the MIT License - see the LICENSE file for details.
