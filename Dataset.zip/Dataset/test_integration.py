import asyncio
import logging
import argparse
import json
import sys
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.models.intelligence_module import IntelligenceModule
from src.agents.store_agent import StoreAgent
from src.agents.warehouse_agent import WarehouseAgent
from src.utils.message_bus import MessageBus

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("integration_test.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def test_store_agent_with_intelligence():
    """Test the store agent with intelligence module."""
    logger.info("Testing store agent with intelligence module...")
    
    # Create intelligence module
    intelligence_module = IntelligenceModule(ollama_model="mistral")
    
    # Create message bus
    message_bus = MessageBus()
    
    # Create store agent
    store = StoreAgent(
        store_id=1,
        name="Test Store",
        location="Test Location",
        intelligence_module=intelligence_module,
        message_bus=message_bus
    )
    
    # Initialize inventory
    store.state["inventory"] = {
        1: 50,  # Product 1: 50 units
        2: 10,  # Product 2: 10 units (low)
        3: 0,   # Product 3: 0 units (stockout)
        4: 100  # Product 4: 100 units (overstocked)
    }
    
    # Add some sales history
    store.state["sales"] = [
        {
            "product_id": 1,
            "quantity": 5,
            "price": 100.0,
            "date": "2023-04-01T10:00:00",
            "customer_id": 1
        },
        {
            "product_id": 1,
            "quantity": 3,
            "price": 100.0,
            "date": "2023-04-02T11:00:00",
            "customer_id": 2
        },
        {
            "product_id": 2,
            "quantity": 2,
            "price": 150.0,
            "date": "2023-04-01T09:00:00",
            "customer_id": 3
        }
    ]
    
    # Check inventory
    logger.info("Checking inventory...")
    await store.check_inventory()
    
    # Print results
    logger.info(f"Stockouts: {store.state['stockouts']}")
    logger.info(f"Overstocked items: {store.state['overstocked_items']}")
    
    if "reorder_recommendations" in store.state:
        logger.info(f"Reorder recommendations: {store.state['reorder_recommendations']}")
    
    # Adjust prices
    logger.info("Adjusting prices...")
    await store.adjust_prices()
    
    # Print results
    if "price_adjustments" in store.state:
        logger.info(f"Price adjustments: {store.state['price_adjustments']}")
    
    if "promotions" in store.state:
        logger.info(f"Promotions: {store.state['promotions']}")
    
    return store

async def test_warehouse_agent_with_intelligence():
    """Test the warehouse agent with intelligence module."""
    logger.info("Testing warehouse agent with intelligence module...")
    
    # Create intelligence module
    intelligence_module = IntelligenceModule(ollama_model="mistral")
    
    # Create message bus
    message_bus = MessageBus()
    
    # Create warehouse agent
    warehouse = WarehouseAgent(
        warehouse_id=1,
        name="Test Warehouse",
        location="Test Location",
        intelligence_module=intelligence_module,
        message_bus=message_bus
    )
    
    # Initialize inventory
    warehouse.state["inventory"] = {
        1: 100,  # Product 1: 100 units
        2: 15,   # Product 2: 15 units (low)
        3: 50,   # Product 3: 50 units
        4: 200   # Product 4: 200 units (high)
    }
    
    # Add store inventory data
    warehouse.state["store_inventory"] = {
        1: {
            "inventory": {
                1: 50,
                2: 10,
                3: 0,
                4: 100
            },
            "stockouts": [3],
            "overstocked_items": [4]
        },
        2: {
            "inventory": {
                1: 30,
                2: 5,
                3: 20,
                4: 80
            },
            "stockouts": [2],
            "overstocked_items": []
        }
    }
    
    # Add supplier orders
    warehouse.state["supplier_orders"] = [
        {
            "order_id": "order_1",
            "supplier_id": 1,
            "products": {1: 50, 2: 30},
            "timestamp": "2023-04-01T10:00:00",
            "status": "delivered",
            "actual_delivery_date": "2023-04-05T10:00:00"
        },
        {
            "order_id": "order_2",
            "supplier_id": 2,
            "products": {3: 40, 4: 60},
            "timestamp": "2023-04-02T11:00:00",
            "status": "shipped"
        }
    ]
    
    # Check inventory
    logger.info("Checking inventory...")
    await warehouse.check_inventory()
    
    # Print results
    logger.info(f"Low stock items: {warehouse.state.get('low_stock_items', [])}")
    
    if "reorder_recommendations" in warehouse.state:
        logger.info(f"Reorder recommendations: {warehouse.state['reorder_recommendations']}")
    
    # Check inventory rebalancing
    logger.info("Checking inventory rebalancing...")
    await warehouse.check_inventory_rebalancing()
    
    # Print results
    if "rebalancing_plans" in warehouse.state:
        logger.info(f"Rebalancing plans: {warehouse.state['rebalancing_plans']}")
    
    return warehouse

async def main():
    """Main function to run integration tests."""
    parser = argparse.ArgumentParser(description="Run integration tests")
    parser.add_argument("--test", choices=["store", "warehouse", "all"], default="all", help="Test to run")
    
    args = parser.parse_args()
    
    try:
        if args.test in ["store", "all"]:
            store = await test_store_agent_with_intelligence()
            print("\nStore Agent Test Results:")
            print(f"Stockouts: {store.state['stockouts']}")
            print(f"Overstocked items: {store.state['overstocked_items']}")
            if "reorder_recommendations" in store.state:
                print(f"Reorder recommendations: {len(store.state['reorder_recommendations'])}")
            if "price_adjustments" in store.state:
                print(f"Price adjustments: {len(store.state['price_adjustments'])}")
        
        if args.test in ["warehouse", "all"]:
            warehouse = await test_warehouse_agent_with_intelligence()
            print("\nWarehouse Agent Test Results:")
            print(f"Low stock items: {warehouse.state.get('low_stock_items', [])}")
            if "reorder_recommendations" in warehouse.state:
                print(f"Reorder recommendations: {len(warehouse.state['reorder_recommendations'])}")
            if "rebalancing_plans" in warehouse.state:
                print(f"Rebalancing plans: {len(warehouse.state['rebalancing_plans'])}")
    
    except Exception as e:
        logger.error(f"Error in integration test: {e}", exc_info=True)

if __name__ == "__main__":
    asyncio.run(main())
