import asyncio
import logging
import argparse
import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.simulation.simulation_environment import SimulationEnvironment

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("scenarios.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def run_scenario(scenario_config: dict, output_dir: str):
    """
    Run a simulation scenario.
    
    Args:
        scenario_config: Configuration for the scenario.
        output_dir: Directory to save scenario results.
    
    Returns:
        Dictionary with scenario results.
    """
    # Create output directory if it doesn't exist
    scenario_name = scenario_config.get("name", "unnamed_scenario")
    scenario_dir = os.path.join(output_dir, scenario_name)
    os.makedirs(scenario_dir, exist_ok=True)
    
    # Log scenario start
    logger.info(f"Starting scenario: {scenario_name}")
    logger.info(f"Description: {scenario_config.get('description', 'No description')}")
    
    # Create simulation environment
    simulation = SimulationEnvironment(scenario_config)
    
    # Initialize simulation
    await simulation.initialize()
    
    # Run simulation
    start_time = time.time()
    await simulation.run(scenario_config.get("duration", 60))
    end_time = time.time()
    
    # Generate report
    report = simulation.generate_report()
    
    # Add scenario information to report
    report["scenario"] = {
        "name": scenario_name,
        "description": scenario_config.get("description", "No description"),
        "duration": scenario_config.get("duration", 60),
        "actual_runtime": end_time - start_time
    }
    
    # Save report
    report_path = os.path.join(scenario_dir, "report.json")
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=2)
    
    # Log scenario completion
    logger.info(f"Completed scenario: {scenario_name}")
    logger.info(f"Runtime: {end_time - start_time:.2f} seconds")
    logger.info(f"Report saved to: {report_path}")
    
    return report

async def run_all_scenarios(config_file: str, output_dir: str = "data/scenarios"):
    """
    Run all scenarios defined in the configuration file.
    
    Args:
        config_file: Path to the configuration file.
        output_dir: Directory to save scenario results.
    """
    # Create output directory if it doesn't exist
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(output_dir, timestamp)
    os.makedirs(output_dir, exist_ok=True)
    
    # Load configuration
    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
    except Exception as e:
        logger.error(f"Error loading configuration: {e}")
        return
    
    # Get scenarios
    scenarios = config.get("simulation_scenarios", [])
    if not scenarios:
        logger.warning("No scenarios found in configuration")
        return
    
    # Create base configuration
    base_config = {k: v for k, v in config.items() if k != "simulation_scenarios"}
    
    # Run each scenario
    scenario_results = {}
    
    for scenario in scenarios:
        # Merge base config with scenario config
        scenario_config = {**base_config, **scenario}
        
        # Run scenario
        try:
            result = await run_scenario(scenario_config, output_dir)
            scenario_results[scenario.get("name", "unnamed_scenario")] = result
        except Exception as e:
            logger.error(f"Error running scenario {scenario.get('name', 'unnamed_scenario')}: {e}", exc_info=True)
    
    # Save combined results
    combined_results_path = os.path.join(output_dir, "combined_results.json")
    with open(combined_results_path, 'w') as f:
        json.dump(scenario_results, f, indent=2)
    
    # Generate comparison report
    comparison_report = []
    comparison_report.append("# Scenario Comparison Report\n")
    comparison_report.append(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Add scenario descriptions
    comparison_report.append("## Scenarios\n")
    for scenario in scenarios:
        name = scenario.get("name", "unnamed_scenario")
        description = scenario.get("description", "No description")
        duration = scenario.get("duration", 60)
        comparison_report.append(f"### {name}\n")
        comparison_report.append(f"- **Description**: {description}")
        comparison_report.append(f"- **Duration**: {duration} seconds\n")
    
    # Add KPI comparison
    comparison_report.append("## KPI Comparison\n")
    
    # Get all KPIs
    all_kpis = set()
    for scenario_name, result in scenario_results.items():
        if "sales_summary" in result:
            all_kpis.add("total_sales")
            all_kpis.add("total_revenue")
        if "inventory_summary" in result and "warehouse" in result["inventory_summary"]:
            all_kpis.add("stockouts")
            all_kpis.add("total_items")
    
    # Create KPI table
    comparison_report.append("| KPI | " + " | ".join(scenario_results.keys()) + " |")
    comparison_report.append("|-----|" + "-|" * len(scenario_results) + "-|")
    
    for kpi in sorted(all_kpis):
        row = [f"**{kpi.replace('_', ' ').title()}**"]
        
        for scenario_name, result in scenario_results.items():
            value = "N/A"
            
            if kpi == "total_sales" and "sales_summary" in result and "total_quantity" in result["sales_summary"]:
                value = str(result["sales_summary"]["total_quantity"])
            elif kpi == "total_revenue" and "sales_summary" in result and "total_revenue" in result["sales_summary"]:
                value = f"${result['sales_summary']['total_revenue']:.2f}"
            elif kpi == "stockouts" and "inventory_summary" in result and "warehouse" in result["inventory_summary"]:
                value = str(result["inventory_summary"]["warehouse"]["stockouts"])
            elif kpi == "total_items" and "inventory_summary" in result and "warehouse" in result["inventory_summary"]:
                value = str(result["inventory_summary"]["warehouse"]["total_items"])
            
            row.append(value)
        
        comparison_report.append(" | ".join(row) + " |")
    
    comparison_report.append("\n")
    
    # Save comparison report
    comparison_report_path = os.path.join(output_dir, "comparison_report.md")
    with open(comparison_report_path, 'w') as f:
        f.write("\n".join(comparison_report))
    
    logger.info(f"All scenarios completed. Results saved to: {output_dir}")
    logger.info(f"Combined results: {combined_results_path}")
    logger.info(f"Comparison report: {comparison_report_path}")
    
    # Print summary
    print("\n=== Scenario Results ===")
    print(f"Total scenarios: {len(scenarios)}")
    print(f"Results directory: {output_dir}")
    print("\nScenario KPIs:")
    
    for scenario_name, result in scenario_results.items():
        print(f"\n{scenario_name}:")
        
        if "sales_summary" in result:
            print(f"- Total sales: {result['sales_summary'].get('total_quantity', 'N/A')}")
            print(f"- Total revenue: ${result['sales_summary'].get('total_revenue', 0):.2f}")
        
        if "inventory_summary" in result and "warehouse" in result["inventory_summary"]:
            print(f"- Warehouse stockouts: {result['inventory_summary']['warehouse'].get('stockouts', 'N/A')}")
            print(f"- Total inventory: {result['inventory_summary']['warehouse'].get('total_items', 'N/A')}")
    
    print(f"\nComparison report: {comparison_report_path}")

def main():
    """Main function to parse arguments and run scenarios."""
    parser = argparse.ArgumentParser(description="Run simulation scenarios")
    parser.add_argument("--config", type=str, default="simulation_config.json", help="Path to configuration file")
    parser.add_argument("--output", type=str, default="data/scenarios", help="Output directory for scenario results")
    
    args = parser.parse_args()
    
    asyncio.run(run_all_scenarios(args.config, args.output))

if __name__ == "__main__":
    main()
