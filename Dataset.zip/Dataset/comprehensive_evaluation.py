import asyncio
import logging
import argparse
import json
import os
import sys
import time
import shutil
from pathlib import Path
from datetime import datetime

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from run_scenarios import run_all_scenarios
from evaluate_simulation import evaluate_simulation

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("comprehensive_evaluation.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def run_comprehensive_evaluation(config_file: str, output_dir: str = "data/evaluation_results"):
    """
    Run a comprehensive evaluation of the retail inventory optimization system.
    
    Args:
        config_file: Path to the configuration file.
        output_dir: Directory to save evaluation results.
    """
    # Create timestamp for this evaluation
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    eval_dir = os.path.join(output_dir, timestamp)
    os.makedirs(eval_dir, exist_ok=True)
    
    # Copy configuration file to evaluation directory
    shutil.copy(config_file, os.path.join(eval_dir, "config.json"))
    
    # Step 1: Run all scenarios
    logger.info("Step 1: Running all scenarios...")
    scenarios_dir = os.path.join(eval_dir, "scenarios")
    await run_all_scenarios(config_file, scenarios_dir)
    
    # Step 2: Evaluate each scenario
    logger.info("Step 2: Evaluating each scenario...")
    
    # Get scenario directories
    scenario_dirs = [d for d in os.listdir(scenarios_dir) if os.path.isdir(os.path.join(scenarios_dir, d))]
    
    for scenario in scenario_dirs:
        scenario_data_dir = os.path.join(scenarios_dir, scenario)
        scenario_eval_dir = os.path.join(eval_dir, "evaluations", scenario)
        os.makedirs(scenario_eval_dir, exist_ok=True)
        
        logger.info(f"Evaluating scenario: {scenario}")
        evaluate_simulation(scenario_data_dir, scenario_eval_dir)
    
    # Step 3: Compare scenarios
    logger.info("Step 3: Comparing scenarios...")
    
    # Find baseline scenario
    baseline_scenario = None
    for scenario in scenario_dirs:
        if scenario == "baseline":
            baseline_scenario = scenario
            break
    
    if not baseline_scenario and scenario_dirs:
        baseline_scenario = scenario_dirs[0]
    
    if baseline_scenario:
        baseline_metrics_path = os.path.join(eval_dir, "evaluations", baseline_scenario, "metrics.json")
        
        # Compare each scenario with baseline
        for scenario in scenario_dirs:
            if scenario == baseline_scenario:
                continue
            
            scenario_eval_dir = os.path.join(eval_dir, "evaluations", scenario)
            evaluate_simulation(
                os.path.join(scenarios_dir, scenario),
                scenario_eval_dir,
                compare_with=baseline_metrics_path
            )
    
    # Step 4: Generate comprehensive report
    logger.info("Step 4: Generating comprehensive report...")
    
    # Load metrics from each scenario
    scenario_metrics = {}
    for scenario in scenario_dirs:
        metrics_path = os.path.join(eval_dir, "evaluations", scenario, "metrics.json")
        try:
            with open(metrics_path, 'r') as f:
                metrics = json.load(f)
                scenario_metrics[scenario] = metrics
        except Exception as e:
            logger.error(f"Error loading metrics for scenario {scenario}: {e}")
    
    # Generate comprehensive report
    report = []
    report.append("# Comprehensive Evaluation Report\n")
    report.append(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Add scenario descriptions
    report.append("## Scenarios\n")
    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
            scenarios = config.get("simulation_scenarios", [])
            
            for scenario_config in scenarios:
                name = scenario_config.get("name", "unnamed_scenario")
                description = scenario_config.get("description", "No description")
                duration = scenario_config.get("duration", 60)
                
                report.append(f"### {name}\n")
                report.append(f"- **Description**: {description}")
                report.append(f"- **Duration**: {duration} seconds")
                
                # Add scenario-specific parameters
                for key, value in scenario_config.items():
                    if key not in ["name", "description", "duration"]:
                        report.append(f"- **{key}**: {value}")
                
                report.append("")
    except Exception as e:
        logger.error(f"Error loading scenario descriptions: {e}")
    
    # Add KPI comparison
    report.append("## KPI Comparison\n")
    
    # Extract KPIs from each scenario
    kpi_data = {}
    for scenario, metrics in scenario_metrics.items():
        if "inventory" in metrics and "overall" in metrics["inventory"]:
            kpi_data.setdefault("stockout_rate", {})[scenario] = metrics["inventory"]["overall"]["stockout_rate"]
        
        if "inventory" in metrics and "overall" in metrics["inventory"] and "sales" in metrics and "total" in metrics["sales"]:
            avg_inventory = metrics["inventory"]["overall"]["avg_inventory"]
            total_sales = metrics["sales"]["total"]["quantity"]
            
            if avg_inventory > 0:
                kpi_data.setdefault("inventory_turnover", {})[scenario] = total_sales / avg_inventory
        
        if "sales" in metrics and "total" in metrics["sales"]:
            kpi_data.setdefault("total_sales", {})[scenario] = metrics["sales"]["total"]["quantity"]
            kpi_data.setdefault("total_revenue", {})[scenario] = metrics["sales"]["total"]["revenue"]
    
    # Create KPI table
    if kpi_data:
        report.append("| KPI | " + " | ".join(scenario_dirs) + " |")
        report.append("|-----|" + "-|" * len(scenario_dirs) + "-|")
        
        for kpi, values in kpi_data.items():
            row = [f"**{kpi.replace('_', ' ').title()}**"]
            
            for scenario in scenario_dirs:
                value = values.get(scenario, "N/A")
                if isinstance(value, (int, float)):
                    if kpi == "total_revenue":
                        row.append(f"${value:.2f}")
                    else:
                        row.append(f"{value:.4f}")
                else:
                    row.append(str(value))
            
            report.append(" | ".join(row) + " |")
        
        report.append("")
    
    # Add improvement analysis
    if baseline_scenario and len(scenario_dirs) > 1:
        report.append("## Improvement Analysis\n")
        report.append("This section shows the percentage improvement of each scenario compared to the baseline.\n")
        
        report.append("| KPI | " + " | ".join([s for s in scenario_dirs if s != baseline_scenario]) + " |")
        report.append("|-----|" + "-|" * (len(scenario_dirs) - 1) + "-|")
        
        for kpi, values in kpi_data.items():
            if baseline_scenario in values:
                baseline_value = values[baseline_scenario]
                
                if baseline_value != 0:
                    row = [f"**{kpi.replace('_', ' ').title()}**"]
                    
                    for scenario in scenario_dirs:
                        if scenario != baseline_scenario and scenario in values:
                            scenario_value = values[scenario]
                            pct_change = ((scenario_value - baseline_value) / baseline_value) * 100
                            
                            # For stockout rate, negative change is good
                            if kpi == "stockout_rate":
                                pct_change = -pct_change
                            
                            if pct_change > 0:
                                row.append(f"+{pct_change:.2f}%")
                            else:
                                row.append(f"{pct_change:.2f}%")
                        elif scenario != baseline_scenario:
                            row.append("N/A")
                    
                    report.append(" | ".join(row) + " |")
        
        report.append("")
    
    # Add recommendations
    report.append("## Recommendations\n")
    
    # Find best scenario for each KPI
    best_scenarios = {}
    for kpi, values in kpi_data.items():
        if kpi == "stockout_rate":
            # Lower is better for stockout rate
            best_scenario = min(values.items(), key=lambda x: x[1])[0]
        else:
            # Higher is better for other KPIs
            best_scenario = max(values.items(), key=lambda x: x[1])[0]
        
        best_scenarios[kpi] = best_scenario
    
    # Generate recommendations
    report.append("Based on the evaluation results, here are the recommendations:\n")
    
    for kpi, best_scenario in best_scenarios.items():
        report.append(f"- For optimizing **{kpi.replace('_', ' ').title()}**, use the **{best_scenario}** scenario configuration.")
    
    report.append("\nOverall recommendation:")
    
    # Count how many times each scenario is the best
    scenario_counts = {}
    for best_scenario in best_scenarios.values():
        scenario_counts[best_scenario] = scenario_counts.get(best_scenario, 0) + 1
    
    # Find the overall best scenario
    if scenario_counts:
        overall_best = max(scenario_counts.items(), key=lambda x: x[1])[0]
        report.append(f"The **{overall_best}** scenario provides the best overall performance across multiple KPIs.")
    
    # Save comprehensive report
    report_path = os.path.join(eval_dir, "comprehensive_report.md")
    with open(report_path, 'w') as f:
        f.write("\n".join(report))
    
    logger.info(f"Comprehensive evaluation completed. Report saved to: {report_path}")
    
    # Print summary
    print("\n=== Comprehensive Evaluation Summary ===")
    print(f"Evaluation directory: {eval_dir}")
    print(f"Scenarios evaluated: {len(scenario_dirs)}")
    print(f"Comprehensive report: {report_path}")
    
    if best_scenarios:
        print("\nBest scenarios by KPI:")
        for kpi, best_scenario in best_scenarios.items():
            print(f"- {kpi.replace('_', ' ').title()}: {best_scenario}")
    
    if scenario_counts:
        print(f"\nOverall best scenario: {overall_best}")

def main():
    """Main function to parse arguments and run comprehensive evaluation."""
    parser = argparse.ArgumentParser(description="Run comprehensive evaluation")
    parser.add_argument("--config", type=str, default="scenario_config.json", help="Path to configuration file")
    parser.add_argument("--output", type=str, default="data/evaluation_results", help="Output directory for evaluation results")
    
    args = parser.parse_args()
    
    asyncio.run(run_comprehensive_evaluation(args.config, args.output))

if __name__ == "__main__":
    main()
