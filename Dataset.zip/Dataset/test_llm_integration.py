import sys
import os
import asyncio
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.utils.llm_integration import test_llm_integration

if __name__ == "__main__":
    asyncio.run(test_llm_integration())
