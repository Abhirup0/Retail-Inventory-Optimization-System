import asyncio
import os
import sys
import logging
import random
import threading
import argparse
import json
from pathlib import Path
from dotenv import load_dotenv

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Load environment variables
load_dotenv()

from src.database.database import engine
from src.database.models import Base
from src.database import generate_data
from src.agents.store_agent import StoreAgent
from src.agents.warehouse_agent import WarehouseAgent
from src.agents.supplier_agent import SupplierAgent
from src.agents.customer_agent import CustomerAgent
from src.agents.coordinator_agent import CoordinatorAgent
from src.utils.message_bus import MessageBus
from src.api.dashboard import setup_message_bus, start_dashboard
from src.models.intelligence_module import IntelligenceModule

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("retail_inventory.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

async def initialize_database():
    """Initialize the database and generate sample data."""
    logger.info("Initializing database...")

    # Create tables
    Base.metadata.create_all(bind=engine)

    # Generate sample data
    generate_data.generate_data()

    logger.info("Database initialization completed.")

async def initialize_intelligence_module():
    """Initialize the intelligence module."""
    logger.info("Initializing intelligence module...")

    # Create intelligence module
    intelligence_module = IntelligenceModule(ollama_model="mistral")

    return intelligence_module

async def initialize_agents():
    """Initialize and connect agents."""
    logger.info("Initializing agents...")

    # Create message bus
    message_bus = MessageBus()

    # Create intelligence module
    intelligence_module = await initialize_intelligence_module()

    # Create coordinator agent
    coordinator = CoordinatorAgent(coordinator_id="main_coordinator")
    coordinator.message_bus = message_bus
    message_bus.register_agent(coordinator.agent_id, coordinator._handle_direct_message)

    # Create store agents
    store_agents = [
        StoreAgent(store_id=1, name="Store 1", location="New York", message_bus=message_bus),
        StoreAgent(store_id=2, name="Store 2", location="Los Angeles", message_bus=message_bus),
        StoreAgent(store_id=3, name="Store 3", location="Chicago", message_bus=message_bus)
    ]

    # Create warehouse agent
    warehouse_agent = WarehouseAgent(warehouse_id=1, name="Central Warehouse", location="Dallas", message_bus=message_bus)

    # Create supplier agents
    supplier_agents = [
        SupplierAgent(supplier_id=1, name="Global Supplies Inc.", lead_time=3, message_bus=message_bus),
        SupplierAgent(supplier_id=2, name="Quality Products Co.", lead_time=5, message_bus=message_bus),
        SupplierAgent(supplier_id=3, name="Premium Goods Ltd.", lead_time=7, message_bus=message_bus)
    ]

    # Create customer agents
    customer_segments = ["Regular", "Premium", "VIP", "New", "Occasional"]
    preferences = ["Electronics", "Clothing", "Groceries", "Home Goods", "Toys", "Sports", "Beauty", "Books"]

    customer_agents = []
    for i in range(1, 11):  # Create 10 customer agents
        segment = random.choice(customer_segments)
        customer_prefs = random.sample(preferences, random.randint(1, 3))  # 1-3 preferences
        customer = CustomerAgent(
            customer_id=i,
            segment=segment,
            preferences=customer_prefs,
            message_bus=message_bus
        )
        customer_agents.append(customer)

    # Register all agents with the coordinator
    for agent in [*store_agents, warehouse_agent, *supplier_agents, *customer_agents]:
        await coordinator.register_agent(agent)

    # Connect agents directly as well (for backward compatibility)
    # Connect stores with warehouse
    for store in store_agents:
        await store.connect(warehouse_agent)
        await warehouse_agent.connect(store)

    # Connect warehouse with suppliers
    for supplier in supplier_agents:
        await warehouse_agent.connect(supplier)
        await supplier.connect(warehouse_agent)

    # Connect stores with customers
    for store in store_agents:
        for customer in customer_agents:
            await store.connect(customer)
            await customer.connect(store)

    logger.info(f"Initialized {len(store_agents)} store agents, 1 warehouse agent, "
               f"{len(supplier_agents)} supplier agents, and {len(customer_agents)} customer agents.")

    return {
        "coordinator": coordinator,
        "stores": store_agents,
        "warehouse": warehouse_agent,
        "suppliers": supplier_agents,
        "customers": customer_agents,
        "message_bus": message_bus,
        "intelligence_module": intelligence_module
    }

async def run_simulation(agents, duration=60, use_simulation_env=True):
    """Run the simulation for a specified duration (in seconds)."""
    # Get simulation duration from environment variable if available
    env_duration = os.getenv("SIMULATION_DURATION")
    if env_duration:
        try:
            duration = int(env_duration)
        except ValueError:
            logger.warning(f"Invalid SIMULATION_DURATION value: {env_duration}. Using default: {duration}")

    logger.info(f"Starting simulation for {duration} seconds...")

    if use_simulation_env:
        # Use the simulation environment
        from src.simulation.simulation_environment import SimulationEnvironment

        # Create configuration
        config = {
            "num_stores": len(agents["stores"]),
            "num_suppliers": len(agents["suppliers"]),
            "num_customers": len(agents["customers"]),
            "num_products": 20,  # Default value
            "time_acceleration": 1,
            "use_intelligence_module": "intelligence_module" in agents and agents["intelligence_module"] is not None,
            "ollama_model": "mistral"
        }

        # Create simulation environment
        simulation = SimulationEnvironment(config)

        # Initialize simulation
        await simulation.initialize()

        # Run simulation
        await simulation.run(duration)

        # Generate report
        report = simulation.generate_report()
        logger.info(f"Simulation completed with {report['num_agents']['stores']} stores, {report['num_agents']['suppliers']} suppliers")

        return report
    else:
        # Use the basic simulation approach
        # Start agent tasks
        tasks = []

        # Start coordinator first
        coordinator = agents["coordinator"]
        coordinator_task = asyncio.create_task(coordinator.run())
        tasks.append(coordinator_task)

        # Start store agents
        for store in agents["stores"]:
            tasks.append(asyncio.create_task(store.run()))

        # Start warehouse agent
        tasks.append(asyncio.create_task(agents["warehouse"].run()))

        # Start supplier agents
        for supplier in agents["suppliers"]:
            tasks.append(asyncio.create_task(supplier.run()))

        # Start customer agents
        for customer in agents["customers"]:
            tasks.append(asyncio.create_task(customer.run()))

        logger.info(f"Started {len(tasks)} agent tasks")

        # Run for specified duration
        try:
            await asyncio.sleep(duration)
        except asyncio.CancelledError:
            logger.info("Simulation cancelled")
        finally:
            # Cancel all tasks
            for task in tasks:
                if not task.done():
                    task.cancel()

            # Wait for tasks to be cancelled
            await asyncio.gather(*tasks, return_exceptions=True)

            logger.info("Simulation completed.")

            return None

def start_dashboard_thread(message_bus):
    """Start the dashboard in a separate thread."""
    try:
        # Set up the message bus for the dashboard
        setup_message_bus(message_bus)

        # Start the dashboard server
        start_dashboard()
    except Exception as e:
        logger.error(f"Error in dashboard thread: {e}", exc_info=True)

async def main():
    """Main function to run the retail inventory optimization system."""
    try:
        # Parse command line arguments
        parser = argparse.ArgumentParser(description="Run retail inventory optimization system")
        parser.add_argument("--duration", type=int, default=60, help="Simulation duration in seconds")
        parser.add_argument("--no-intelligence", action="store_true", help="Disable intelligence module")
        parser.add_argument("--basic-sim", action="store_true", help="Use basic simulation instead of simulation environment")
        parser.add_argument("--config", type=str, help="Path to simulation configuration file")

        args = parser.parse_args()

        # Initialize database
        await initialize_database()

        # Initialize agents
        agents = await initialize_agents()

        # Start dashboard in a separate thread
        dashboard_thread = threading.Thread(
            target=start_dashboard_thread,
            args=(agents["message_bus"],),
            daemon=True
        )
        dashboard_thread.start()
        logger.info("Dashboard started on http://localhost:8000")

        # Load configuration if provided
        config = None
        if args.config:
            try:
                with open(args.config, 'r') as f:
                    config = json.load(f)
                logger.info(f"Loaded configuration from {args.config}")
            except Exception as e:
                logger.error(f"Error loading configuration: {e}")

        # Run simulation
        simulation_result = await run_simulation(
            agents=agents,
            duration=args.duration,
            use_simulation_env=not args.basic_sim
        )

        if simulation_result:
            # Print summary of simulation results
            print("\n=== Simulation Results ===")
            print(f"Duration: {simulation_result.get('duration', args.duration):.2f} seconds")
            print(f"Agents: {simulation_result.get('num_agents', {}).get('stores', 0)} stores, "
                  f"{simulation_result.get('num_agents', {}).get('suppliers', 0)} suppliers")

            if 'sales_summary' in simulation_result and 'total_revenue' in simulation_result['sales_summary']:
                print(f"Total sales: ${simulation_result['sales_summary']['total_revenue']:.2f}")

            if 'inventory_summary' in simulation_result and 'warehouse' in simulation_result['inventory_summary']:
                print(f"Warehouse stockouts: {simulation_result['inventory_summary']['warehouse']['stockouts']}")

    except Exception as e:
        logger.error(f"Error in main function: {e}", exc_info=True)

if __name__ == "__main__":
    asyncio.run(main())
