import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

class PerformanceMetrics:
    """
    Class for calculating and analyzing performance metrics from simulation data.
    """
    
    def __init__(self, simulation_data: Dict[str, Any] = None):
        """
        Initialize the performance metrics calculator.
        
        Args:
            simulation_data: Dictionary containing simulation data.
        """
        self.simulation_data = simulation_data or {}
        self.metrics = {}
        
        # Create data directory if it doesn't exist
        os.makedirs("data/evaluation", exist_ok=True)
    
    def load_data(self, data_path: str) -> None:
        """
        Load simulation data from CSV files.
        
        Args:
            data_path: Path to the directory containing simulation data files.
        """
        try:
            # Load inventory data
            inventory_files = list(Path(data_path).glob("inventory_*.csv"))
            if inventory_files:
                self.simulation_data["inventory_levels"] = pd.read_csv(inventory_files[-1])
            
            # Load sales data
            sales_files = list(Path(data_path).glob("sales_*.csv"))
            if sales_files:
                self.simulation_data["sales"] = pd.read_csv(sales_files[-1])
            
            # Load orders data
            orders_files = list(Path(data_path).glob("orders_*.csv"))
            if orders_files:
                self.simulation_data["orders"] = pd.read_csv(orders_files[-1])
            
            # Load metrics data
            metrics_files = list(Path(data_path).glob("metrics_*.csv"))
            if metrics_files:
                self.simulation_data["metrics"] = pd.read_csv(metrics_files[-1])
            
            # Load products data
            products_files = list(Path(data_path).glob("products_*.csv"))
            if products_files:
                self.simulation_data["products"] = pd.read_csv(products_files[-1])
            
            logger.info(f"Loaded simulation data from {data_path}")
        except Exception as e:
            logger.error(f"Error loading simulation data: {e}")
    
    def calculate_inventory_metrics(self) -> Dict[str, Any]:
        """
        Calculate inventory-related metrics.
        
        Returns:
            Dictionary with inventory metrics.
        """
        inventory_metrics = {}
        
        if "inventory_levels" not in self.simulation_data:
            logger.warning("No inventory data available for metrics calculation")
            return inventory_metrics
        
        inventory_df = self.simulation_data["inventory_levels"]
        
        # Convert timestamp to datetime
        if "timestamp" in inventory_df.columns:
            inventory_df["timestamp"] = pd.to_datetime(inventory_df["timestamp"])
        
        # Calculate metrics by agent type
        for agent_type in inventory_df["agent_type"].unique():
            agent_inventory = inventory_df[inventory_df["agent_type"] == agent_type]
            
            # Calculate average inventory levels
            avg_inventory = agent_inventory.groupby("agent_id")["quantity"].mean().reset_index()
            avg_inventory.columns = ["agent_id", "avg_inventory"]
            
            # Calculate stockout frequency
            stockout_counts = agent_inventory[agent_inventory["quantity"] == 0].groupby("agent_id").size().reset_index()
            stockout_counts.columns = ["agent_id", "stockout_count"]
            
            # Calculate total observations per agent
            total_obs = agent_inventory.groupby("agent_id").size().reset_index()
            total_obs.columns = ["agent_id", "total_observations"]
            
            # Merge metrics
            agent_metrics = pd.merge(avg_inventory, stockout_counts, on="agent_id", how="left")
            agent_metrics = pd.merge(agent_metrics, total_obs, on="agent_id", how="left")
            
            # Fill NaN values
            agent_metrics["stockout_count"] = agent_metrics["stockout_count"].fillna(0)
            
            # Calculate stockout rate
            agent_metrics["stockout_rate"] = agent_metrics["stockout_count"] / agent_metrics["total_observations"]
            
            # Convert to dictionary
            agent_metrics_dict = {
                row["agent_id"]: {
                    "avg_inventory": row["avg_inventory"],
                    "stockout_count": row["stockout_count"],
                    "stockout_rate": row["stockout_rate"],
                    "total_observations": row["total_observations"]
                }
                for _, row in agent_metrics.iterrows()
            }
            
            inventory_metrics[agent_type] = agent_metrics_dict
        
        # Calculate overall metrics
        inventory_metrics["overall"] = {
            "avg_inventory": inventory_df["quantity"].mean(),
            "stockout_rate": len(inventory_df[inventory_df["quantity"] == 0]) / len(inventory_df),
            "total_observations": len(inventory_df)
        }
        
        return inventory_metrics
    
    def calculate_sales_metrics(self) -> Dict[str, Any]:
        """
        Calculate sales-related metrics.
        
        Returns:
            Dictionary with sales metrics.
        """
        sales_metrics = {}
        
        if "sales" not in self.simulation_data:
            logger.warning("No sales data available for metrics calculation")
            return sales_metrics
        
        sales_df = self.simulation_data["sales"]
        
        # Convert date to datetime
        if "date" in sales_df.columns:
            sales_df["date"] = pd.to_datetime(sales_df["date"])
        
        # Calculate total sales
        sales_metrics["total"] = {
            "quantity": int(sales_df["quantity"].sum()),
            "revenue": float(sales_df["price"].sum())
        }
        
        # Calculate sales by store
        if "store_id" in sales_df.columns:
            store_sales = sales_df.groupby("store_id").agg({
                "quantity": "sum",
                "price": "sum"
            }).reset_index()
            
            sales_metrics["by_store"] = {
                row["store_id"]: {
                    "quantity": int(row["quantity"]),
                    "revenue": float(row["price"])
                }
                for _, row in store_sales.iterrows()
            }
        
        # Calculate sales by product
        if "product_id" in sales_df.columns:
            product_sales = sales_df.groupby("product_id").agg({
                "quantity": "sum",
                "price": "sum"
            }).reset_index()
            
            sales_metrics["by_product"] = {
                row["product_id"]: {
                    "quantity": int(row["quantity"]),
                    "revenue": float(row["price"])
                }
                for _, row in product_sales.iterrows()
            }
        
        # Calculate sales over time (daily)
        if "date" in sales_df.columns:
            sales_df["date_only"] = sales_df["date"].dt.date
            daily_sales = sales_df.groupby("date_only").agg({
                "quantity": "sum",
                "price": "sum"
            }).reset_index()
            
            sales_metrics["daily"] = {
                str(row["date_only"]): {
                    "quantity": int(row["quantity"]),
                    "revenue": float(row["price"])
                }
                for _, row in daily_sales.iterrows()
            }
        
        return sales_metrics
    
    def calculate_order_metrics(self) -> Dict[str, Any]:
        """
        Calculate order-related metrics.
        
        Returns:
            Dictionary with order metrics.
        """
        order_metrics = {}
        
        if "orders" not in self.simulation_data:
            logger.warning("No order data available for metrics calculation")
            return order_metrics
        
        orders_df = self.simulation_data["orders"]
        
        # Calculate order status counts
        if "status" in orders_df.columns:
            status_counts = orders_df["status"].value_counts().to_dict()
            order_metrics["status_counts"] = status_counts
        
        # Calculate orders by supplier
        if "supplier_id" in orders_df.columns:
            supplier_orders = orders_df.groupby("supplier_id").size().to_dict()
            order_metrics["by_supplier"] = supplier_orders
        
        # Calculate lead times if possible
        if "order_date" in orders_df.columns and "estimated_delivery_date" in orders_df.columns:
            orders_df["order_date"] = pd.to_datetime(orders_df["order_date"])
            orders_df["estimated_delivery_date"] = pd.to_datetime(orders_df["estimated_delivery_date"])
            
            # Calculate lead time in days
            orders_df["lead_time"] = (orders_df["estimated_delivery_date"] - orders_df["order_date"]).dt.days
            
            # Calculate average lead time
            order_metrics["avg_lead_time"] = float(orders_df["lead_time"].mean())
            
            # Calculate lead time by supplier
            supplier_lead_times = orders_df.groupby("supplier_id")["lead_time"].mean().to_dict()
            order_metrics["lead_time_by_supplier"] = supplier_lead_times
        
        return order_metrics
    
    def calculate_agent_performance_metrics(self) -> Dict[str, Any]:
        """
        Calculate agent performance metrics.
        
        Returns:
            Dictionary with agent performance metrics.
        """
        performance_metrics = {}
        
        if "metrics" not in self.simulation_data:
            logger.warning("No performance metrics data available")
            return performance_metrics
        
        metrics_df = self.simulation_data["metrics"]
        
        # Convert timestamp to datetime
        if "timestamp" in metrics_df.columns:
            metrics_df["timestamp"] = pd.to_datetime(metrics_df["timestamp"])
        
        # Calculate latest metrics by agent type
        for agent_type in metrics_df["agent_type"].unique():
            agent_metrics = metrics_df[metrics_df["agent_type"] == agent_type]
            
            # Get the latest timestamp
            latest_timestamp = agent_metrics["timestamp"].max()
            latest_metrics = agent_metrics[agent_metrics["timestamp"] == latest_timestamp]
            
            # Group by agent_id and metric
            agent_metrics_pivot = latest_metrics.pivot_table(
                index="agent_id",
                columns="metric",
                values="value",
                aggfunc="first"
            ).reset_index()
            
            # Convert to dictionary
            agent_metrics_dict = {}
            for _, row in agent_metrics_pivot.iterrows():
                agent_id = row["agent_id"]
                agent_metrics_dict[agent_id] = {
                    col: row[col] for col in agent_metrics_pivot.columns if col != "agent_id"
                }
            
            performance_metrics[agent_type] = agent_metrics_dict
        
        return performance_metrics
    
    def calculate_all_metrics(self) -> Dict[str, Any]:
        """
        Calculate all performance metrics.
        
        Returns:
            Dictionary with all metrics.
        """
        self.metrics = {
            "inventory": self.calculate_inventory_metrics(),
            "sales": self.calculate_sales_metrics(),
            "orders": self.calculate_order_metrics(),
            "agent_performance": self.calculate_agent_performance_metrics()
        }
        
        return self.metrics
    
    def calculate_kpis(self) -> Dict[str, float]:
        """
        Calculate key performance indicators (KPIs).
        
        Returns:
            Dictionary with KPIs.
        """
        kpis = {}
        
        # Ensure metrics are calculated
        if not self.metrics:
            self.calculate_all_metrics()
        
        # Inventory turnover
        if "inventory" in self.metrics and "sales" in self.metrics:
            if "overall" in self.metrics["inventory"] and "total" in self.metrics["sales"]:
                avg_inventory = self.metrics["inventory"]["overall"]["avg_inventory"]
                total_sales = self.metrics["sales"]["total"]["quantity"]
                
                if avg_inventory > 0:
                    kpis["inventory_turnover"] = total_sales / avg_inventory
        
        # Stockout rate
        if "inventory" in self.metrics and "overall" in self.metrics["inventory"]:
            kpis["stockout_rate"] = self.metrics["inventory"]["overall"]["stockout_rate"]
        
        # Order fill rate
        if "orders" in self.metrics and "status_counts" in self.metrics["orders"]:
            status_counts = self.metrics["orders"]["status_counts"]
            fulfilled = status_counts.get("delivered", 0) + status_counts.get("shipped", 0)
            total_orders = sum(status_counts.values())
            
            if total_orders > 0:
                kpis["order_fill_rate"] = fulfilled / total_orders
        
        # Average lead time
        if "orders" in self.metrics and "avg_lead_time" in self.metrics["orders"]:
            kpis["avg_lead_time"] = self.metrics["orders"]["avg_lead_time"]
        
        # Sales performance
        if "sales" in self.metrics and "total" in self.metrics["sales"]:
            kpis["total_sales_quantity"] = self.metrics["sales"]["total"]["quantity"]
            kpis["total_sales_revenue"] = self.metrics["sales"]["total"]["revenue"]
        
        # Store performance
        if "sales" in self.metrics and "by_store" in self.metrics["sales"]:
            store_revenues = [store["revenue"] for store in self.metrics["sales"]["by_store"].values()]
            if store_revenues:
                kpis["avg_store_revenue"] = sum(store_revenues) / len(store_revenues)
                kpis["revenue_variance"] = np.var(store_revenues) if len(store_revenues) > 1 else 0
        
        return kpis
    
    def compare_scenarios(self, other_metrics: Dict[str, Any], scenario_name: str = "baseline", other_name: str = "comparison") -> Dict[str, Any]:
        """
        Compare metrics between two scenarios.
        
        Args:
            other_metrics: Metrics from another scenario.
            scenario_name: Name of the current scenario.
            other_name: Name of the other scenario.
            
        Returns:
            Dictionary with comparison results.
        """
        comparison = {}
        
        # Ensure metrics are calculated
        if not self.metrics:
            self.calculate_all_metrics()
        
        # Compare KPIs
        self_kpis = self.calculate_kpis()
        other_kpis = PerformanceMetrics().metrics = other_metrics
        other_kpis = PerformanceMetrics().calculate_kpis()
        
        kpi_comparison = {}
        for kpi, value in self_kpis.items():
            if kpi in other_kpis:
                other_value = other_kpis[kpi]
                pct_change = ((value - other_value) / other_value) * 100 if other_value != 0 else float('inf')
                
                kpi_comparison[kpi] = {
                    scenario_name: value,
                    other_name: other_value,
                    "absolute_diff": value - other_value,
                    "percent_change": pct_change
                }
        
        comparison["kpis"] = kpi_comparison
        
        # Compare inventory metrics
        if "inventory" in self.metrics and "inventory" in other_metrics:
            inventory_comparison = {}
            
            # Compare overall metrics
            if "overall" in self.metrics["inventory"] and "overall" in other_metrics["inventory"]:
                self_overall = self.metrics["inventory"]["overall"]
                other_overall = other_metrics["inventory"]["overall"]
                
                overall_comparison = {}
                for metric, value in self_overall.items():
                    if metric in other_overall:
                        other_value = other_overall[metric]
                        pct_change = ((value - other_value) / other_value) * 100 if other_value != 0 else float('inf')
                        
                        overall_comparison[metric] = {
                            scenario_name: value,
                            other_name: other_value,
                            "absolute_diff": value - other_value,
                            "percent_change": pct_change
                        }
                
                inventory_comparison["overall"] = overall_comparison
            
            comparison["inventory"] = inventory_comparison
        
        # Compare sales metrics
        if "sales" in self.metrics and "sales" in other_metrics:
            sales_comparison = {}
            
            # Compare total sales
            if "total" in self.metrics["sales"] and "total" in other_metrics["sales"]:
                self_total = self.metrics["sales"]["total"]
                other_total = other_metrics["sales"]["total"]
                
                total_comparison = {}
                for metric, value in self_total.items():
                    if metric in other_total:
                        other_value = other_total[metric]
                        pct_change = ((value - other_value) / other_value) * 100 if other_value != 0 else float('inf')
                        
                        total_comparison[metric] = {
                            scenario_name: value,
                            other_name: other_value,
                            "absolute_diff": value - other_value,
                            "percent_change": pct_change
                        }
                
                sales_comparison["total"] = total_comparison
            
            comparison["sales"] = sales_comparison
        
        return comparison
    
    def save_metrics(self, output_path: str = "data/evaluation/metrics.json") -> None:
        """
        Save metrics to a JSON file.
        
        Args:
            output_path: Path to save the metrics.
        """
        import json
        
        # Ensure metrics are calculated
        if not self.metrics:
            self.calculate_all_metrics()
        
        # Convert numpy values to Python native types
        def convert_numpy(obj):
            if isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, dict):
                return {k: convert_numpy(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_numpy(i) for i in obj]
            else:
                return obj
        
        metrics_json = convert_numpy(self.metrics)
        
        try:
            with open(output_path, 'w') as f:
                json.dump(metrics_json, f, indent=2)
            
            logger.info(f"Saved metrics to {output_path}")
        except Exception as e:
            logger.error(f"Error saving metrics: {e}")
    
    def generate_report(self, output_path: str = "data/evaluation/report.md") -> None:
        """
        Generate a Markdown report of the metrics.
        
        Args:
            output_path: Path to save the report.
        """
        # Ensure metrics are calculated
        if not self.metrics:
            self.calculate_all_metrics()
        
        # Calculate KPIs
        kpis = self.calculate_kpis()
        
        # Generate report
        report = []
        report.append("# Simulation Performance Report\n")
        report.append(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        # Add KPIs section
        report.append("## Key Performance Indicators (KPIs)\n")
        for kpi, value in kpis.items():
            report.append(f"- **{kpi.replace('_', ' ').title()}**: {value:.4f}")
        report.append("\n")
        
        # Add inventory metrics section
        report.append("## Inventory Metrics\n")
        if "inventory" in self.metrics and "overall" in self.metrics["inventory"]:
            overall = self.metrics["inventory"]["overall"]
            report.append("### Overall Inventory Metrics\n")
            report.append(f"- **Average Inventory**: {overall['avg_inventory']:.2f}")
            report.append(f"- **Stockout Rate**: {overall['stockout_rate']:.4f}")
            report.append(f"- **Total Observations**: {overall['total_observations']}")
            report.append("\n")
        
        if "inventory" in self.metrics and "store" in self.metrics["inventory"]:
            report.append("### Store Inventory Metrics\n")
            report.append("| Store ID | Avg Inventory | Stockout Rate | Stockout Count |\n")
            report.append("|----------|--------------|---------------|---------------|\n")
            
            for store_id, metrics in self.metrics["inventory"]["store"].items():
                report.append(f"| {store_id} | {metrics['avg_inventory']:.2f} | {metrics['stockout_rate']:.4f} | {metrics['stockout_count']} |")
            report.append("\n")
        
        # Add sales metrics section
        report.append("## Sales Metrics\n")
        if "sales" in self.metrics and "total" in self.metrics["sales"]:
            total = self.metrics["sales"]["total"]
            report.append("### Total Sales\n")
            report.append(f"- **Quantity**: {total['quantity']}")
            report.append(f"- **Revenue**: ${total['revenue']:.2f}")
            report.append("\n")
        
        if "sales" in self.metrics and "by_store" in self.metrics["sales"]:
            report.append("### Sales by Store\n")
            report.append("| Store ID | Quantity | Revenue |\n")
            report.append("|----------|----------|--------|\n")
            
            for store_id, metrics in self.metrics["sales"]["by_store"].items():
                report.append(f"| {store_id} | {metrics['quantity']} | ${metrics['revenue']:.2f} |")
            report.append("\n")
        
        if "sales" in self.metrics and "by_product" in self.metrics["sales"]:
            report.append("### Sales by Product\n")
            report.append("| Product ID | Quantity | Revenue |\n")
            report.append("|------------|----------|--------|\n")
            
            for product_id, metrics in self.metrics["sales"]["by_product"].items():
                report.append(f"| {product_id} | {metrics['quantity']} | ${metrics['revenue']:.2f} |")
            report.append("\n")
        
        # Add order metrics section
        report.append("## Order Metrics\n")
        if "orders" in self.metrics and "status_counts" in self.metrics["orders"]:
            status_counts = self.metrics["orders"]["status_counts"]
            report.append("### Order Status Counts\n")
            for status, count in status_counts.items():
                report.append(f"- **{status.title()}**: {count}")
            report.append("\n")
        
        if "orders" in self.metrics and "avg_lead_time" in self.metrics["orders"]:
            report.append(f"### Average Lead Time: {self.metrics['orders']['avg_lead_time']:.2f} days\n")
        
        if "orders" in self.metrics and "lead_time_by_supplier" in self.metrics["orders"]:
            report.append("### Lead Time by Supplier\n")
            report.append("| Supplier ID | Avg Lead Time (days) |\n")
            report.append("|-------------|----------------------|\n")
            
            for supplier_id, lead_time in self.metrics["orders"]["lead_time_by_supplier"].items():
                report.append(f"| {supplier_id} | {lead_time:.2f} |")
            report.append("\n")
        
        # Add agent performance metrics section
        report.append("## Agent Performance Metrics\n")
        if "agent_performance" in self.metrics:
            for agent_type, agents in self.metrics["agent_performance"].items():
                report.append(f"### {agent_type.title()} Agent Metrics\n")
                
                # Get all metrics
                all_metrics = set()
                for agent_metrics in agents.values():
                    all_metrics.update(agent_metrics.keys())
                
                # Create table header
                report.append(f"| Agent ID | {' | '.join(all_metrics)} |\n")
                report.append(f"|----------|{'-|' * len(all_metrics)}\n")
                
                # Add agent metrics
                for agent_id, agent_metrics in agents.items():
                    metrics_values = []
                    for metric in all_metrics:
                        value = agent_metrics.get(metric, "N/A")
                        if isinstance(value, (int, float)):
                            metrics_values.append(f"{value:.4f}")
                        else:
                            metrics_values.append(str(value))
                    
                    report.append(f"| {agent_id} | {' | '.join(metrics_values)} |")
                report.append("\n")
        
        # Write report to file
        try:
            with open(output_path, 'w') as f:
                f.write("\n".join(report))
            
            logger.info(f"Generated report at {output_path}")
        except Exception as e:
            logger.error(f"Error generating report: {e}")
