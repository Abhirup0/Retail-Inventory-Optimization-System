import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Any, Optional, Tuple
import logging
import os
from pathlib import Path
import json

logger = logging.getLogger(__name__)

class MetricsVisualizer:
    """
    Class for visualizing performance metrics from simulation data.
    """
    
    def __init__(self, metrics_data: Dict[str, Any] = None, simulation_data: Dict[str, Any] = None):
        """
        Initialize the metrics visualizer.
        
        Args:
            metrics_data: Dictionary containing calculated metrics.
            simulation_data: Dictionary containing raw simulation data.
        """
        self.metrics_data = metrics_data or {}
        self.simulation_data = simulation_data or {}
        
        # Set up plotting style
        sns.set_style("whitegrid")
        plt.rcParams["figure.figsize"] = (12, 8)
        plt.rcParams["font.size"] = 12
        
        # Create output directory if it doesn't exist
        os.makedirs("data/evaluation/visualizations", exist_ok=True)
    
    def load_metrics(self, metrics_path: str) -> None:
        """
        Load metrics data from a JSON file.
        
        Args:
            metrics_path: Path to the metrics JSON file.
        """
        try:
            with open(metrics_path, 'r') as f:
                self.metrics_data = json.load(f)
            
            logger.info(f"Loaded metrics data from {metrics_path}")
        except Exception as e:
            logger.error(f"Error loading metrics data: {e}")
    
    def load_simulation_data(self, data_path: str) -> None:
        """
        Load simulation data from CSV files.
        
        Args:
            data_path: Path to the directory containing simulation data files.
        """
        try:
            # Load inventory data
            inventory_files = list(Path(data_path).glob("inventory_*.csv"))
            if inventory_files:
                self.simulation_data["inventory_levels"] = pd.read_csv(inventory_files[-1])
            
            # Load sales data
            sales_files = list(Path(data_path).glob("sales_*.csv"))
            if sales_files:
                self.simulation_data["sales"] = pd.read_csv(sales_files[-1])
            
            # Load orders data
            orders_files = list(Path(data_path).glob("orders_*.csv"))
            if orders_files:
                self.simulation_data["orders"] = pd.read_csv(orders_files[-1])
            
            # Load metrics data
            metrics_files = list(Path(data_path).glob("metrics_*.csv"))
            if metrics_files:
                self.simulation_data["metrics"] = pd.read_csv(metrics_files[-1])
            
            # Load products data
            products_files = list(Path(data_path).glob("products_*.csv"))
            if products_files:
                self.simulation_data["products"] = pd.read_csv(products_files[-1])
            
            logger.info(f"Loaded simulation data from {data_path}")
        except Exception as e:
            logger.error(f"Error loading simulation data: {e}")
    
    def plot_inventory_levels(self, save_path: Optional[str] = None) -> None:
        """
        Plot inventory levels over time.
        
        Args:
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        if "inventory_levels" not in self.simulation_data:
            logger.warning("No inventory data available for plotting")
            return
        
        inventory_df = self.simulation_data["inventory_levels"]
        
        # Convert timestamp to datetime
        if "timestamp" in inventory_df.columns:
            inventory_df["timestamp"] = pd.to_datetime(inventory_df["timestamp"])
        
        # Create figure
        plt.figure(figsize=(14, 10))
        
        # Plot inventory levels by agent type
        for agent_type in inventory_df["agent_type"].unique():
            agent_inventory = inventory_df[inventory_df["agent_type"] == agent_type]
            
            # Calculate average inventory across all agents of this type
            avg_inventory = agent_inventory.groupby(["timestamp", "product_id"])["quantity"].mean().reset_index()
            
            # Plot for each product
            for product_id in avg_inventory["product_id"].unique():
                product_inventory = avg_inventory[avg_inventory["product_id"] == product_id]
                plt.plot(
                    product_inventory["timestamp"],
                    product_inventory["quantity"],
                    label=f"{agent_type.title()} - Product {product_id}"
                )
        
        plt.title("Inventory Levels Over Time")
        plt.xlabel("Time")
        plt.ylabel("Quantity")
        plt.legend(loc="best")
        plt.grid(True)
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved inventory levels plot to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def plot_stockout_rates(self, save_path: Optional[str] = None) -> None:
        """
        Plot stockout rates by agent.
        
        Args:
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        if "inventory" not in self.metrics_data:
            logger.warning("No inventory metrics available for plotting")
            return
        
        # Extract stockout rates
        stockout_data = []
        
        for agent_type, agents in self.metrics_data["inventory"].items():
            if agent_type == "overall":
                continue
            
            for agent_id, metrics in agents.items():
                stockout_data.append({
                    "agent_type": agent_type,
                    "agent_id": agent_id,
                    "stockout_rate": metrics.get("stockout_rate", 0)
                })
        
        if not stockout_data:
            logger.warning("No stockout data available for plotting")
            return
        
        # Convert to DataFrame
        stockout_df = pd.DataFrame(stockout_data)
        
        # Create figure
        plt.figure(figsize=(12, 8))
        
        # Plot stockout rates
        ax = sns.barplot(x="agent_id", y="stockout_rate", hue="agent_type", data=stockout_df)
        
        plt.title("Stockout Rates by Agent")
        plt.xlabel("Agent ID")
        plt.ylabel("Stockout Rate")
        plt.legend(title="Agent Type")
        plt.grid(True, axis="y")
        
        # Add value labels
        for p in ax.patches:
            ax.annotate(
                f"{p.get_height():.4f}",
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha="center",
                va="bottom",
                fontsize=8,
                rotation=0
            )
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved stockout rates plot to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def plot_sales_by_store(self, save_path: Optional[str] = None) -> None:
        """
        Plot sales by store.
        
        Args:
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        if "sales" not in self.metrics_data or "by_store" not in self.metrics_data["sales"]:
            logger.warning("No sales by store metrics available for plotting")
            return
        
        # Extract sales data
        sales_data = []
        
        for store_id, metrics in self.metrics_data["sales"]["by_store"].items():
            sales_data.append({
                "store_id": store_id,
                "quantity": metrics.get("quantity", 0),
                "revenue": metrics.get("revenue", 0)
            })
        
        if not sales_data:
            logger.warning("No sales data available for plotting")
            return
        
        # Convert to DataFrame
        sales_df = pd.DataFrame(sales_data)
        
        # Create figure with two subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
        
        # Plot quantity
        sns.barplot(x="store_id", y="quantity", data=sales_df, ax=ax1, color="skyblue")
        ax1.set_title("Sales Quantity by Store")
        ax1.set_xlabel("Store ID")
        ax1.set_ylabel("Quantity")
        ax1.grid(True, axis="y")
        
        # Add value labels
        for p in ax1.patches:
            ax1.annotate(
                f"{int(p.get_height())}",
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha="center",
                va="bottom",
                fontsize=10,
                rotation=0
            )
        
        # Plot revenue
        sns.barplot(x="store_id", y="revenue", data=sales_df, ax=ax2, color="lightgreen")
        ax2.set_title("Sales Revenue by Store")
        ax2.set_xlabel("Store ID")
        ax2.set_ylabel("Revenue ($)")
        ax2.grid(True, axis="y")
        
        # Add value labels
        for p in ax2.patches:
            ax2.annotate(
                f"${p.get_height():.2f}",
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha="center",
                va="bottom",
                fontsize=10,
                rotation=0
            )
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved sales by store plot to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def plot_sales_by_product(self, save_path: Optional[str] = None) -> None:
        """
        Plot sales by product.
        
        Args:
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        if "sales" not in self.metrics_data or "by_product" not in self.metrics_data["sales"]:
            logger.warning("No sales by product metrics available for plotting")
            return
        
        # Extract sales data
        sales_data = []
        
        for product_id, metrics in self.metrics_data["sales"]["by_product"].items():
            sales_data.append({
                "product_id": product_id,
                "quantity": metrics.get("quantity", 0),
                "revenue": metrics.get("revenue", 0)
            })
        
        if not sales_data:
            logger.warning("No sales data available for plotting")
            return
        
        # Convert to DataFrame
        sales_df = pd.DataFrame(sales_data)
        
        # Sort by revenue
        sales_df = sales_df.sort_values("revenue", ascending=False)
        
        # Create figure with two subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
        
        # Plot quantity
        sns.barplot(x="product_id", y="quantity", data=sales_df, ax=ax1, color="skyblue", order=sales_df["product_id"])
        ax1.set_title("Sales Quantity by Product")
        ax1.set_xlabel("Product ID")
        ax1.set_ylabel("Quantity")
        ax1.grid(True, axis="y")
        
        # Add value labels
        for p in ax1.patches:
            ax1.annotate(
                f"{int(p.get_height())}",
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha="center",
                va="bottom",
                fontsize=10,
                rotation=0
            )
        
        # Plot revenue
        sns.barplot(x="product_id", y="revenue", data=sales_df, ax=ax2, color="lightgreen", order=sales_df["product_id"])
        ax2.set_title("Sales Revenue by Product")
        ax2.set_xlabel("Product ID")
        ax2.set_ylabel("Revenue ($)")
        ax2.grid(True, axis="y")
        
        # Add value labels
        for p in ax2.patches:
            ax2.annotate(
                f"${p.get_height():.2f}",
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha="center",
                va="bottom",
                fontsize=10,
                rotation=0
            )
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved sales by product plot to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def plot_sales_over_time(self, save_path: Optional[str] = None) -> None:
        """
        Plot sales over time.
        
        Args:
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        if "sales" not in self.metrics_data or "daily" not in self.metrics_data["sales"]:
            logger.warning("No daily sales metrics available for plotting")
            return
        
        # Extract sales data
        sales_data = []
        
        for date_str, metrics in self.metrics_data["sales"]["daily"].items():
            sales_data.append({
                "date": pd.to_datetime(date_str),
                "quantity": metrics.get("quantity", 0),
                "revenue": metrics.get("revenue", 0)
            })
        
        if not sales_data:
            logger.warning("No sales data available for plotting")
            return
        
        # Convert to DataFrame
        sales_df = pd.DataFrame(sales_data)
        
        # Sort by date
        sales_df = sales_df.sort_values("date")
        
        # Create figure with two subplots
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 12), sharex=True)
        
        # Plot quantity
        ax1.plot(sales_df["date"], sales_df["quantity"], marker="o", linestyle="-", color="blue")
        ax1.set_title("Sales Quantity Over Time")
        ax1.set_ylabel("Quantity")
        ax1.grid(True)
        
        # Plot revenue
        ax2.plot(sales_df["date"], sales_df["revenue"], marker="o", linestyle="-", color="green")
        ax2.set_title("Sales Revenue Over Time")
        ax2.set_xlabel("Date")
        ax2.set_ylabel("Revenue ($)")
        ax2.grid(True)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved sales over time plot to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def plot_order_status(self, save_path: Optional[str] = None) -> None:
        """
        Plot order status distribution.
        
        Args:
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        if "orders" not in self.metrics_data or "status_counts" not in self.metrics_data["orders"]:
            logger.warning("No order status metrics available for plotting")
            return
        
        # Extract order status data
        status_counts = self.metrics_data["orders"]["status_counts"]
        
        if not status_counts:
            logger.warning("No order status data available for plotting")
            return
        
        # Convert to DataFrame
        status_df = pd.DataFrame([
            {"status": status, "count": count}
            for status, count in status_counts.items()
        ])
        
        # Create figure
        plt.figure(figsize=(10, 8))
        
        # Plot order status
        ax = sns.barplot(x="status", y="count", data=status_df, palette="viridis")
        
        plt.title("Order Status Distribution")
        plt.xlabel("Status")
        plt.ylabel("Count")
        plt.grid(True, axis="y")
        
        # Add value labels
        for p in ax.patches:
            ax.annotate(
                f"{int(p.get_height())}",
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha="center",
                va="bottom",
                fontsize=10,
                rotation=0
            )
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved order status plot to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def plot_lead_times(self, save_path: Optional[str] = None) -> None:
        """
        Plot lead times by supplier.
        
        Args:
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        if "orders" not in self.metrics_data or "lead_time_by_supplier" not in self.metrics_data["orders"]:
            logger.warning("No lead time metrics available for plotting")
            return
        
        # Extract lead time data
        lead_times = self.metrics_data["orders"]["lead_time_by_supplier"]
        
        if not lead_times:
            logger.warning("No lead time data available for plotting")
            return
        
        # Convert to DataFrame
        lead_time_df = pd.DataFrame([
            {"supplier_id": supplier_id, "lead_time": lead_time}
            for supplier_id, lead_time in lead_times.items()
        ])
        
        # Create figure
        plt.figure(figsize=(10, 8))
        
        # Plot lead times
        ax = sns.barplot(x="supplier_id", y="lead_time", data=lead_time_df, palette="Blues_d")
        
        plt.title("Average Lead Time by Supplier")
        plt.xlabel("Supplier ID")
        plt.ylabel("Lead Time (days)")
        plt.grid(True, axis="y")
        
        # Add value labels
        for p in ax.patches:
            ax.annotate(
                f"{p.get_height():.2f}",
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha="center",
                va="bottom",
                fontsize=10,
                rotation=0
            )
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved lead time plot to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def plot_kpi_dashboard(self, save_path: Optional[str] = None) -> None:
        """
        Plot a dashboard of key performance indicators.
        
        Args:
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        # Calculate KPIs if not available
        if "inventory" not in self.metrics_data or "sales" not in self.metrics_data:
            logger.warning("Metrics data not available for KPI dashboard")
            return
        
        # Create KPI data
        kpi_data = {}
        
        # Inventory turnover
        if "overall" in self.metrics_data["inventory"] and "total" in self.metrics_data["sales"]:
            avg_inventory = self.metrics_data["inventory"]["overall"]["avg_inventory"]
            total_sales = self.metrics_data["sales"]["total"]["quantity"]
            
            if avg_inventory > 0:
                kpi_data["inventory_turnover"] = total_sales / avg_inventory
        
        # Stockout rate
        if "overall" in self.metrics_data["inventory"]:
            kpi_data["stockout_rate"] = self.metrics_data["inventory"]["overall"]["stockout_rate"]
        
        # Order fill rate
        if "orders" in self.metrics_data and "status_counts" in self.metrics_data["orders"]:
            status_counts = self.metrics_data["orders"]["status_counts"]
            fulfilled = status_counts.get("delivered", 0) + status_counts.get("shipped", 0)
            total_orders = sum(status_counts.values())
            
            if total_orders > 0:
                kpi_data["order_fill_rate"] = fulfilled / total_orders
        
        # Average lead time
        if "orders" in self.metrics_data and "avg_lead_time" in self.metrics_data["orders"]:
            kpi_data["avg_lead_time"] = self.metrics_data["orders"]["avg_lead_time"]
        
        # Total sales
        if "total" in self.metrics_data["sales"]:
            kpi_data["total_sales"] = self.metrics_data["sales"]["total"]["quantity"]
            kpi_data["total_revenue"] = self.metrics_data["sales"]["total"]["revenue"]
        
        if not kpi_data:
            logger.warning("No KPI data available for dashboard")
            return
        
        # Create figure with subplots
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # Flatten axes for easier indexing
        axes = axes.flatten()
        
        # Plot KPIs
        kpi_colors = {
            "inventory_turnover": "blue",
            "stockout_rate": "red",
            "order_fill_rate": "green",
            "avg_lead_time": "orange",
            "total_sales": "purple",
            "total_revenue": "teal"
        }
        
        kpi_titles = {
            "inventory_turnover": "Inventory Turnover",
            "stockout_rate": "Stockout Rate",
            "order_fill_rate": "Order Fill Rate",
            "avg_lead_time": "Average Lead Time (days)",
            "total_sales": "Total Sales (units)",
            "total_revenue": "Total Revenue ($)"
        }
        
        # Select KPIs to display
        display_kpis = ["inventory_turnover", "stockout_rate", "order_fill_rate", "avg_lead_time"]
        
        for i, kpi in enumerate(display_kpis):
            if kpi in kpi_data:
                value = kpi_data[kpi]
                ax = axes[i]
                
                # Create gauge chart
                self._plot_gauge(ax, value, title=kpi_titles[kpi], color=kpi_colors[kpi])
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved KPI dashboard to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def _plot_gauge(self, ax, value: float, title: str, color: str, min_val: float = 0, max_val: float = 1) -> None:
        """
        Plot a gauge chart for a KPI.
        
        Args:
            ax: Matplotlib axis to plot on.
            value: Value to display.
            title: Title of the gauge.
            color: Color of the gauge.
            min_val: Minimum value of the gauge.
            max_val: Maximum value of the gauge.
        """
        # Adjust min and max values based on KPI
        if "turnover" in title.lower():
            min_val, max_val = 0, 10
        elif "lead time" in title.lower():
            min_val, max_val = 0, 14
        elif "rate" in title.lower():
            min_val, max_val = 0, 1
        
        # Ensure value is within range
        value = max(min_val, min(value, max_val))
        
        # Calculate angle
        angle = (value - min_val) / (max_val - min_val) * 180
        
        # Create gauge
        ax.set_aspect('equal')
        ax.set_xlim(-1.1, 1.1)
        ax.set_ylim(-1.1, 1.1)
        
        # Draw background
        background = plt.Circle((0, 0), 1, fill=False, linewidth=2)
        ax.add_artist(background)
        
        # Draw colored arc
        theta1 = np.radians(180 - angle)
        theta2 = np.radians(180)
        arc = plt.matplotlib.patches.Arc(
            (0, 0), 2, 2, 0, angle_1=180, angle_2=180-angle,
            linewidth=10, color=color
        )
        ax.add_artist(arc)
        
        # Draw needle
        needle_angle = np.radians(180 - angle)
        x = 0.8 * np.cos(needle_angle)
        y = 0.8 * np.sin(needle_angle)
        ax.plot([0, x], [0, y], color='black', linewidth=2)
        
        # Add center circle
        center = plt.Circle((0, 0), 0.05, color='black')
        ax.add_artist(center)
        
        # Add value text
        ax.text(0, -0.2, f"{value:.4f}", ha='center', va='center', fontsize=24, fontweight='bold')
        
        # Add title
        ax.text(0, 0.7, title, ha='center', va='center', fontsize=16)
        
        # Remove ticks and spines
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)
    
    def plot_comparison(self, other_metrics: Dict[str, Any], scenario_name: str = "baseline", other_name: str = "comparison", save_path: Optional[str] = None) -> None:
        """
        Plot a comparison between two scenarios.
        
        Args:
            other_metrics: Metrics from another scenario.
            scenario_name: Name of the current scenario.
            other_name: Name of the other scenario.
            save_path: Path to save the plot. If None, the plot is displayed.
        """
        # Ensure metrics are available
        if not self.metrics_data:
            logger.warning("No metrics data available for comparison")
            return
        
        # Create comparison data
        from src.evaluation.metrics import PerformanceMetrics
        metrics_calculator = PerformanceMetrics()
        metrics_calculator.metrics = self.metrics_data
        
        comparison = metrics_calculator.compare_scenarios(other_metrics, scenario_name, other_name)
        
        if "kpis" not in comparison:
            logger.warning("No KPI comparison data available")
            return
        
        # Extract KPI comparison data
        kpi_comparison = comparison["kpis"]
        
        # Create DataFrame for plotting
        comparison_data = []
        
        for kpi, values in kpi_comparison.items():
            comparison_data.append({
                "kpi": kpi.replace("_", " ").title(),
                scenario_name: values[scenario_name],
                other_name: values[other_name],
                "percent_change": values["percent_change"]
            })
        
        if not comparison_data:
            logger.warning("No comparison data available for plotting")
            return
        
        comparison_df = pd.DataFrame(comparison_data)
        
        # Create figure with two subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
        
        # Plot absolute values
        comparison_df_melted = pd.melt(
            comparison_df,
            id_vars=["kpi"],
            value_vars=[scenario_name, other_name],
            var_name="scenario",
            value_name="value"
        )
        
        sns.barplot(x="kpi", y="value", hue="scenario", data=comparison_df_melted, ax=ax1)
        ax1.set_title("KPI Comparison - Absolute Values")
        ax1.set_xlabel("KPI")
        ax1.set_ylabel("Value")
        ax1.tick_params(axis='x', rotation=45)
        ax1.legend(title="Scenario")
        ax1.grid(True, axis="y")
        
        # Plot percent change
        colors = ["green" if x >= 0 else "red" for x in comparison_df["percent_change"]]
        sns.barplot(x="kpi", y="percent_change", data=comparison_df, ax=ax2, palette=colors)
        ax2.set_title(f"KPI Comparison - Percent Change ({scenario_name} vs {other_name})")
        ax2.set_xlabel("KPI")
        ax2.set_ylabel("Percent Change (%)")
        ax2.tick_params(axis='x', rotation=45)
        ax2.grid(True, axis="y")
        
        # Add value labels
        for p in ax2.patches:
            ax2.annotate(
                f"{p.get_height():.2f}%",
                (p.get_x() + p.get_width() / 2., p.get_height()),
                ha="center",
                va="bottom" if p.get_height() >= 0 else "top",
                fontsize=10,
                rotation=0
            )
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            logger.info(f"Saved comparison plot to {save_path}")
        else:
            plt.show()
        
        plt.close()
    
    def generate_all_visualizations(self, output_dir: str = "data/evaluation/visualizations") -> None:
        """
        Generate all visualizations and save them to the specified directory.
        
        Args:
            output_dir: Directory to save the visualizations.
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate visualizations
        self.plot_inventory_levels(save_path=f"{output_dir}/inventory_levels.png")
        self.plot_stockout_rates(save_path=f"{output_dir}/stockout_rates.png")
        self.plot_sales_by_store(save_path=f"{output_dir}/sales_by_store.png")
        self.plot_sales_by_product(save_path=f"{output_dir}/sales_by_product.png")
        self.plot_sales_over_time(save_path=f"{output_dir}/sales_over_time.png")
        self.plot_order_status(save_path=f"{output_dir}/order_status.png")
        self.plot_lead_times(save_path=f"{output_dir}/lead_times.png")
        self.plot_kpi_dashboard(save_path=f"{output_dir}/kpi_dashboard.png")
        
        logger.info(f"Generated all visualizations in {output_dir}")
