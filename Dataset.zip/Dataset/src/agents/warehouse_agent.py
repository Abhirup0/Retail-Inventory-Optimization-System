import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import random
import logging
import pandas as pd

from .base_agent import Agent
from src.models.intelligence_module import IntelligenceModule

logger = logging.getLogger(__name__)

class WarehouseAgent(Agent):
    """Agent representing a warehouse that supplies multiple stores."""

    def __init__(self, warehouse_id: int, name: str, location: str, intelligence_module: Optional[IntelligenceModule] = None, message_bus = None):
        """
        Initialize a warehouse agent.

        Args:
            warehouse_id: ID of the warehouse.
            name: Name of the warehouse.
            location: Location of the warehouse.
            intelligence_module: Optional intelligence module for advanced decision-making.
            message_bus: Optional message bus for agent communication.
        """
        super().__init__(agent_id=f"warehouse_{warehouse_id}", agent_type="warehouse", message_bus=message_bus)
        self.warehouse_id = warehouse_id
        self.name = name
        self.location = location
        self.intelligence_module = intelligence_module

        # Initialize state with warehouse-specific information
        self.state = {
            "warehouse_id": warehouse_id,
            "name": name,
            "location": location,
            "inventory": {},
            "pending_orders": [],
            "store_requests": [],
            "supplier_orders": [],
            "last_inventory_check": None,
            "store_inventory": {},  # Tracks inventory across all stores
            "rebalancing_plans": [],
            "order_batching_plans": [],
            "performance_metrics": {
                "order_fill_rate": 0,
                "inventory_turnover": 0,
                "stockout_rate": 0,
                "average_lead_time": 0
            }
        }

    async def process_message(self, message: Dict[str, Any]) -> None:
        """
        Process a received message.

        Args:
            message: The message to process.
        """
        sender_id = message.get("sender_id")
        message_type = message.get("message_type")
        content = message.get("content", {})

        # Store the interaction in memory
        await self.store_memory("interaction", {
            "sender_id": sender_id,
            "message_type": message_type,
            "content_summary": str(content)[:100]  # Store a summary of the content
        })

        if message_type == "restock_request":
            await self.handle_restock_request(content, sender_id)
        elif message_type == "inventory_status_response":
            await self.handle_inventory_status_response(content, sender_id)
        elif message_type == "supplier_order_status":
            await self.handle_supplier_order_status(content)
        elif message_type == "inventory_update":
            await self.handle_inventory_update(content)

    async def handle_restock_request(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a restock request from a store.

        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        store_id = content.get("store_id")
        product_ids = content.get("product_ids", [])
        quantities = content.get("quantities", {})

        if not store_id or not product_ids:
            return

        # Store the request
        request = {
            "store_id": store_id,
            "store_agent_id": sender_id,
            "product_ids": product_ids,
            "quantities": quantities,
            "timestamp": datetime.now().isoformat(),
            "status": "pending"
        }
        self.state["store_requests"].append(request)

        # Process the request
        await self.process_restock_request(request)

    async def process_restock_request(self, request: Dict[str, Any]) -> None:
        """
        Process a restock request.

        Args:
            request: The restock request to process.
        """
        store_id = request.get("store_id")
        store_agent_id = request.get("store_agent_id")
        product_ids = request.get("product_ids", [])
        requested_quantities = request.get("quantities", {})

        # Check warehouse inventory for each product
        fulfilled_products = {}
        unfulfilled_products = {}

        for product_id in product_ids:
            requested_qty = requested_quantities.get(product_id, 0)
            warehouse_qty = self.state["inventory"].get(product_id, 0)

            if warehouse_qty >= requested_qty:
                # We can fulfill this request
                fulfilled_products[product_id] = requested_qty
                # Update warehouse inventory
                self.state["inventory"][product_id] -= requested_qty
            else:
                # We can partially fulfill or not fulfill this request
                if warehouse_qty > 0:
                    # Partial fulfillment
                    fulfilled_products[product_id] = warehouse_qty
                    unfulfilled_products[product_id] = requested_qty - warehouse_qty
                    # Update warehouse inventory
                    self.state["inventory"][product_id] = 0
                else:
                    # Cannot fulfill
                    unfulfilled_products[product_id] = requested_qty

        # Send fulfilled products to the store
        if fulfilled_products:
            await self.send_message(
                target_agent_id=store_agent_id,
                message_type="restock_fulfillment",
                content={
                    "store_id": store_id,
                    "fulfilled_products": fulfilled_products
                }
            )

            # Store the fulfillment in memory
            await self.store_memory("decision", {
                "type": "restock_fulfillment",
                "store_id": store_id,
                "fulfilled_products": fulfilled_products
            })

        # Order unfulfilled products from suppliers
        if unfulfilled_products:
            await self.order_from_suppliers(unfulfilled_products, store_id)

            # Update the request status
            for i, req in enumerate(self.state["store_requests"]):
                if req.get("store_id") == store_id and req.get("timestamp") == request.get("timestamp"):
                    self.state["store_requests"][i]["status"] = "partially_fulfilled" if fulfilled_products else "ordered_from_supplier"
                    break

    async def order_from_suppliers(self, products: Dict[int, int], store_id: Optional[int] = None) -> None:
        """
        Order products from suppliers.

        Args:
            products: Dictionary mapping product IDs to quantities.
            store_id: Optional ID of the store that requested the products.
        """
        # Group products by supplier
        supplier_orders = {}

        # In a real system, we would query the database to get supplier information
        # For now, we'll use a simple mapping
        product_to_supplier = {
            # product_id: supplier_id
            1: 1, 2: 1, 3: 2, 4: 2, 5: 3
        }

        for product_id, quantity in products.items():
            supplier_id = product_to_supplier.get(product_id, random.randint(1, 5))  # Default to random supplier

            if supplier_id not in supplier_orders:
                supplier_orders[supplier_id] = {}

            supplier_orders[supplier_id][product_id] = quantity

        # Create and send orders to suppliers
        for supplier_id, order_products in supplier_orders.items():
            order = {
                "order_id": f"order_{datetime.now().timestamp()}",
                "warehouse_id": self.warehouse_id,
                "supplier_id": supplier_id,
                "products": order_products,
                "store_id": store_id,  # Track which store requested these products
                "timestamp": datetime.now().isoformat(),
                "status": "pending"
            }

            self.state["supplier_orders"].append(order)

            # Find supplier agent
            supplier_agents = [conn for conn in self.connections if conn.agent_type == "supplier" and conn.supplier_id == supplier_id]

            if supplier_agents:
                supplier_agent = supplier_agents[0]

                await self.send_message(
                    target_agent_id=supplier_agent.agent_id,
                    message_type="supplier_order",
                    content=order
                )

                # Store the order in memory
                await self.store_memory("decision", {
                    "type": "supplier_order",
                    "supplier_id": supplier_id,
                    "products": order_products,
                    "store_id": store_id
                })
            else:
                # Store the failed order in memory
                await self.store_memory("decision", {
                    "type": "supplier_order_failed",
                    "reason": f"No agent found for supplier {supplier_id}",
                    "products": order_products,
                    "store_id": store_id
                })

    async def handle_inventory_status_response(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle an inventory status response from a store.

        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        inventory = content.get("inventory", {})
        stockouts = content.get("stockouts", [])
        overstocked_items = content.get("overstocked_items", [])

        # Extract store ID from sender_id (format: "store_{id}")
        store_id = sender_id.split("_")[1] if "_" in sender_id else None

        if store_id:
            # Update our knowledge of the store's inventory
            self.state["store_inventory"][store_id] = {
                "inventory": inventory,
                "stockouts": stockouts,
                "overstocked_items": overstocked_items,
                "last_updated": datetime.now().isoformat()
            }

            # Store the update in memory
            await self.store_memory("observation", {
                "type": "store_inventory_update",
                "store_id": store_id,
                "stockouts": len(stockouts),
                "overstocked_items": len(overstocked_items)
            })

            # Check if we need to rebalance inventory across stores
            await self.check_inventory_rebalancing()

    async def handle_supplier_order_status(self, content: Dict[str, Any]) -> None:
        """
        Handle a supplier order status update.

        Args:
            content: Content of the message.
        """
        order_id = content.get("order_id")
        status = content.get("status")
        products = content.get("products", {})

        if not order_id or not status:
            return

        # Update order status
        for i, order in enumerate(self.state["supplier_orders"]):
            if order.get("order_id") == order_id:
                self.state["supplier_orders"][i]["status"] = status

                # If order is delivered, update inventory
                if status == "delivered":
                    for product_id, quantity in products.items():
                        if product_id in self.state["inventory"]:
                            self.state["inventory"][product_id] += quantity
                        else:
                            self.state["inventory"][product_id] = quantity

                    # Check if this order was for a specific store
                    store_id = order.get("store_id")
                    if store_id:
                        # Find the store's agent ID
                        store_agent_id = None
                        for req in self.state["store_requests"]:
                            if req.get("store_id") == store_id:
                                store_agent_id = req.get("store_agent_id")
                                break

                        if store_agent_id:
                            # Notify the store that their order is ready
                            await self.send_message(
                                target_agent_id=store_agent_id,
                                message_type="restock_fulfillment",
                                content={
                                    "store_id": store_id,
                                    "fulfilled_products": products
                                }
                            )

                break

        # Store the update in memory
        await self.store_memory("observation", {
            "type": "supplier_order_status",
            "order_id": order_id,
            "status": status,
            "products": products
        })

    async def handle_inventory_update(self, content: Dict[str, Any]) -> None:
        """
        Handle an inventory update.

        Args:
            content: Content of the message.
        """
        product_id = content.get("product_id")
        quantity = content.get("quantity")

        if product_id is not None and quantity is not None:
            # Update warehouse inventory
            self.state["inventory"][product_id] = quantity

            # Store the update in memory
            await self.store_memory("observation", {
                "type": "inventory_update",
                "product_id": product_id,
                "quantity": quantity
            })

    async def check_inventory(self) -> None:
        """Check warehouse inventory levels and identify low stock items using the intelligence module if available."""
        low_stock_items = []
        reorder_recommendations = []

        # Use intelligence module if available
        if self.intelligence_module:
            try:
                # Get product data
                product_data = {}
                for product_id, quantity in self.state["inventory"].items():
                    # In a real system, we would get this data from the database
                    # For now, we'll use placeholders
                    product_data[product_id] = {
                        "cost": 40.0,  # Placeholder (lower than store cost)
                        "current_inventory": quantity
                    }

                # Get store inventory data to estimate demand
                store_inventory_data = {}
                for store_id, info in self.state["store_inventory"].items():
                    store_inventory_data[store_id] = info.get("inventory", {})

                # Convert historical orders to sales data format
                sales_data = []
                for order in self.state["supplier_orders"]:
                    if order.get("status") in ["delivered", "shipped"]:
                        order_date = datetime.fromisoformat(order.get("timestamp", datetime.now().isoformat()))
                        for product_id, quantity in order.get("products", {}).items():
                            sales_data.append({
                                "product_id": product_id,
                                "quantity": quantity,
                                "date": order_date,
                                "price": 40.0  # Placeholder
                            })

                # Convert to DataFrame
                sales_df = pd.DataFrame(sales_data)

                # Process each product
                for product_id, data in product_data.items():
                    # Skip if no inventory data
                    if product_id not in self.state["inventory"]:
                        continue

                    # Filter sales data for this product
                    product_sales = sales_df[sales_df["product_id"] == product_id].copy() if not sales_df.empty else pd.DataFrame()

                    # If we have enough data, use intelligence module
                    if not product_sales.empty and len(product_sales) >= 5:
                        # Optimize inventory
                        optimization_result = await self.intelligence_module.optimize_inventory(
                            product_id=product_id,
                            cost=data["cost"],
                            current_inventory=data["current_inventory"],
                            sales_data=product_sales,
                            lead_time_days=7  # Supplier to warehouse lead time
                        )

                        # Check if we need to reorder
                        if data["current_inventory"] <= optimization_result["optimization"]["reorder_point"]:
                            reorder_recommendations.append({
                                "product_id": product_id,
                                "current_inventory": data["current_inventory"],
                                "reorder_point": optimization_result["optimization"]["reorder_point"],
                                "order_quantity": optimization_result["optimization"]["economic_order_quantity"],
                                "priority": "high" if data["current_inventory"] < optimization_result["optimization"]["safety_stock"] else "medium"
                            })
                            low_stock_items.append(product_id)
                    else:
                        # Use basic check if not enough data
                        await self._basic_inventory_check(product_id, data["current_inventory"], low_stock_items)

                logger.info(f"Warehouse {self.warehouse_id}: Intelligent inventory check completed with {len(low_stock_items)} low stock items")

            except Exception as e:
                logger.error(f"Warehouse {self.warehouse_id}: Error in intelligent inventory check: {e}")
                # Fall back to basic inventory check
                await self._basic_inventory_check_all(low_stock_items)
        else:
            # Use basic inventory check
            await self._basic_inventory_check_all(low_stock_items)

        # Update state
        self.state["low_stock_items"] = low_stock_items
        self.state["reorder_recommendations"] = reorder_recommendations
        self.state["last_inventory_check"] = datetime.now().isoformat()

        # Place orders for low stock items
        if low_stock_items:
            # Determine order quantities
            if reorder_recommendations:
                # Use intelligent recommendations
                order_quantities = {rec["product_id"]: rec["order_quantity"] for rec in reorder_recommendations}
            else:
                # Use basic approach
                threshold = 20
                order_quantities = {pid: threshold * 2 for pid in low_stock_items}

            # Order from suppliers
            await self.order_from_suppliers(order_quantities)

        # Calculate inventory metrics
        total_inventory = sum(self.state["inventory"].values())
        total_products = len(self.state["inventory"])
        stockout_rate = len([pid for pid, qty in self.state["inventory"].items() if qty == 0]) / total_products if total_products > 0 else 0

        # Update performance metrics
        self.state["performance_metrics"]["stockout_rate"] = stockout_rate

        # Store the inventory check in memory
        await self.store_memory("observation", {
            "type": "warehouse_inventory_check",
            "low_stock_items": low_stock_items,
            "total_products": total_products,
            "total_inventory": total_inventory,
            "stockout_rate": stockout_rate
        })

    async def _basic_inventory_check_all(self, low_stock_items: List[int]) -> None:
        """Perform basic inventory check for all products."""
        for product_id, quantity in self.state["inventory"].items():
            await self._basic_inventory_check(product_id, quantity, low_stock_items)

    async def _basic_inventory_check(self, product_id: int, quantity: int, low_stock_items: List[int]) -> None:
        """Perform basic inventory check for a single product."""
        # In a real system, we would have minimum stock levels for each product
        # For now, we'll use a simple threshold
        threshold = 20

        if quantity < threshold:
            low_stock_items.append(product_id)

    async def check_inventory_rebalancing(self) -> None:
        """Check if inventory needs to be rebalanced across stores using the intelligence module if available."""
        # Find overstocked and understocked stores
        overstocked_stores = {}
        understocked_stores = {}

        for store_id, info in self.state["store_inventory"].items():
            for product_id in info.get("overstocked_items", []):
                if product_id not in overstocked_stores:
                    overstocked_stores[product_id] = []
                overstocked_stores[product_id].append(store_id)

            for product_id in info.get("stockouts", []):
                if product_id not in understocked_stores:
                    understocked_stores[product_id] = []
                understocked_stores[product_id].append(store_id)

        # Use intelligence module if available
        if self.intelligence_module and (overstocked_stores or understocked_stores):
            try:
                # Get store IDs
                store_ids = list(set([store_id for store_id, _ in self.state["store_inventory"].items()]))

                # Process each product that needs rebalancing
                rebalance_actions = []

                for product_id in set(list(overstocked_stores.keys()) + list(understocked_stores.keys())):
                    # Skip if product not in both lists
                    if product_id not in overstocked_stores or product_id not in understocked_stores:
                        continue

                    # Get warehouse inventory
                    warehouse_inventory = self.state["inventory"].get(product_id, 0)

                    # Get store inventories
                    store_inventories = {}
                    for store_id, info in self.state["store_inventory"].items():
                        store_inventories[store_id] = info.get("inventory", {}).get(product_id, 0)

                    # Get sales data for this product
                    sales_data = []
                    for store_id, info in self.state["store_inventory"].items():
                        for sale in info.get("sales", []):
                            if sale.get("product_id") == product_id:
                                sale_copy = sale.copy()
                                sale_copy["store_id"] = store_id
                                sales_data.append(sale_copy)

                    # Convert to DataFrame
                    sales_df = pd.DataFrame(sales_data)

                    if not sales_df.empty:
                        # Optimize multi-store inventory
                        optimization_result = await self.intelligence_module.optimize_multi_store_inventory(
                            warehouse_id=self.warehouse_id,
                            store_ids=store_ids,
                            product_id=product_id,
                            warehouse_inventory=warehouse_inventory,
                            store_inventories=store_inventories,
                            sales_data=sales_df
                        )

                        # Get rebalancing recommendations
                        if "allocations" in optimization_result:
                            # Create rebalance actions based on allocations
                            for target_store_id, allocation in optimization_result["allocations"].items():
                                # Skip if no allocation
                                if allocation <= 0:
                                    continue

                                # Determine source (warehouse or overstocked store)
                                if warehouse_inventory >= allocation:
                                    # Source from warehouse
                                    rebalance_actions.append({
                                        "product_id": product_id,
                                        "source": "warehouse",
                                        "target_store": target_store_id,
                                        "quantity": allocation,
                                        "reason": "Intelligent allocation"
                                    })
                                else:
                                    # Source from overstocked store
                                    for source_store_id in overstocked_stores[product_id]:
                                        source_inventory = store_inventories.get(source_store_id, 0)
                                        if source_inventory > allocation:
                                            rebalance_actions.append({
                                                "product_id": product_id,
                                                "source_store": source_store_id,
                                                "target_store": target_store_id,
                                                "quantity": allocation,
                                                "reason": "Intelligent rebalancing"
                                            })
                                            break

                logger.info(f"Warehouse {self.warehouse_id}: Intelligent inventory rebalancing completed with {len(rebalance_actions)} actions")

                # Store rebalancing plan
                if rebalance_actions:
                    self.state["rebalancing_plans"] = rebalance_actions

                    # Store the decision in memory
                    await self.store_memory("decision", {
                        "type": "inventory_rebalance",
                        "actions": rebalance_actions,
                        "method": "intelligent"
                    })

                    # Execute rebalancing actions
                    await self.execute_rebalancing_actions(rebalance_actions)

            except Exception as e:
                logger.error(f"Warehouse {self.warehouse_id}: Error in intelligent inventory rebalancing: {e}")
                # Fall back to basic rebalancing
                rebalance_actions = await self._basic_inventory_rebalancing(overstocked_stores, understocked_stores)

                if rebalance_actions:
                    # Store the decision in memory
                    await self.store_memory("decision", {
                        "type": "inventory_rebalance",
                        "actions": rebalance_actions,
                        "method": "basic"
                    })
        else:
            # Use basic rebalancing
            rebalance_actions = await self._basic_inventory_rebalancing(overstocked_stores, understocked_stores)

            if rebalance_actions:
                # Store the decision in memory
                await self.store_memory("decision", {
                    "type": "inventory_rebalance",
                    "actions": rebalance_actions,
                    "method": "basic"
                })

    async def _basic_inventory_rebalancing(self, overstocked_stores: Dict[int, List[int]], understocked_stores: Dict[int, List[int]]) -> List[Dict[str, Any]]:
        """Perform basic inventory rebalancing without intelligence module."""
        rebalance_actions = []

        for product_id, overstocked in overstocked_stores.items():
            if product_id in understocked_stores:
                # We can rebalance this product
                for source_store in overstocked:
                    for target_store in understocked_stores[product_id]:
                        # In a real system, we would consider distance, quantities, etc.
                        rebalance_actions.append({
                            "product_id": product_id,
                            "source_store": source_store,
                            "target_store": target_store,
                            "quantity": 10,  # Simplified quantity
                            "reason": "Basic rebalancing"
                        })

        return rebalance_actions

    async def execute_rebalancing_actions(self, rebalance_actions: List[Dict[str, Any]]) -> None:
        """Execute inventory rebalancing actions."""
        for action in rebalance_actions:
            product_id = action.get("product_id")
            quantity = action.get("quantity", 0)

            if action.get("source") == "warehouse":
                # Source from warehouse
                target_store_id = action.get("target_store")

                # Update warehouse inventory
                if product_id in self.state["inventory"] and self.state["inventory"][product_id] >= quantity:
                    self.state["inventory"][product_id] -= quantity

                    # Notify store
                    store_agents = [conn for conn in self.connections if conn.agent_type == "store" and conn.store_id == int(target_store_id)]

                    if store_agents:
                        store = store_agents[0]

                        await self.send_message(
                            target_agent_id=store.agent_id,
                            message_type="inventory_update",
                            content={
                                "product_id": product_id,
                                "quantity": quantity,
                                "source": "warehouse",
                                "reason": action.get("reason", "Rebalancing")
                            }
                        )
            else:
                # Source from another store
                source_store_id = action.get("source_store")
                target_store_id = action.get("target_store")

                # Notify source store
                source_agents = [conn for conn in self.connections if conn.agent_type == "store" and conn.store_id == int(source_store_id)]

                if source_agents:
                    source = source_agents[0]

                    await self.send_message(
                        target_agent_id=source.agent_id,
                        message_type="inventory_transfer_request",
                        content={
                            "product_id": product_id,
                            "quantity": quantity,
                            "target_store_id": target_store_id,
                            "reason": action.get("reason", "Rebalancing")
                        }
                    }

                # Notify target store
                target_agents = [conn for conn in self.connections if conn.agent_type == "store" and conn.store_id == int(target_store_id)]

                if target_agents:
                    target = target_agents[0]

                    await self.send_message(
                        target_agent_id=target.agent_id,
                        message_type="inventory_transfer_notification",
                        content={
                            "product_id": product_id,
                            "quantity": quantity,
                            "source_store_id": source_store_id,
                            "reason": action.get("reason", "Rebalancing")
                        }
                    }

    async def query_store_inventory(self) -> None:
        """Query all connected stores for their current inventory status."""
        store_agents = [conn for conn in self.connections if conn.agent_type == "store"]

        for store in store_agents:
            await self.send_message(
                target_agent_id=store.agent_id,
                message_type="warehouse_query",
                content={"query_type": "inventory_status"}
            )

    async def take_action(self) -> None:
        """Take action based on the agent's current state."""
        try:
            # Check if it's time to check inventory (every hour)
            last_check = self.state.get("last_inventory_check")
            if last_check is None or (datetime.now() - datetime.fromisoformat(last_check)).total_seconds() > 3600:
                await self.check_inventory()

            # Periodically query stores for inventory status (every 2 hours)
            last_query = self.state.get("last_store_query")
            if last_query is None or (datetime.now() - datetime.fromisoformat(last_query)).total_seconds() > 7200:
                await self.query_store_inventory()
                self.state["last_store_query"] = datetime.now().isoformat()

            # Check for inventory rebalancing opportunities (every 4 hours)
            last_rebalance = self.state.get("last_rebalance_check")
            if last_rebalance is None or (datetime.now() - datetime.fromisoformat(last_rebalance)).total_seconds() > 14400:
                await self.check_inventory_rebalancing()
                self.state["last_rebalance_check"] = datetime.now().isoformat()

            # Process any pending store requests
            pending_requests = [req for req in self.state["store_requests"] if req.get("status") == "pending"]
            for request in pending_requests:
                await self.process_restock_request(request)

            # Optimize order batching (every 6 hours)
            last_order_batch = self.state.get("last_order_batch")
            if last_order_batch is None or (datetime.now() - datetime.fromisoformat(last_order_batch)).total_seconds() > 21600:
                await self.optimize_order_batching()
                self.state["last_order_batch"] = datetime.now().isoformat()

            # Report performance metrics to coordinator (every 12 hours)
            last_report = self.state.get("last_performance_report")
            if last_report is None or (datetime.now() - datetime.fromisoformat(last_report)).total_seconds() > 43200:
                await self.report_performance_metrics()
                self.state["last_performance_report"] = datetime.now().isoformat()

            # Check supplier order status (random chance)
            if random.random() < 0.2:  # 20% chance each cycle
                await self.check_supplier_orders()

        except Exception as e:
            logger.error(f"Warehouse {self.warehouse_id}: Error in take_action: {e}")

    async def optimize_order_batching(self) -> None:
        """Optimize order batching to suppliers using the intelligence module if available."""
        # Get pending orders that need to be placed with suppliers
        pending_orders = []
        for request in self.state["store_requests"]:
            if request.get("status") in ["pending", "partially_fulfilled"]:
                pending_orders.append(request)

        if not pending_orders:
            return

        # Use intelligence module if available
        if self.intelligence_module:
            try:
                # Get coordinator for optimization
                coordinator_agents = [conn for conn in self.connections if conn.agent_type == "coordinator"]

                if coordinator_agents:
                    coordinator = coordinator_agents[0]

                    # Request optimization
                    await self.send_message(
                        target_agent_id=coordinator.agent_id,
                        message_type="optimization_request",
                        content={
                            "optimization_type": "order_batching",
                            "parameters": {
                                "warehouse_id": self.warehouse_id,
                                "pending_orders": pending_orders
                            }
                        }
                    )

                    logger.info(f"Warehouse {self.warehouse_id}: Requested order batching optimization for {len(pending_orders)} orders")
                else:
                    # Perform basic order batching
                    batched_orders = await self._basic_order_batching(pending_orders)
                    await self.process_batched_orders(batched_orders)

            except Exception as e:
                logger.error(f"Warehouse {self.warehouse_id}: Error in order batching optimization: {e}")
                # Fall back to basic order batching
                batched_orders = await self._basic_order_batching(pending_orders)
                await self.process_batched_orders(batched_orders)
        else:
            # Perform basic order batching
            batched_orders = await self._basic_order_batching(pending_orders)
            await self.process_batched_orders(batched_orders)

    async def _basic_order_batching(self, pending_orders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Perform basic order batching without intelligence module."""
        # Group orders by supplier
        supplier_orders = {}

        for order in pending_orders:
            for product_id, quantity in order.get("products", {}).items():
                # In a real system, we would look up the supplier for each product
                # For now, we'll use a simple mapping
                supplier_id = (product_id % 3) + 1  # Map product_id to supplier_id 1, 2, or 3

                if supplier_id not in supplier_orders:
                    supplier_orders[supplier_id] = {}

                if product_id not in supplier_orders[supplier_id]:
                    supplier_orders[supplier_id][product_id] = 0

                supplier_orders[supplier_id][product_id] += quantity

        # Create batched orders
        batched_orders = []

        for supplier_id, products in supplier_orders.items():
            batched_orders.append({
                "supplier_id": supplier_id,
                "products": products,
                "original_orders": [order.get("order_id") for order in pending_orders if any(pid in products for pid in order.get("products", {}))]  # Simplified
            })

        return batched_orders

    async def process_batched_orders(self, batched_orders: List[Dict[str, Any]]) -> None:
        """Process batched orders and send to suppliers."""
        for batch in batched_orders:
            supplier_id = batch.get("supplier_id")
            products = batch.get("products", {})

            if not supplier_id or not products:
                continue

            # Create a new order
            order = {
                "order_id": f"order_{datetime.now().timestamp()}",
                "warehouse_id": self.warehouse_id,
                "supplier_id": supplier_id,
                "products": products,
                "timestamp": datetime.now().isoformat(),
                "status": "pending"
            }

            # Add to supplier orders
            self.state["supplier_orders"].append(order)

            # Find supplier agent
            supplier_agents = [conn for conn in self.connections if conn.agent_type == "supplier" and conn.supplier_id == supplier_id]

            if supplier_agents:
                supplier = supplier_agents[0]

                # Send order to supplier
                await self.send_message(
                    target_agent_id=supplier.agent_id,
                    message_type="supplier_order",
                    content=order
                )

                # Store the order in memory
                await self.store_memory("decision", {
                    "type": "supplier_order",
                    "supplier_id": supplier_id,
                    "products": products,
                    "batched": True
                })

    async def report_performance_metrics(self) -> None:
        """Report performance metrics to the coordinator."""
        # Find coordinator agent
        coordinator_agents = [conn for conn in self.connections if conn.agent_type == "coordinator"]

        if not coordinator_agents:
            return

        coordinator = coordinator_agents[0]

        # Calculate additional metrics
        # Order fill rate
        total_requests = len(self.state["store_requests"])
        fulfilled_requests = len([req for req in self.state["store_requests"] if req.get("status") in ["fulfilled", "partially_fulfilled"]])
        order_fill_rate = fulfilled_requests / total_requests if total_requests > 0 else 1.0

        # Average lead time
        lead_times = []
        for order in self.state["supplier_orders"]:
            if order.get("status") == "delivered" and "timestamp" in order and "actual_delivery_date" in order:
                order_date = datetime.fromisoformat(order["timestamp"])
                delivery_date = datetime.fromisoformat(order["actual_delivery_date"])
                lead_time = (delivery_date - order_date).days
                lead_times.append(lead_time)

        average_lead_time = sum(lead_times) / len(lead_times) if lead_times else 0

        # Update performance metrics
        self.state["performance_metrics"]["order_fill_rate"] = order_fill_rate
        self.state["performance_metrics"]["average_lead_time"] = average_lead_time

        # Send performance metrics
        await self.send_message(
            target_agent_id=coordinator.agent_id,
            message_type="performance_metrics",
            content={
                "metrics": self.state["performance_metrics"],
                "warehouse_id": self.warehouse_id,
                "timestamp": datetime.now().isoformat()
            }
        )

    async def check_supplier_orders(self) -> None:
        """Check the status of pending supplier orders."""
        for i, order in enumerate(self.state["supplier_orders"]):
            if order.get("status") == "pending":
                # Simulate order status check
                # In a real system, we would query the supplier
                # For now, we'll just update the status randomly
                if random.random() < 0.3:  # 30% chance of status change
                    new_status = random.choice(["processing", "shipped"])
                    self.state["supplier_orders"][i]["status"] = new_status

                    # Store the update in memory
                    await self.store_memory("observation", {
                        "type": "supplier_order_status_update",
                        "order_id": order.get("order_id"),
                        "old_status": "pending",
                        "new_status": new_status
                    })
