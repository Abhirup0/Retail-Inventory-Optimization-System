import asyncio
import uuid
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional

from src.utils.message_bus import MessageBus

logger = logging.getLogger(__name__)

class Agent:
    """Base class for all agents in the retail inventory optimization system."""

    def __init__(self, agent_id: str = None, agent_type: str = None, message_bus: Optional[MessageBus] = None):
        """
        Initialize a new agent.

        Args:
            agent_id: Unique identifier for the agent. If None, a UUID will be generated.
            agent_type: Type of the agent (e.g., "store", "warehouse", "supplier", "customer").
            message_bus: Optional message bus for agent communication. If None, the agent will use direct connections.
        """
        self.agent_id = agent_id or str(uuid.uuid4())
        self.agent_type = agent_type
        self.state = {}
        self.inbox = asyncio.Queue()
        self.outbox = asyncio.Queue()
        self.memory = []
        self.connections = []
        self.message_bus = message_bus

        # Register with message bus if provided
        if self.message_bus:
            self.message_bus.register_agent(self.agent_id, self._handle_direct_message)

    async def send_message(self, target_agent_id: str, message_type: str, content: Dict[str, Any]) -> None:
        """
        Send a message to another agent.

        Args:
            target_agent_id: ID of the agent to send the message to.
            message_type: Type of the message (e.g., "request", "response", "notification").
            content: Content of the message.
        """
        message = {
            "sender_id": self.agent_id,
            "sender_type": self.agent_type,
            "target_id": target_agent_id,
            "message_type": message_type,
            "content": content,
            "timestamp": datetime.now().isoformat()
        }

        # Log the message
        logger.debug(f"Agent {self.agent_id} sending message to {target_agent_id}: {message_type}")

        # Use message bus if available, otherwise use direct connection
        if self.message_bus:
            await self.message_bus.send_direct(target_agent_id, message)
        else:
            # Legacy direct connection method
            await self.outbox.put(message)

            # Find the target agent in connections and deliver the message
            target_agent = next((agent for agent in self.connections if agent.agent_id == target_agent_id), None)
            if target_agent:
                await target_agent.inbox.put(message)

    async def receive_message(self) -> Dict[str, Any]:
        """
        Receive a message from the inbox.

        Returns:
            The received message.
        """
        message = await self.inbox.get()
        return message

    async def process_message(self, message: Dict[str, Any]) -> None:
        """
        Process a received message.

        Args:
            message: The message to process.
        """
        # This method should be implemented by subclasses
        raise NotImplementedError("Subclasses must implement process_message method")

    async def update_state(self, key: str, value: Any) -> None:
        """
        Update the agent's state.

        Args:
            key: The state key to update.
            value: The new value for the state key.
        """
        self.state[key] = value

    async def get_state(self, key: str) -> Any:
        """
        Get a value from the agent's state.

        Args:
            key: The state key to retrieve.

        Returns:
            The value for the specified key, or None if the key doesn't exist.
        """
        return self.state.get(key)

    async def store_memory(self, memory_type: str, content: Dict[str, Any], relevance: float = 1.0) -> None:
        """
        Store a memory.

        Args:
            memory_type: Type of the memory (e.g., "observation", "decision", "interaction").
            content: Content of the memory.
            relevance: Relevance score of the memory (0.0 to 1.0).
        """
        memory = {
            "agent_id": self.agent_id,
            "memory_type": memory_type,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "relevance": relevance
        }
        self.memory.append(memory)

    async def retrieve_memories(self, memory_type: Optional[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Retrieve memories, optionally filtered by type.

        Args:
            memory_type: Type of memories to retrieve. If None, all memories are returned.
            limit: Maximum number of memories to retrieve.

        Returns:
            A list of memories, sorted by timestamp (newest first).
        """
        filtered_memories = [m for m in self.memory if memory_type is None or m["memory_type"] == memory_type]
        sorted_memories = sorted(filtered_memories, key=lambda m: m["timestamp"], reverse=True)
        return sorted_memories[:limit]

    async def connect(self, agent) -> None:
        """
        Connect to another agent.

        Args:
            agent: The agent to connect to.
        """
        # Only add if not already connected
        if agent not in self.connections:
            self.connections.append(agent)
            logger.debug(f"Agent {self.agent_id} connected to {agent.agent_id}")

    async def _handle_direct_message(self, message: Dict[str, Any]) -> None:
        """
        Handle a direct message from the message bus.

        Args:
            message: The message to handle.
        """
        # Put the message in the inbox
        await self.inbox.put(message)

    async def run(self) -> None:
        """
        Run the agent's main loop.
        """
        logger.info(f"Agent {self.agent_id} ({self.agent_type}) starting")

        try:
            while True:
                # Process incoming messages
                if not self.inbox.empty():
                    message = await self.receive_message()
                    await self.process_message(message)

                # Take action based on current state
                await self.take_action()

                # Small delay to prevent CPU hogging
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            logger.info(f"Agent {self.agent_id} ({self.agent_type}) stopping")
            # Unregister from message bus if used
            if self.message_bus:
                self.message_bus.unregister_agent(self.agent_id)
            raise
        except Exception as e:
            logger.error(f"Error in agent {self.agent_id} ({self.agent_type}): {e}", exc_info=True)
            # Unregister from message bus if used
            if self.message_bus:
                self.message_bus.unregister_agent(self.agent_id)
            raise

    async def take_action(self) -> None:
        """
        Take action based on the agent's current state.
        """
        # This method should be implemented by subclasses
        raise NotImplementedError("Subclasses must implement take_action method")
