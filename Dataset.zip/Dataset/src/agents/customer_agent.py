import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import random

from .base_agent import Agent

class CustomerAgent(Agent):
    """Agent representing a customer or customer segment."""
    
    def __init__(self, customer_id: int, segment: str, preferences: List[str] = None):
        """
        Initialize a customer agent.
        
        Args:
            customer_id: ID of the customer in the database.
            segment: Customer segment (e.g., "Regular", "Premium", "VIP").
            preferences: List of product categories the customer prefers.
        """
        super().__init__(agent_id=f"customer_{customer_id}", agent_type="customer")
        self.customer_id = customer_id
        self.segment = segment
        self.preferences = preferences or []
        
        # Initialize state with customer-specific information
        self.state = {
            "customer_id": customer_id,
            "segment": segment,
            "preferences": self.preferences,
            "purchase_history": [],
            "shopping_cart": {},
            "viewed_products": [],
            "price_sensitivity": self._generate_price_sensitivity(),
            "seasonal_preferences": self._generate_seasonal_preferences(),
            "last_purchase_date": None,
            "favorite_stores": []
        }
    
    def _generate_price_sensitivity(self) -> float:
        """
        Generate price sensitivity based on customer segment.
        
        Returns:
            A value between 0 and 1, where 0 is not price sensitive and 1 is very price sensitive.
        """
        if self.segment == "Premium" or self.segment == "VIP":
            return random.uniform(0.1, 0.4)  # Less price sensitive
        elif self.segment == "Regular":
            return random.uniform(0.4, 0.7)  # Moderately price sensitive
        else:  # "New" or "Occasional"
            return random.uniform(0.6, 0.9)  # More price sensitive
    
    def _generate_seasonal_preferences(self) -> Dict[str, List[str]]:
        """
        Generate seasonal preferences for different product categories.
        
        Returns:
            A dictionary mapping seasons to preferred product categories.
        """
        all_categories = ["Electronics", "Clothing", "Groceries", "Home Goods", "Toys", "Sports", "Beauty", "Books"]
        
        # Select a subset of categories for each season
        return {
            "spring": random.sample(all_categories, random.randint(2, 4)),
            "summer": random.sample(all_categories, random.randint(2, 4)),
            "fall": random.sample(all_categories, random.randint(2, 4)),
            "winter": random.sample(all_categories, random.randint(2, 4))
        }
    
    async def process_message(self, message: Dict[str, Any]) -> None:
        """
        Process a received message.
        
        Args:
            message: The message to process.
        """
        sender_id = message.get("sender_id")
        message_type = message.get("message_type")
        content = message.get("content", {})
        
        # Store the interaction in memory
        await self.store_memory("interaction", {
            "sender_id": sender_id,
            "message_type": message_type,
            "content_summary": str(content)[:100]  # Store a summary of the content
        })
        
        if message_type == "product_recommendation":
            await self.handle_product_recommendation(content, sender_id)
        elif message_type == "product_availability_response":
            await self.handle_product_availability_response(content, sender_id)
        elif message_type == "price_update":
            await self.handle_price_update(content)
        elif message_type == "promotion":
            await self.handle_promotion(content, sender_id)
    
    async def handle_product_recommendation(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a product recommendation from a store.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        recommended_products = content.get("products", [])
        
        if not recommended_products:
            return
        
        # Evaluate each recommended product
        for product in recommended_products:
            product_id = product.get("product_id")
            category = product.get("category", "")
            price = product.get("price", 0)
            
            if not product_id:
                continue
            
            # Check if the product matches customer preferences
            preference_match = category in self.state["preferences"]
            
            # Check if the product is in season
            current_month = datetime.now().month
            current_season = "winter" if current_month in [12, 1, 2] else \
                            "spring" if current_month in [3, 4, 5] else \
                            "summer" if current_month in [6, 7, 8] else "fall"
            seasonal_match = category in self.state["seasonal_preferences"].get(current_season, [])
            
            # Calculate interest score
            interest_score = 0.3
            if preference_match:
                interest_score += 0.4
            if seasonal_match:
                interest_score += 0.3
                
            # Adjust for price sensitivity
            if price > 0:
                # Higher price reduces interest for price-sensitive customers
                interest_score *= (1 - self.state["price_sensitivity"] * (price / 1000))  # Simple heuristic
            
            # If interested, add to viewed products and possibly to cart
            if interest_score > 0.5:  # Threshold for interest
                # Add to viewed products
                self.state["viewed_products"].append({
                    "product_id": product_id,
                    "timestamp": datetime.now().isoformat(),
                    "interest_score": interest_score
                })
                
                # Possibly add to cart (simulating purchase intent)
                if random.random() < interest_score:
                    if product_id in self.state["shopping_cart"]:
                        self.state["shopping_cart"][product_id] += 1
                    else:
                        self.state["shopping_cart"][product_id] = 1
                    
                    # Store the decision in memory
                    await self.store_memory("decision", {
                        "type": "add_to_cart",
                        "product_id": product_id,
                        "interest_score": interest_score,
                        "reason": "Recommendation matched preferences" if preference_match else "Seasonal interest"
                    })
    
    async def handle_product_availability_response(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a product availability response from a store.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        product_id = content.get("product_id")
        available = content.get("available", False)
        quantity = content.get("quantity", 0)
        
        if not product_id:
            return
        
        # If the product is in our cart but not available, remove it
        if product_id in self.state["shopping_cart"] and not available:
            del self.state["shopping_cart"][product_id]
            
            # Store the decision in memory
            await self.store_memory("decision", {
                "type": "remove_from_cart",
                "product_id": product_id,
                "reason": "Product not available"
            })
        
        # If the product is available but limited quantity, adjust cart quantity
        elif product_id in self.state["shopping_cart"] and available and quantity < self.state["shopping_cart"][product_id]:
            self.state["shopping_cart"][product_id] = quantity
            
            # Store the decision in memory
            await self.store_memory("decision", {
                "type": "adjust_cart_quantity",
                "product_id": product_id,
                "new_quantity": quantity,
                "reason": "Limited availability"
            })
    
    async def handle_price_update(self, content: Dict[str, Any]) -> None:
        """
        Handle a price update for a product.
        
        Args:
            content: Content of the message.
        """
        product_id = content.get("product_id")
        old_price = content.get("old_price")
        new_price = content.get("new_price")
        
        if not product_id or old_price is None or new_price is None:
            return
        
        # Calculate price change percentage
        price_change_pct = (new_price - old_price) / old_price * 100
        
        # If price increased and we're price sensitive, possibly remove from cart
        if price_change_pct > 0 and product_id in self.state["shopping_cart"]:
            # Higher price sensitivity means more likely to remove on price increase
            removal_probability = self.state["price_sensitivity"] * (price_change_pct / 10)  # Simple heuristic
            
            if random.random() < removal_probability:
                del self.state["shopping_cart"][product_id]
                
                # Store the decision in memory
                await self.store_memory("decision", {
                    "type": "remove_from_cart",
                    "product_id": product_id,
                    "reason": f"Price increased by {price_change_pct:.1f}%"
                })
        
        # If price decreased, possibly add to cart or increase quantity
        elif price_change_pct < 0:
            # Check if this product is in our viewed products
            viewed = any(p.get("product_id") == product_id for p in self.state["viewed_products"])
            
            if viewed:
                # Higher price sensitivity means more likely to add on price decrease
                add_probability = self.state["price_sensitivity"] * (abs(price_change_pct) / 10)  # Simple heuristic
                
                if random.random() < add_probability:
                    if product_id in self.state["shopping_cart"]:
                        self.state["shopping_cart"][product_id] += 1
                    else:
                        self.state["shopping_cart"][product_id] = 1
                    
                    # Store the decision in memory
                    await self.store_memory("decision", {
                        "type": "add_to_cart" if self.state["shopping_cart"][product_id] == 1 else "increase_cart_quantity",
                        "product_id": product_id,
                        "reason": f"Price decreased by {abs(price_change_pct):.1f}%"
                    })
    
    async def handle_promotion(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a promotion from a store.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        promotion_type = content.get("type")
        product_id = content.get("product_id")
        discount_pct = content.get("discount_percentage", 0)
        
        if not promotion_type:
            return
        
        # Different types of promotions
        if promotion_type == "product_discount" and product_id:
            # Similar logic to price decrease
            # Higher price sensitivity means more likely to respond to discount
            response_probability = self.state["price_sensitivity"] * (discount_pct / 10)  # Simple heuristic
            
            if random.random() < response_probability:
                if product_id in self.state["shopping_cart"]:
                    self.state["shopping_cart"][product_id] += 1
                else:
                    self.state["shopping_cart"][product_id] = 1
                
                # Store the decision in memory
                await self.store_memory("decision", {
                    "type": "add_to_cart" if self.state["shopping_cart"][product_id] == 1 else "increase_cart_quantity",
                    "product_id": product_id,
                    "reason": f"Promotion with {discount_pct}% discount"
                })
        
        elif promotion_type == "store_wide_sale":
            # Add store to favorites if good sale
            if discount_pct >= 20:  # Significant discount
                store_id = sender_id.split("_")[1] if "_" in sender_id else None
                if store_id and store_id not in self.state["favorite_stores"]:
                    self.state["favorite_stores"].append(store_id)
                    
                    # Store the decision in memory
                    await self.store_memory("decision", {
                        "type": "add_favorite_store",
                        "store_id": store_id,
                        "reason": f"Store-wide sale with {discount_pct}% discount"
                    })
    
    async def check_product_availability(self, product_id: int) -> None:
        """
        Check availability of a product with stores.
        
        Args:
            product_id: ID of the product to check.
        """
        # Find store agents to query
        store_agents = [conn for conn in self.connections if conn.agent_type == "store"]
        
        if not store_agents:
            return
        
        # Prioritize favorite stores
        favorite_store_agents = [
            agent for agent in store_agents 
            if agent.store_id in self.state["favorite_stores"]
        ]
        
        target_stores = favorite_store_agents if favorite_store_agents else store_agents
        
        # Query each store
        for store in target_stores:
            await self.send_message(
                target_agent_id=store.agent_id,
                message_type="customer_query",
                content={
                    "query_type": "product_availability",
                    "product_id": product_id
                }
            )
    
    async def make_purchase(self) -> None:
        """Simulate making a purchase from the shopping cart."""
        if not self.state["shopping_cart"]:
            return
        
        # Find a store to purchase from
        store_agents = [conn for conn in self.connections if conn.agent_type == "store"]
        
        if not store_agents:
            return
        
        # Prioritize favorite stores
        favorite_store_agents = [
            agent for agent in store_agents 
            if agent.store_id in self.state["favorite_stores"]
        ]
        
        target_store = random.choice(favorite_store_agents) if favorite_store_agents else random.choice(store_agents)
        
        # Create purchase
        purchase = {
            "customer_id": self.customer_id,
            "store_id": target_store.store_id,
            "products": self.state["shopping_cart"].copy(),
            "timestamp": datetime.now().isoformat()
        }
        
        # Send purchase to store
        await self.send_message(
            target_agent_id=target_store.agent_id,
            message_type="purchase",
            content=purchase
        )
        
        # Add to purchase history
        self.state["purchase_history"].append(purchase)
        self.state["last_purchase_date"] = purchase["timestamp"]
        
        # Clear shopping cart
        self.state["shopping_cart"] = {}
        
        # Store the purchase in memory
        await self.store_memory("decision", {
            "type": "purchase",
            "store_id": target_store.store_id,
            "products": purchase["products"]
        })
    
    async def browse_products(self) -> None:
        """Simulate browsing products from stores."""
        # Find store agents
        store_agents = [conn for conn in self.connections if conn.agent_type == "store"]
        
        if not store_agents:
            return
        
        # Prioritize favorite stores
        favorite_store_agents = [
            agent for agent in store_agents 
            if agent.store_id in self.state["favorite_stores"]
        ]
        
        target_stores = favorite_store_agents if favorite_store_agents else store_agents
        
        # Select a random store to browse
        store = random.choice(target_stores)
        
        # Request product recommendations
        await self.send_message(
            target_agent_id=store.agent_id,
            message_type="customer_query",
            content={
                "query_type": "product_recommendations",
                "preferences": self.state["preferences"],
                "price_range": {
                    "min": 0,
                    "max": 1000 * (1 - self.state["price_sensitivity"])  # Higher price sensitivity = lower max price
                }
            }
        )
    
    async def take_action(self) -> None:
        """Take action based on the agent's current state."""
        # Simulate customer behavior with random actions
        action = random.choice(["browse", "check_availability", "purchase", "none"])
        
        if action == "browse":
            await self.browse_products()
        elif action == "check_availability" and self.state["shopping_cart"]:
            # Check availability for a random product in cart
            product_id = random.choice(list(self.state["shopping_cart"].keys()))
            await self.check_product_availability(product_id)
        elif action == "purchase" and self.state["shopping_cart"] and random.random() < 0.3:  # 30% chance to purchase
            await self.make_purchase()
        
        # In a real system, we would also:
        # - Analyze product trends
        # - Respond to personalized marketing
        # - Adjust preferences over time
        # - etc.
