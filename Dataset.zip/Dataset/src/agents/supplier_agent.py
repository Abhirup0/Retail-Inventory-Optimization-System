import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import random

from .base_agent import Agent

class SupplierAgent(Agent):
    """Agent representing a product supplier."""
    
    def __init__(self, supplier_id: int, name: str, lead_time: int = 5):
        """
        Initialize a supplier agent.
        
        Args:
            supplier_id: ID of the supplier in the database.
            name: Name of the supplier.
            lead_time: Average lead time in days for this supplier.
        """
        super().__init__(agent_id=f"supplier_{supplier_id}", agent_type="supplier")
        self.supplier_id = supplier_id
        self.name = name
        self.lead_time = lead_time
        
        # Initialize state with supplier-specific information
        self.state = {
            "supplier_id": supplier_id,
            "name": name,
            "lead_time": lead_time,
            "products": {},  # product_id -> {name, price, stock, production_capacity}
            "pending_orders": [],
            "production_schedule": {},
            "warehouse_relationships": {},  # warehouse_id -> {reliability, priority}
            "last_production_update": None
        }
    
    async def process_message(self, message: Dict[str, Any]) -> None:
        """
        Process a received message.
        
        Args:
            message: The message to process.
        """
        sender_id = message.get("sender_id")
        message_type = message.get("message_type")
        content = message.get("content", {})
        
        # Store the interaction in memory
        await self.store_memory("interaction", {
            "sender_id": sender_id,
            "message_type": message_type,
            "content_summary": str(content)[:100]  # Store a summary of the content
        })
        
        if message_type == "supplier_order":
            await self.handle_supplier_order(content, sender_id)
        elif message_type == "product_inquiry":
            await self.handle_product_inquiry(content, sender_id)
        elif message_type == "lead_time_inquiry":
            await self.handle_lead_time_inquiry(content, sender_id)
        elif message_type == "bulk_discount_inquiry":
            await self.handle_bulk_discount_inquiry(content, sender_id)
        elif message_type == "production_update":
            await self.handle_production_update(content)
    
    async def handle_supplier_order(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle an order from a warehouse.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        order_id = content.get("order_id")
        warehouse_id = content.get("warehouse_id")
        products = content.get("products", {})  # product_id -> quantity
        
        if not order_id or not warehouse_id or not products:
            return
        
        # Create a new pending order
        order = {
            "order_id": order_id,
            "warehouse_id": warehouse_id,
            "warehouse_agent_id": sender_id,
            "products": products,
            "order_date": datetime.now().isoformat(),
            "estimated_delivery_date": (datetime.now() + timedelta(days=self.lead_time)).isoformat(),
            "status": "processing",
            "production_status": {}  # product_id -> {status, completion_percentage}
        }
        
        # Initialize production status for each product
        for product_id, quantity in products.items():
            order["production_status"][product_id] = {
                "status": "queued",
                "completion_percentage": 0
            }
        
        # Add to pending orders
        self.state["pending_orders"].append(order)
        
        # Update production schedule
        await self.update_production_schedule()
        
        # Send acknowledgment to warehouse
        await self.send_message(
            target_agent_id=sender_id,
            message_type="order_acknowledgment",
            content={
                "order_id": order_id,
                "status": "processing",
                "estimated_delivery_date": order["estimated_delivery_date"]
            }
        )
        
        # Store the order in memory
        await self.store_memory("decision", {
            "type": "order_received",
            "order_id": order_id,
            "warehouse_id": warehouse_id,
            "products": products
        })
    
    async def handle_product_inquiry(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a product inquiry from a warehouse.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        product_ids = content.get("product_ids", [])
        
        if not product_ids:
            return
        
        # Prepare product information
        product_info = {}
        for product_id in product_ids:
            if product_id in self.state["products"]:
                product_info[product_id] = self.state["products"][product_id]
            else:
                product_info[product_id] = {"available": False, "reason": "Product not supplied by this supplier"}
        
        # Send response to warehouse
        await self.send_message(
            target_agent_id=sender_id,
            message_type="product_inquiry_response",
            content={
                "product_info": product_info
            }
        )
    
    async def handle_lead_time_inquiry(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a lead time inquiry from a warehouse.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        product_ids = content.get("product_ids", [])
        
        if not product_ids:
            return
        
        # Prepare lead time information
        lead_times = {}
        for product_id in product_ids:
            if product_id in self.state["products"]:
                # Product-specific lead time or default supplier lead time
                product_lead_time = self.state["products"][product_id].get("lead_time", self.lead_time)
                
                # Adjust based on current production load
                production_load_factor = len(self.state["pending_orders"]) / 10  # Simple heuristic
                adjusted_lead_time = product_lead_time * (1 + production_load_factor)
                
                lead_times[product_id] = {
                    "standard_lead_time": product_lead_time,
                    "current_lead_time": round(adjusted_lead_time, 1),
                    "reason": "High production load" if production_load_factor > 0.2 else "Normal production load"
                }
            else:
                lead_times[product_id] = {
                    "available": False,
                    "reason": "Product not supplied by this supplier"
                }
        
        # Send response to warehouse
        await self.send_message(
            target_agent_id=sender_id,
            message_type="lead_time_inquiry_response",
            content={
                "lead_times": lead_times
            }
        )
    
    async def handle_bulk_discount_inquiry(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a bulk discount inquiry from a warehouse.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        product_id = content.get("product_id")
        quantity = content.get("quantity")
        
        if not product_id or not quantity:
            return
        
        # Check if we supply this product
        if product_id not in self.state["products"]:
            await self.send_message(
                target_agent_id=sender_id,
                message_type="bulk_discount_inquiry_response",
                content={
                    "product_id": product_id,
                    "available": False,
                    "reason": "Product not supplied by this supplier"
                }
            )
            return
        
        # Calculate bulk discount
        base_price = self.state["products"][product_id].get("price", 100)  # Default price if not set
        discount_percentage = 0
        
        if quantity >= 1000:
            discount_percentage = 25
        elif quantity >= 500:
            discount_percentage = 20
        elif quantity >= 200:
            discount_percentage = 15
        elif quantity >= 100:
            discount_percentage = 10
        elif quantity >= 50:
            discount_percentage = 5
        
        discounted_price = base_price * (1 - discount_percentage / 100)
        
        # Send response to warehouse
        await self.send_message(
            target_agent_id=sender_id,
            message_type="bulk_discount_inquiry_response",
            content={
                "product_id": product_id,
                "quantity": quantity,
                "base_price": base_price,
                "discount_percentage": discount_percentage,
                "discounted_price": discounted_price,
                "total_price": discounted_price * quantity
            }
        )
    
    async def handle_production_update(self, content: Dict[str, Any]) -> None:
        """
        Handle a production update.
        
        Args:
            content: Content of the message.
        """
        product_id = content.get("product_id")
        production_capacity = content.get("production_capacity")
        stock = content.get("stock")
        
        if product_id is None:
            return
        
        # Update product information
        if product_id in self.state["products"]:
            if production_capacity is not None:
                self.state["products"][product_id]["production_capacity"] = production_capacity
            
            if stock is not None:
                self.state["products"][product_id]["stock"] = stock
        else:
            # New product
            self.state["products"][product_id] = {
                "production_capacity": production_capacity or 100,  # Default capacity
                "stock": stock or 0  # Default stock
            }
        
        self.state["last_production_update"] = datetime.now().isoformat()
        
        # Update production schedule based on new capacity
        await self.update_production_schedule()
    
    async def update_production_schedule(self) -> None:
        """Update the production schedule based on pending orders and production capacity."""
        # Reset production schedule
        self.state["production_schedule"] = {}
        
        # Sort orders by priority (FIFO for now)
        sorted_orders = sorted(
            self.state["pending_orders"],
            key=lambda o: datetime.fromisoformat(o["order_date"])
        )
        
        # Allocate production capacity to orders
        for order in sorted_orders:
            if order["status"] in ["processing", "in_production"]:
                for product_id, quantity in order["products"].items():
                    if product_id not in self.state["production_schedule"]:
                        self.state["production_schedule"][product_id] = []
                    
                    # Add to production schedule
                    self.state["production_schedule"][product_id].append({
                        "order_id": order["order_id"],
                        "quantity": quantity,
                        "priority": 1  # Default priority
                    })
    
    async def advance_production(self) -> None:
        """Advance production for all pending orders."""
        # Update production status for each order
        for i, order in enumerate(self.state["pending_orders"]):
            if order["status"] in ["processing", "in_production"]:
                # Mark as in production
                self.state["pending_orders"][i]["status"] = "in_production"
                
                # Update production status for each product
                all_complete = True
                for product_id, status in order["production_status"].items():
                    if status["status"] != "completed":
                        # Advance production by a random amount (simulating production progress)
                        progress_increment = random.uniform(5, 15)  # 5-15% progress per cycle
                        new_completion = min(100, status["completion_percentage"] + progress_increment)
                        
                        self.state["pending_orders"][i]["production_status"][product_id]["completion_percentage"] = new_completion
                        
                        if new_completion >= 100:
                            self.state["pending_orders"][i]["production_status"][product_id]["status"] = "completed"
                        else:
                            all_complete = False
                
                # If all products are complete, mark the order as ready for shipping
                if all_complete:
                    self.state["pending_orders"][i]["status"] = "ready_for_shipping"
                    
                    # Store the completion in memory
                    await self.store_memory("observation", {
                        "type": "order_production_completed",
                        "order_id": order["order_id"],
                        "warehouse_id": order["warehouse_id"]
                    })
    
    async def ship_completed_orders(self) -> None:
        """Ship orders that are ready for shipping."""
        for i, order in enumerate(self.state["pending_orders"]):
            if order["status"] == "ready_for_shipping":
                # Mark as shipped
                self.state["pending_orders"][i]["status"] = "shipped"
                
                # Calculate actual delivery date (simulating shipping time)
                shipping_days = random.randint(1, 3)  # 1-3 days for shipping
                actual_delivery_date = (datetime.now() + timedelta(days=shipping_days)).isoformat()
                self.state["pending_orders"][i]["actual_delivery_date"] = actual_delivery_date
                
                # Notify warehouse
                await self.send_message(
                    target_agent_id=order["warehouse_agent_id"],
                    message_type="supplier_order_status",
                    content={
                        "order_id": order["order_id"],
                        "status": "shipped",
                        "estimated_delivery_date": actual_delivery_date,
                        "products": order["products"]
                    }
                )
                
                # Store the shipment in memory
                await self.store_memory("decision", {
                    "type": "order_shipped",
                    "order_id": order["order_id"],
                    "warehouse_id": order["warehouse_id"],
                    "products": order["products"],
                    "estimated_delivery_date": actual_delivery_date
                })
    
    async def clean_up_old_orders(self) -> None:
        """Clean up old completed orders from the pending orders list."""
        current_time = datetime.now()
        orders_to_keep = []
        
        for order in self.state["pending_orders"]:
            if order["status"] in ["shipped", "delivered"]:
                # Check if the order is old (more than 30 days)
                if "actual_delivery_date" in order:
                    delivery_date = datetime.fromisoformat(order["actual_delivery_date"])
                    if (current_time - delivery_date).days <= 30:
                        orders_to_keep.append(order)
                else:
                    orders_to_keep.append(order)
            else:
                orders_to_keep.append(order)
        
        # Update pending orders
        self.state["pending_orders"] = orders_to_keep
    
    async def take_action(self) -> None:
        """Take action based on the agent's current state."""
        # Advance production for pending orders
        await self.advance_production()
        
        # Ship completed orders
        await self.ship_completed_orders()
        
        # Clean up old orders
        await self.clean_up_old_orders()
        
        # In a real system, we would also:
        # - Optimize production scheduling
        # - Predict raw material needs
        # - Adjust production capacity
        # - Negotiate with warehouses on bulk orders
        # - etc.
