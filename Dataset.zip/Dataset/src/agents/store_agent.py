import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import random
import logging
import pandas as pd

from .base_agent import Agent
from src.models.intelligence_module import IntelligenceModule

logger = logging.getLogger(__name__)

class StoreAgent(Agent):
    """Agent representing a retail store."""

    def __init__(self, store_id: int, name: str, location: str, intelligence_module: Optional[IntelligenceModule] = None, message_bus = None):
        """
        Initialize a store agent.

        Args:
            store_id: ID of the store in the database.
            name: Name of the store.
            location: Location of the store.
            intelligence_module: Optional intelligence module for advanced decision-making.
            message_bus: Optional message bus for agent communication.
        """
        super().__init__(agent_id=f"store_{store_id}", agent_type="store", message_bus=message_bus)
        self.store_id = store_id
        self.name = name
        self.location = location
        self.intelligence_module = intelligence_module

        # Initialize state with store-specific information
        self.state = {
            "store_id": store_id,
            "name": name,
            "location": location,
            "inventory": {},
            "sales": [],
            "pending_orders": [],
            "stockouts": [],
            "overstocked_items": [],
            "last_inventory_check": None,
            "price_adjustments": [],
            "promotions": [],
            "performance_metrics": {
                "stockout_rate": 0,
                "inventory_turnover": 0,
                "sales_growth": 0,
                "profit_margin": 0
            }
        }

    async def process_message(self, message: Dict[str, Any]) -> None:
        """
        Process a received message.

        Args:
            message: The message to process.
        """
        sender_id = message.get("sender_id")
        message_type = message.get("message_type")
        content = message.get("content", {})

        # Store the interaction in memory
        await self.store_memory("interaction", {
            "sender_id": sender_id,
            "message_type": message_type,
            "content_summary": str(content)[:100]  # Store a summary of the content
        })

        if message_type == "inventory_update":
            await self.handle_inventory_update(content)
        elif message_type == "sales_update":
            await self.handle_sales_update(content)
        elif message_type == "order_status":
            await self.handle_order_status(content)
        elif message_type == "price_recommendation":
            await self.handle_price_recommendation(content)
        elif message_type == "warehouse_query":
            await self.handle_warehouse_query(content, sender_id)
        elif message_type == "customer_query":
            await self.handle_customer_query(content, sender_id)

    async def handle_inventory_update(self, content: Dict[str, Any]) -> None:
        """
        Handle an inventory update message.

        Args:
            content: Content of the message.
        """
        product_id = content.get("product_id")
        quantity = content.get("quantity")

        if product_id and quantity is not None:
            # Update inventory in state
            self.state["inventory"][product_id] = quantity

            # Check if this resolves a stockout
            if product_id in self.state["stockouts"] and quantity > 0:
                self.state["stockouts"].remove(product_id)

            # Store the update in memory
            await self.store_memory("observation", {
                "type": "inventory_update",
                "product_id": product_id,
                "quantity": quantity
            })

    async def handle_sales_update(self, content: Dict[str, Any]) -> None:
        """
        Handle a sales update message.

        Args:
            content: Content of the message.
        """
        sale = content.get("sale", {})

        if sale:
            # Add to sales history
            self.state["sales"].append(sale)

            # Update inventory
            product_id = sale.get("product_id")
            quantity_sold = sale.get("quantity", 0)

            if product_id in self.state["inventory"]:
                current_quantity = self.state["inventory"][product_id]
                new_quantity = max(0, current_quantity - quantity_sold)
                self.state["inventory"][product_id] = new_quantity

                # Check for stockout
                if new_quantity == 0 and product_id not in self.state["stockouts"]:
                    self.state["stockouts"].append(product_id)

            # Store the sale in memory
            await self.store_memory("observation", {
                "type": "sale",
                "product_id": product_id,
                "quantity": quantity_sold,
                "revenue": sale.get("price", 0) * quantity_sold
            })

    async def handle_order_status(self, content: Dict[str, Any]) -> None:
        """
        Handle an order status message.

        Args:
            content: Content of the message.
        """
        order_id = content.get("order_id")
        status = content.get("status")

        if order_id and status:
            # Update pending orders
            for i, order in enumerate(self.state["pending_orders"]):
                if order.get("order_id") == order_id:
                    self.state["pending_orders"][i]["status"] = status

                    # If order is delivered, update inventory
                    if status == "delivered":
                        for item in order.get("items", []):
                            product_id = item.get("product_id")
                            quantity = item.get("quantity", 0)

                            if product_id in self.state["inventory"]:
                                self.state["inventory"][product_id] += quantity
                            else:
                                self.state["inventory"][product_id] = quantity

                            # Check if this resolves a stockout
                            if product_id in self.state["stockouts"]:
                                self.state["stockouts"].remove(product_id)

                    break

            # Store the update in memory
            await self.store_memory("observation", {
                "type": "order_status",
                "order_id": order_id,
                "status": status
            })

    async def handle_price_recommendation(self, content: Dict[str, Any]) -> None:
        """
        Handle a price recommendation message.

        Args:
            content: Content of the message.
        """
        product_id = content.get("product_id")
        recommended_price = content.get("recommended_price")

        if product_id and recommended_price:
            # Store the recommendation in memory
            await self.store_memory("recommendation", {
                "type": "price",
                "product_id": product_id,
                "recommended_price": recommended_price,
                "current_price": content.get("current_price"),
                "reason": content.get("reason", "")
            })

    async def handle_warehouse_query(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a query from a warehouse.

        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        query_type = content.get("query_type")

        if query_type == "inventory_status":
            # Respond with current inventory status
            response = {
                "inventory": self.state["inventory"],
                "stockouts": self.state["stockouts"],
                "overstocked_items": self.state["overstocked_items"]
            }

            await self.send_message(
                target_agent_id=sender_id,
                message_type="inventory_status_response",
                content=response
            )
        elif query_type == "sales_history":
            # Respond with sales history
            time_period = content.get("time_period", 30)  # Default to 30 days

            # Filter sales by time period
            cutoff_date = datetime.now() - timedelta(days=time_period)
            recent_sales = [
                sale for sale in self.state["sales"]
                if datetime.fromisoformat(sale.get("date", datetime.now().isoformat())) >= cutoff_date
            ]

            response = {
                "sales": recent_sales,
                "time_period": time_period
            }

            await self.send_message(
                target_agent_id=sender_id,
                message_type="sales_history_response",
                content=response
            )

    async def handle_customer_query(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a query from a customer.

        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        query_type = content.get("query_type")

        if query_type == "product_availability":
            product_id = content.get("product_id")

            if product_id in self.state["inventory"]:
                availability = self.state["inventory"][product_id] > 0
                quantity = self.state["inventory"][product_id]
            else:
                availability = False
                quantity = 0

            response = {
                "product_id": product_id,
                "available": availability,
                "quantity": quantity
            }

            await self.send_message(
                target_agent_id=sender_id,
                message_type="product_availability_response",
                content=response
            )

    async def check_inventory(self) -> None:
        """Check inventory levels and identify stockouts and overstocked items using the intelligence module if available."""
        stockouts = []
        overstocked_items = []
        reorder_recommendations = []

        # Use intelligence module if available
        if self.intelligence_module:
            try:
                # Get product data
                product_data = {}
                for product_id, quantity in self.state["inventory"].items():
                    # In a real system, we would get this data from the database
                    # For now, we'll use placeholders
                    product_data[product_id] = {
                        "cost": 50.0,  # Placeholder
                        "current_inventory": quantity
                    }

                # Convert sales history to DataFrame
                sales_data = pd.DataFrame(self.state["sales"])

                # If no sales data, create a minimal DataFrame
                if sales_data.empty:
                    sales_data = pd.DataFrame(columns=["product_id", "quantity", "price", "date"])

                # Process each product
                for product_id, data in product_data.items():
                    # Filter sales data for this product
                    product_sales = sales_data[sales_data["product_id"] == product_id].copy() if not sales_data.empty else pd.DataFrame()

                    # Check if we have enough data
                    if not product_sales.empty:
                        # Optimize inventory
                        optimization_result = await self.intelligence_module.optimize_inventory(
                            product_id=product_id,
                            cost=data["cost"],
                            current_inventory=data["current_inventory"],
                            sales_data=product_sales
                        )

                        # Check if we need to reorder
                        if data["current_inventory"] <= optimization_result["optimization"]["reorder_point"]:
                            reorder_recommendations.append({
                                "product_id": product_id,
                                "current_inventory": data["current_inventory"],
                                "reorder_point": optimization_result["optimization"]["reorder_point"],
                                "order_quantity": optimization_result["optimization"]["order_quantity"],
                                "priority": "high" if data["current_inventory"] == 0 else "medium"
                            })

                        # Check for stockouts
                        if data["current_inventory"] == 0:
                            stockouts.append(product_id)

                        # Check for overstocked items
                        max_inventory = optimization_result["optimization"]["max_inventory"]
                        if data["current_inventory"] > max_inventory * 1.2:  # 20% over max
                            overstocked_items.append(product_id)
                    else:
                        # Use basic checks if no sales data
                        await self._basic_inventory_check(product_id, data["current_inventory"], stockouts, overstocked_items)

                logger.info(f"Store {self.store_id}: Intelligent inventory check completed with {len(stockouts)} stockouts, {len(overstocked_items)} overstocked items")

            except Exception as e:
                logger.error(f"Store {self.store_id}: Error in intelligent inventory check: {e}")
                # Fall back to basic inventory check
                await self._basic_inventory_check_all(stockouts, overstocked_items)
        else:
            # Use basic inventory check
            await self._basic_inventory_check_all(stockouts, overstocked_items)

        # Update state
        self.state["stockouts"] = stockouts
        self.state["overstocked_items"] = overstocked_items
        self.state["reorder_recommendations"] = reorder_recommendations
        self.state["last_inventory_check"] = datetime.now().isoformat()

        # Calculate inventory metrics
        total_inventory_value = sum(self.state["inventory"].values())
        total_products = len(self.state["inventory"])
        stockout_rate = len(stockouts) / total_products if total_products > 0 else 0

        # Update performance metrics
        self.state["performance_metrics"]["stockout_rate"] = stockout_rate

        # Store the inventory check in memory
        await self.store_memory("observation", {
            "type": "inventory_check",
            "stockouts": len(stockouts),
            "overstocked_items": len(overstocked_items),
            "total_products": total_products,
            "total_inventory_value": total_inventory_value,
            "stockout_rate": stockout_rate
        })

        # If we have stockouts, request restocking
        if stockouts or reorder_recommendations:
            products_to_restock = stockouts.copy()

            # Add products from reorder recommendations that aren't already in stockouts
            for rec in reorder_recommendations:
                product_id = rec["product_id"]
                if product_id not in products_to_restock:
                    products_to_restock.append(product_id)

            if products_to_restock:
                await self.request_restock(products_to_restock)

    async def _basic_inventory_check_all(self, stockouts: List[int], overstocked_items: List[int]) -> None:
        """Perform basic inventory check for all products."""
        for product_id, quantity in self.state["inventory"].items():
            await self._basic_inventory_check(product_id, quantity, stockouts, overstocked_items)

    async def _basic_inventory_check(self, product_id: int, quantity: int, stockouts: List[int], overstocked_items: List[int]) -> None:
        """Perform basic inventory check for a single product."""
        # Check for stockouts
        if quantity == 0:
            stockouts.append(product_id)

        # Check for overstocked items
        # This would typically compare against max_level from the database
        # For now, we'll use a simple heuristic
        if quantity > 100:  # Arbitrary threshold
            overstocked_items.append(product_id)

    async def request_restock(self, product_ids: List[int]) -> None:
        """
        Request restocking for specified products.

        Args:
            product_ids: List of product IDs to restock.
        """
        if not product_ids:
            return

        # Find a warehouse agent to send the request to
        warehouse_agents = [conn for conn in self.connections if conn.agent_type == "warehouse"]

        if not warehouse_agents:
            # Store the failed request in memory
            await self.store_memory("decision", {
                "type": "restock_request_failed",
                "reason": "No warehouse agents connected",
                "product_ids": product_ids
            })
            return

        # Select a warehouse (in a real system, this would be more sophisticated)
        warehouse = warehouse_agents[0]

        # Create restock request
        restock_request = {
            "store_id": self.store_id,
            "product_ids": product_ids,
            "quantities": {pid: max(10, random.randint(20, 50)) for pid in product_ids}  # Simple quantity calculation
        }

        # Send request to warehouse
        await self.send_message(
            target_agent_id=warehouse.agent_id,
            message_type="restock_request",
            content=restock_request
        )

        # Store the request in memory
        await self.store_memory("decision", {
            "type": "restock_request",
            "warehouse_id": warehouse.agent_id,
            "product_ids": product_ids,
            "quantities": restock_request["quantities"]
        })

    async def adjust_prices(self) -> None:
        """Adjust prices based on inventory levels using the intelligence module if available."""
        price_adjustments = []

        # Use intelligence module if available
        if self.intelligence_module:
            try:
                # Get product data
                product_data = {}
                for product_id, quantity in self.state["inventory"].items():
                    # In a real system, we would get this data from the database
                    # For now, we'll use placeholders
                    product_data[product_id] = {
                        "cost": 50.0,  # Placeholder
                        "current_price": 100.0,  # Placeholder
                        "current_inventory": quantity,
                        "target_inventory": 30  # Placeholder
                    }

                # Convert sales history to DataFrame
                sales_data = pd.DataFrame(self.state["sales"])

                # If no sales data, create a minimal DataFrame
                if sales_data.empty:
                    sales_data = pd.DataFrame(columns=["product_id", "quantity", "price", "date"])

                # Process each product
                for product_id, data in product_data.items():
                    # Skip products with no inventory
                    if data["current_inventory"] <= 0:
                        continue

                    # Filter sales data for this product
                    product_sales = sales_data[sales_data["product_id"] == product_id].copy() if not sales_data.empty else pd.DataFrame()

                    # Optimize pricing
                    pricing_result = await self.intelligence_module.optimize_pricing(
                        product_id=product_id,
                        cost=data["cost"],
                        current_price=data["current_price"],
                        current_inventory=data["current_inventory"],
                        target_inventory=data["target_inventory"],
                        sales_data=product_sales
                    )

                    # Add to price adjustments if price changed
                    if abs(pricing_result["price_change_pct"]) >= 1.0:  # At least 1% change
                        price_adjustments.append({
                            "product_id": product_id,
                            "old_price": data["current_price"],
                            "new_price": pricing_result["optimal_price"],
                            "change_pct": pricing_result["price_change_pct"],
                            "reason": pricing_result["price_change_reason"]
                        })

                    # Store promotions if any
                    if "promotions" in pricing_result and pricing_result["promotions"]:
                        self.state["promotions"] = pricing_result["promotions"]

                logger.info(f"Store {self.store_id}: Intelligent price optimization completed with {len(price_adjustments)} adjustments")

            except Exception as e:
                logger.error(f"Store {self.store_id}: Error in intelligent price optimization: {e}")
                # Fall back to basic price adjustment
                price_adjustments = await self._basic_price_adjustment()
        else:
            # Use basic price adjustment
            price_adjustments = await self._basic_price_adjustment()

        if price_adjustments:
            # Store the adjustments
            self.state["price_adjustments"] = price_adjustments

            # Store the decision in memory
            await self.store_memory("decision", {
                "type": "price_adjustments",
                "adjustments": price_adjustments
            })

            # Notify other agents about price changes
            for adjustment in price_adjustments:
                await self.send_message(
                    target_agent_id="all",  # Broadcast to all agents
                    message_type="price_update",
                    content={
                        "store_id": self.store_id,
                        "product_id": adjustment["product_id"],
                        "old_price": adjustment["old_price"],
                        "new_price": adjustment["new_price"],
                        "reason": adjustment["reason"]
                    }
                )

    async def _basic_price_adjustment(self) -> List[Dict[str, Any]]:
        """Basic price adjustment logic without intelligence module."""
        price_adjustments = []

        # Increase prices for products with low inventory
        for product_id, quantity in self.state["inventory"].items():
            if 0 < quantity <= 10:  # Low inventory but not stockout
                # In a real system, we would get the current price from the database
                # For now, we'll use a placeholder
                current_price = 100.0  # Placeholder
                new_price = current_price * 1.1  # 10% increase

                price_adjustments.append({
                    "product_id": product_id,
                    "old_price": current_price,
                    "new_price": new_price,
                    "change_pct": 10.0,
                    "reason": "low_inventory"
                })

        # Decrease prices for overstocked items
        for product_id in self.state["overstocked_items"]:
            # In a real system, we would get the current price from the database
            current_price = 100.0  # Placeholder
            new_price = current_price * 0.9  # 10% decrease

            price_adjustments.append({
                "product_id": product_id,
                "old_price": current_price,
                "new_price": new_price,
                "change_pct": -10.0,
                "reason": "overstock"
            })

        return price_adjustments

    async def take_action(self) -> None:
        """Take action based on the agent's current state."""
        try:
            # Check if it's time to check inventory (every hour)
            last_check = self.state.get("last_inventory_check")
            if last_check is None or (datetime.now() - datetime.fromisoformat(last_check)).total_seconds() > 3600:
                await self.check_inventory()

            # Adjust prices based on inventory levels (every 4 hours)
            last_price_adjustment = self.state.get("last_price_adjustment")
            if last_price_adjustment is None or (datetime.now() - datetime.fromisoformat(last_price_adjustment)).total_seconds() > 14400:
                await self.adjust_prices()
                self.state["last_price_adjustment"] = datetime.now().isoformat()

            # Apply promotions if available
            if self.state.get("promotions") and random.random() < 0.1:  # 10% chance each cycle
                await self.apply_promotions()

            # Report performance metrics to coordinator (every 12 hours)
            last_report = self.state.get("last_performance_report")
            if last_report is None or (datetime.now() - datetime.fromisoformat(last_report)).total_seconds() > 43200:
                await self.report_performance_metrics()
                self.state["last_performance_report"] = datetime.now().isoformat()

            # Handle customer queries (random chance)
            if random.random() < 0.2:  # 20% chance each cycle
                await self.handle_random_customer_query()

            # Update inventory based on sales (simulate sales)
            if random.random() < 0.3:  # 30% chance each cycle
                await self.simulate_sales()

        except Exception as e:
            logger.error(f"Store {self.store_id}: Error in take_action: {e}")

    async def apply_promotions(self) -> None:
        """Apply promotions to products."""
        if not self.state.get("promotions"):
            return

        # Get a random promotion
        promotion = random.choice(self.state["promotions"])

        # Notify customers about the promotion
        customer_agents = [conn for conn in self.connections if conn.agent_type == "customer"]

        if customer_agents:
            # Select a random subset of customers
            target_customers = random.sample(customer_agents, min(3, len(customer_agents)))

            for customer in target_customers:
                await self.send_message(
                    target_agent_id=customer.agent_id,
                    message_type="promotion",
                    content=promotion
                )

            # Store the promotion application in memory
            await self.store_memory("decision", {
                "type": "promotion_applied",
                "promotion": promotion,
                "target_customers": len(target_customers)
            })

    async def report_performance_metrics(self) -> None:
        """Report performance metrics to the coordinator."""
        # Find coordinator agent
        coordinator_agents = [conn for conn in self.connections if conn.agent_type == "coordinator"]

        if not coordinator_agents:
            return

        coordinator = coordinator_agents[0]

        # Send performance metrics
        await self.send_message(
            target_agent_id=coordinator.agent_id,
            message_type="performance_metrics",
            content={
                "metrics": self.state["performance_metrics"],
                "store_id": self.store_id,
                "timestamp": datetime.now().isoformat()
            }
        )

    async def handle_random_customer_query(self) -> None:
        """Simulate handling a random customer query."""
        # Only proceed if we have inventory
        if not self.state["inventory"]:
            return

        # Select a random product
        product_id = random.choice(list(self.state["inventory"].keys()))
        quantity = self.state["inventory"][product_id]

        # Create a simulated customer query response
        response = {
            "product_id": product_id,
            "available": quantity > 0,
            "quantity": quantity,
            "estimated_restock_date": (datetime.now() + timedelta(days=3)).isoformat() if quantity == 0 else None
        }

        # Store the customer interaction in memory
        await self.store_memory("interaction", {
            "type": "customer_query",
            "product_id": product_id,
            "response": response
        })

    async def simulate_sales(self) -> None:
        """Simulate sales transactions."""
        # Only proceed if we have inventory
        if not self.state["inventory"]:
            return

        # Select 1-3 random products
        num_products = min(random.randint(1, 3), len(self.state["inventory"]))
        product_ids = random.sample(list(self.state["inventory"].keys()), num_products)

        for product_id in product_ids:
            current_quantity = self.state["inventory"][product_id]

            if current_quantity > 0:
                # Simulate a sale of 1-3 units
                sale_quantity = min(random.randint(1, 3), current_quantity)

                # Update inventory
                self.state["inventory"][product_id] -= sale_quantity

                # Record the sale
                sale = {
                    "product_id": product_id,
                    "quantity": sale_quantity,
                    "price": 100.0,  # Placeholder
                    "date": datetime.now().isoformat(),
                    "customer_id": random.randint(1, 10)  # Random customer ID
                }

                self.state["sales"].append(sale)

                # Check if this created a stockout
                if self.state["inventory"][product_id] == 0 and product_id not in self.state["stockouts"]:
                    self.state["stockouts"].append(product_id)

                    # Notify warehouse of stockout
                    warehouse_agents = [conn for conn in self.connections if conn.agent_type == "warehouse"]

                    if warehouse_agents:
                        warehouse = warehouse_agents[0]

                        await self.send_message(
                            target_agent_id=warehouse.agent_id,
                            message_type="stockout_notification",
                            content={
                                "store_id": self.store_id,
                                "product_id": product_id,
                                "timestamp": datetime.now().isoformat()
                            }
                        )

                # Store the sale in memory
                await self.store_memory("observation", {
                    "type": "sale",
                    "product_id": product_id,
                    "quantity": sale_quantity,
                    "revenue": sale["price"] * sale_quantity
                })
