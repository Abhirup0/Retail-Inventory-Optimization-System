import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import random

from .base_agent import Agent

class CoordinatorAgent(Agent):
    """Agent responsible for coordinating communication between other agents and ensuring system-wide optimization."""
    
    def __init__(self, coordinator_id: str = "main_coordinator"):
        """
        Initialize a coordinator agent.
        
        Args:
            coordinator_id: ID of the coordinator.
        """
        super().__init__(agent_id=coordinator_id, agent_type="coordinator")
        
        # Initialize state with coordinator-specific information
        self.state = {
            "agent_registry": {},  # agent_id -> {agent_type, status, last_seen, performance_metrics}
            "system_metrics": {
                "stockout_rate": 0,
                "inventory_turnover": 0,
                "order_fill_rate": 0,
                "average_lead_time": 0
            },
            "optimization_goals": {
                "reduce_stockouts": True,
                "minimize_holding_costs": True,
                "improve_order_fill_rate": True,
                "reduce_lead_times": True
            },
            "conflict_resolution_queue": [],
            "system_alerts": [],
            "last_system_check": None
        }
    
    async def register_agent(self, agent: Agent) -> None:
        """
        Register an agent with the coordinator.
        
        Args:
            agent: The agent to register.
        """
        self.state["agent_registry"][agent.agent_id] = {
            "agent_type": agent.agent_type,
            "status": "active",
            "last_seen": datetime.now().isoformat(),
            "performance_metrics": {}
        }
        
        # Connect to the agent
        await self.connect(agent)
        await agent.connect(self)
        
        # Send welcome message
        await self.send_message(
            target_agent_id=agent.agent_id,
            message_type="registration_confirmation",
            content={
                "status": "registered",
                "timestamp": datetime.now().isoformat(),
                "coordinator_id": self.agent_id
            }
        )
        
        # Store the registration in memory
        await self.store_memory("system", {
            "type": "agent_registration",
            "agent_id": agent.agent_id,
            "agent_type": agent.agent_type
        })
    
    async def process_message(self, message: Dict[str, Any]) -> None:
        """
        Process a received message.
        
        Args:
            message: The message to process.
        """
        sender_id = message.get("sender_id")
        message_type = message.get("message_type")
        content = message.get("content", {})
        
        # Update agent's last seen timestamp
        if sender_id in self.state["agent_registry"]:
            self.state["agent_registry"][sender_id]["last_seen"] = datetime.now().isoformat()
        
        # Store the interaction in memory
        await self.store_memory("interaction", {
            "sender_id": sender_id,
            "message_type": message_type,
            "content_summary": str(content)[:100]  # Store a summary of the content
        })
        
        if message_type == "status_update":
            await self.handle_status_update(content, sender_id)
        elif message_type == "performance_metrics":
            await self.handle_performance_metrics(content, sender_id)
        elif message_type == "conflict_resolution_request":
            await self.handle_conflict_resolution_request(content, sender_id)
        elif message_type == "system_alert":
            await self.handle_system_alert(content, sender_id)
        elif message_type == "optimization_request":
            await self.handle_optimization_request(content, sender_id)
    
    async def handle_status_update(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a status update from an agent.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        status = content.get("status")
        
        if not status:
            return
        
        # Update agent status
        if sender_id in self.state["agent_registry"]:
            self.state["agent_registry"][sender_id]["status"] = status
            
            # If agent is reporting issues, add to system alerts
            if status in ["error", "warning", "overloaded"]:
                self.state["system_alerts"].append({
                    "agent_id": sender_id,
                    "alert_type": f"agent_{status}",
                    "timestamp": datetime.now().isoformat(),
                    "details": content.get("details", "No details provided")
                })
                
                # Store the alert in memory
                await self.store_memory("system", {
                    "type": "agent_status_alert",
                    "agent_id": sender_id,
                    "status": status,
                    "details": content.get("details", "No details provided")
                })
    
    async def handle_performance_metrics(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle performance metrics from an agent.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        metrics = content.get("metrics", {})
        
        if not metrics:
            return
        
        # Update agent performance metrics
        if sender_id in self.state["agent_registry"]:
            self.state["agent_registry"][sender_id]["performance_metrics"] = metrics
            
            # Store the metrics in memory
            await self.store_memory("system", {
                "type": "agent_performance_metrics",
                "agent_id": sender_id,
                "metrics": metrics
            })
            
            # Update system-wide metrics based on agent type
            agent_type = self.state["agent_registry"][sender_id]["agent_type"]
            
            if agent_type == "store":
                # Update stockout rate if provided
                if "stockout_rate" in metrics:
                    # Simple average of all store stockout rates
                    store_agents = [
                        agent_id for agent_id, info in self.state["agent_registry"].items()
                        if info["agent_type"] == "store" and "performance_metrics" in info
                        and "stockout_rate" in info["performance_metrics"]
                    ]
                    
                    if store_agents:
                        avg_stockout_rate = sum(
                            self.state["agent_registry"][agent_id]["performance_metrics"]["stockout_rate"]
                            for agent_id in store_agents
                        ) / len(store_agents)
                        
                        self.state["system_metrics"]["stockout_rate"] = avg_stockout_rate
            
            elif agent_type == "warehouse":
                # Update order fill rate if provided
                if "order_fill_rate" in metrics:
                    self.state["system_metrics"]["order_fill_rate"] = metrics["order_fill_rate"]
            
            elif agent_type == "supplier":
                # Update average lead time if provided
                if "average_lead_time" in metrics:
                    # Simple average of all supplier lead times
                    supplier_agents = [
                        agent_id for agent_id, info in self.state["agent_registry"].items()
                        if info["agent_type"] == "supplier" and "performance_metrics" in info
                        and "average_lead_time" in info["performance_metrics"]
                    ]
                    
                    if supplier_agents:
                        avg_lead_time = sum(
                            self.state["agent_registry"][agent_id]["performance_metrics"]["average_lead_time"]
                            for agent_id in supplier_agents
                        ) / len(supplier_agents)
                        
                        self.state["system_metrics"]["average_lead_time"] = avg_lead_time
    
    async def handle_conflict_resolution_request(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a conflict resolution request from an agent.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        conflict_type = content.get("conflict_type")
        parties = content.get("parties", [])
        details = content.get("details", {})
        
        if not conflict_type or not parties:
            return
        
        # Add to conflict resolution queue
        conflict = {
            "conflict_id": f"conflict_{datetime.now().timestamp()}",
            "conflict_type": conflict_type,
            "parties": parties,
            "details": details,
            "status": "pending",
            "timestamp": datetime.now().isoformat(),
            "resolution": None
        }
        
        self.state["conflict_resolution_queue"].append(conflict)
        
        # Store the conflict in memory
        await self.store_memory("system", {
            "type": "conflict_resolution_request",
            "conflict_type": conflict_type,
            "parties": parties,
            "details": details
        })
        
        # Process the conflict immediately
        await self.resolve_conflict(conflict)
    
    async def resolve_conflict(self, conflict: Dict[str, Any]) -> None:
        """
        Resolve a conflict between agents.
        
        Args:
            conflict: The conflict to resolve.
        """
        conflict_type = conflict.get("conflict_type")
        parties = conflict.get("parties", [])
        details = conflict.get("details", {})
        
        resolution = None
        
        # Different resolution strategies based on conflict type
        if conflict_type == "inventory_allocation":
            # Conflict over which store gets limited inventory
            requesting_stores = details.get("requesting_stores", {})
            available_quantity = details.get("available_quantity", 0)
            
            if requesting_stores and available_quantity > 0:
                # Allocate based on priority and need
                allocations = {}
                remaining = available_quantity
                
                # First pass: allocate to stores with stockouts
                for store_id, request in requesting_stores.items():
                    if request.get("stockout", False) and remaining > 0:
                        # Allocate minimum of requested quantity or remaining
                        allocation = min(request.get("quantity", 0), remaining)
                        allocations[store_id] = allocation
                        remaining -= allocation
                
                # Second pass: allocate remaining inventory proportionally
                if remaining > 0 and len(requesting_stores) > len(allocations):
                    remaining_stores = {
                        store_id: request for store_id, request in requesting_stores.items()
                        if store_id not in allocations
                    }
                    
                    total_requested = sum(request.get("quantity", 0) for request in remaining_stores.values())
                    
                    if total_requested > 0:
                        for store_id, request in remaining_stores.items():
                            # Proportional allocation
                            proportion = request.get("quantity", 0) / total_requested
                            allocation = min(int(remaining * proportion), request.get("quantity", 0))
                            allocations[store_id] = allocation
                
                resolution = {
                    "type": "inventory_allocation",
                    "allocations": allocations
                }
        
        elif conflict_type == "delivery_priority":
            # Conflict over which order gets delivered first
            orders = details.get("orders", [])
            
            if orders:
                # Prioritize based on stockouts, order date, and customer priority
                prioritized_orders = sorted(
                    orders,
                    key=lambda o: (
                        o.get("has_stockouts", False),  # Stockouts first
                        o.get("customer_priority", 0),  # Higher priority customers
                        datetime.fromisoformat(o.get("order_date", datetime.now().isoformat()))  # Older orders
                    ),
                    reverse=True
                )
                
                resolution = {
                    "type": "delivery_priority",
                    "prioritized_orders": [order.get("order_id") for order in prioritized_orders]
                }
        
        # Update conflict with resolution
        for i, c in enumerate(self.state["conflict_resolution_queue"]):
            if c.get("conflict_id") == conflict.get("conflict_id"):
                self.state["conflict_resolution_queue"][i]["status"] = "resolved"
                self.state["conflict_resolution_queue"][i]["resolution"] = resolution
                break
        
        # Notify parties of the resolution
        for party in parties:
            await self.send_message(
                target_agent_id=party,
                message_type="conflict_resolution",
                content={
                    "conflict_id": conflict.get("conflict_id"),
                    "conflict_type": conflict_type,
                    "resolution": resolution
                }
            )
        
        # Store the resolution in memory
        await self.store_memory("decision", {
            "type": "conflict_resolution",
            "conflict_type": conflict_type,
            "parties": parties,
            "resolution": resolution
        })
    
    async def handle_system_alert(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle a system alert from an agent.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        alert_type = content.get("alert_type")
        details = content.get("details", {})
        
        if not alert_type:
            return
        
        # Add to system alerts
        alert = {
            "alert_id": f"alert_{datetime.now().timestamp()}",
            "alert_type": alert_type,
            "source_agent": sender_id,
            "details": details,
            "timestamp": datetime.now().isoformat(),
            "status": "new"
        }
        
        self.state["system_alerts"].append(alert)
        
        # Store the alert in memory
        await self.store_memory("system", {
            "type": "system_alert",
            "alert_type": alert_type,
            "source_agent": sender_id,
            "details": details
        })
        
        # Process the alert
        await self.process_alert(alert)
    
    async def process_alert(self, alert: Dict[str, Any]) -> None:
        """
        Process a system alert.
        
        Args:
            alert: The alert to process.
        """
        alert_type = alert.get("alert_type")
        details = alert.get("details", {})
        
        # Different processing strategies based on alert type
        if alert_type == "stockout":
            # Alert about a stockout
            store_id = details.get("store_id")
            product_id = details.get("product_id")
            
            if store_id and product_id:
                # Find warehouse agents
                warehouse_agents = [
                    agent_id for agent_id, info in self.state["agent_registry"].items()
                    if info["agent_type"] == "warehouse"
                ]
                
                # Notify warehouses of the stockout
                for warehouse_id in warehouse_agents:
                    await self.send_message(
                        target_agent_id=warehouse_id,
                        message_type="stockout_notification",
                        content={
                            "store_id": store_id,
                            "product_id": product_id,
                            "priority": "high"
                        }
                    )
        
        elif alert_type == "low_warehouse_inventory":
            # Alert about low warehouse inventory
            warehouse_id = details.get("warehouse_id")
            product_id = details.get("product_id")
            
            if warehouse_id and product_id:
                # Find supplier agents
                supplier_agents = [
                    agent_id for agent_id, info in self.state["agent_registry"].items()
                    if info["agent_type"] == "supplier"
                ]
                
                # Notify suppliers of the low inventory
                for supplier_id in supplier_agents:
                    await self.send_message(
                        target_agent_id=supplier_id,
                        message_type="low_inventory_notification",
                        content={
                            "warehouse_id": warehouse_id,
                            "product_id": product_id,
                            "priority": "medium"
                        }
                    )
        
        elif alert_type == "delivery_delay":
            # Alert about a delivery delay
            supplier_id = details.get("supplier_id")
            order_id = details.get("order_id")
            
            if supplier_id and order_id:
                # Find affected warehouse
                warehouse_id = details.get("warehouse_id")
                
                if warehouse_id:
                    # Notify warehouse of the delay
                    await self.send_message(
                        target_agent_id=warehouse_id,
                        message_type="delivery_delay_notification",
                        content={
                            "supplier_id": supplier_id,
                            "order_id": order_id,
                            "new_delivery_date": details.get("new_delivery_date"),
                            "reason": details.get("reason", "Unknown reason")
                        }
                    )
        
        # Update alert status
        for i, a in enumerate(self.state["system_alerts"]):
            if a.get("alert_id") == alert.get("alert_id"):
                self.state["system_alerts"][i]["status"] = "processed"
                break
    
    async def handle_optimization_request(self, content: Dict[str, Any], sender_id: str) -> None:
        """
        Handle an optimization request from an agent.
        
        Args:
            content: Content of the message.
            sender_id: ID of the sender.
        """
        optimization_type = content.get("optimization_type")
        parameters = content.get("parameters", {})
        
        if not optimization_type:
            return
        
        # Store the request in memory
        await self.store_memory("system", {
            "type": "optimization_request",
            "optimization_type": optimization_type,
            "source_agent": sender_id,
            "parameters": parameters
        })
        
        # Process the optimization request
        if optimization_type == "inventory_rebalancing":
            await self.optimize_inventory_rebalancing(parameters, sender_id)
        elif optimization_type == "order_batching":
            await self.optimize_order_batching(parameters, sender_id)
        elif optimization_type == "pricing_strategy":
            await self.optimize_pricing_strategy(parameters, sender_id)
    
    async def optimize_inventory_rebalancing(self, parameters: Dict[str, Any], requester_id: str) -> None:
        """
        Optimize inventory rebalancing across stores.
        
        Args:
            parameters: Parameters for the optimization.
            requester_id: ID of the agent that requested the optimization.
        """
        product_id = parameters.get("product_id")
        store_inventory = parameters.get("store_inventory", {})
        
        if not product_id or not store_inventory:
            return
        
        # Find stores with excess inventory and stores with shortages
        excess_stores = {}
        shortage_stores = {}
        
        for store_id, inventory in store_inventory.items():
            quantity = inventory.get("quantity", 0)
            min_level = inventory.get("min_level", 0)
            max_level = inventory.get("max_level", 100)
            
            if quantity < min_level:
                # Store has shortage
                shortage_stores[store_id] = {
                    "current": quantity,
                    "min_level": min_level,
                    "shortage": min_level - quantity
                }
            elif quantity > max_level:
                # Store has excess
                excess_stores[store_id] = {
                    "current": quantity,
                    "max_level": max_level,
                    "excess": quantity - max_level
                }
        
        # Calculate rebalancing plan
        rebalancing_plan = []
        
        # Sort stores by shortage/excess amount
        sorted_shortage_stores = sorted(
            shortage_stores.items(),
            key=lambda x: x[1]["shortage"],
            reverse=True
        )
        
        sorted_excess_stores = sorted(
            excess_stores.items(),
            key=lambda x: x[1]["excess"],
            reverse=True
        )
        
        # Match excess stores with shortage stores
        for shortage_store_id, shortage_info in sorted_shortage_stores:
            shortage_amount = shortage_info["shortage"]
            
            for excess_store_id, excess_info in sorted_excess_stores:
                if excess_info["excess"] <= 0:
                    continue
                
                # Calculate transfer amount
                transfer_amount = min(shortage_amount, excess_info["excess"])
                
                if transfer_amount > 0:
                    # Add to rebalancing plan
                    rebalancing_plan.append({
                        "product_id": product_id,
                        "from_store_id": excess_store_id,
                        "to_store_id": shortage_store_id,
                        "quantity": transfer_amount
                    })
                    
                    # Update remaining shortage and excess
                    shortage_amount -= transfer_amount
                    excess_info["excess"] -= transfer_amount
                
                if shortage_amount <= 0:
                    break
        
        # Send optimization result to requester
        await self.send_message(
            target_agent_id=requester_id,
            message_type="optimization_result",
            content={
                "optimization_type": "inventory_rebalancing",
                "product_id": product_id,
                "rebalancing_plan": rebalancing_plan
            }
        )
        
        # Store the optimization in memory
        await self.store_memory("decision", {
            "type": "inventory_rebalancing_optimization",
            "product_id": product_id,
            "rebalancing_plan": rebalancing_plan
        })
    
    async def optimize_order_batching(self, parameters: Dict[str, Any], requester_id: str) -> None:
        """
        Optimize order batching for a warehouse.
        
        Args:
            parameters: Parameters for the optimization.
            requester_id: ID of the agent that requested the optimization.
        """
        warehouse_id = parameters.get("warehouse_id")
        pending_orders = parameters.get("pending_orders", [])
        
        if not warehouse_id or not pending_orders:
            return
        
        # Group orders by supplier
        supplier_orders = {}
        
        for order in pending_orders:
            supplier_id = order.get("supplier_id")
            
            if not supplier_id:
                continue
                
            if supplier_id not in supplier_orders:
                supplier_orders[supplier_id] = []
                
            supplier_orders[supplier_id].append(order)
        
        # Create batched orders
        batched_orders = []
        
        for supplier_id, orders in supplier_orders.items():
            # Group by product to consolidate quantities
            product_quantities = {}
            
            for order in orders:
                for product_id, quantity in order.get("products", {}).items():
                    if product_id not in product_quantities:
                        product_quantities[product_id] = 0
                        
                    product_quantities[product_id] += quantity
            
            # Create a batched order
            batched_order = {
                "supplier_id": supplier_id,
                "products": product_quantities,
                "original_orders": [order.get("order_id") for order in orders]
            }
            
            batched_orders.append(batched_order)
        
        # Send optimization result to requester
        await self.send_message(
            target_agent_id=requester_id,
            message_type="optimization_result",
            content={
                "optimization_type": "order_batching",
                "warehouse_id": warehouse_id,
                "batched_orders": batched_orders
            }
        )
        
        # Store the optimization in memory
        await self.store_memory("decision", {
            "type": "order_batching_optimization",
            "warehouse_id": warehouse_id,
            "batched_orders": batched_orders
        })
    
    async def optimize_pricing_strategy(self, parameters: Dict[str, Any], requester_id: str) -> None:
        """
        Optimize pricing strategy for a store.
        
        Args:
            parameters: Parameters for the optimization.
            requester_id: ID of the agent that requested the optimization.
        """
        store_id = parameters.get("store_id")
        products = parameters.get("products", [])
        inventory_levels = parameters.get("inventory_levels", {})
        sales_history = parameters.get("sales_history", [])
        
        if not store_id or not products:
            return
        
        # Calculate price adjustments
        price_adjustments = []
        
        for product in products:
            product_id = product.get("product_id")
            current_price = product.get("price", 0)
            
            if not product_id or current_price <= 0:
                continue
                
            # Get inventory level
            inventory = inventory_levels.get(product_id, 0)
            
            # Get sales history for this product
            product_sales = [
                sale for sale in sales_history
                if sale.get("product_id") == product_id
            ]
            
            # Calculate sales velocity (units sold per day)
            if product_sales:
                total_sold = sum(sale.get("quantity", 0) for sale in product_sales)
                days = max(1, len(set(sale.get("date", "")[:10] for sale in product_sales)))  # Count unique days
                sales_velocity = total_sold / days
            else:
                sales_velocity = 0
            
            # Determine price adjustment
            adjustment_percentage = 0
            reason = ""
            
            if inventory == 0:
                # Stockout - no adjustment needed
                continue
            elif inventory < 10 and sales_velocity > 0:
                # Low inventory and selling well - increase price
                adjustment_percentage = 10
                reason = "Low inventory, high demand"
            elif inventory > 50 and sales_velocity < 1:
                # High inventory and selling slowly - decrease price
                adjustment_percentage = -15
                reason = "High inventory, low demand"
            elif inventory > 30 and sales_velocity < 2:
                # Moderate high inventory and selling moderately slowly - small decrease
                adjustment_percentage = -10
                reason = "Moderate oversupply"
            elif sales_velocity > 5:
                # Very high demand - increase price
                adjustment_percentage = 5
                reason = "High demand"
            
            if adjustment_percentage != 0:
                new_price = current_price * (1 + adjustment_percentage / 100)
                
                price_adjustments.append({
                    "product_id": product_id,
                    "current_price": current_price,
                    "new_price": round(new_price, 2),
                    "adjustment_percentage": adjustment_percentage,
                    "reason": reason
                })
        
        # Send optimization result to requester
        await self.send_message(
            target_agent_id=requester_id,
            message_type="optimization_result",
            content={
                "optimization_type": "pricing_strategy",
                "store_id": store_id,
                "price_adjustments": price_adjustments
            }
        )
        
        # Store the optimization in memory
        await self.store_memory("decision", {
            "type": "pricing_strategy_optimization",
            "store_id": store_id,
            "price_adjustments": price_adjustments
        })
    
    async def check_system_health(self) -> None:
        """Check the health of all registered agents."""
        current_time = datetime.now()
        
        for agent_id, info in self.state["agent_registry"].items():
            # Check if agent has been seen recently
            if "last_seen" in info:
                last_seen = datetime.fromisoformat(info["last_seen"])
                time_since_last_seen = (current_time - last_seen).total_seconds()
                
                # If agent hasn't been seen in 5 minutes, mark as inactive
                if time_since_last_seen > 300:  # 5 minutes
                    self.state["agent_registry"][agent_id]["status"] = "inactive"
                    
                    # Add to system alerts
                    self.state["system_alerts"].append({
                        "alert_id": f"alert_{datetime.now().timestamp()}",
                        "alert_type": "agent_inactive",
                        "source_agent": self.agent_id,
                        "details": {
                            "agent_id": agent_id,
                            "agent_type": info["agent_type"],
                            "time_since_last_seen": time_since_last_seen
                        },
                        "timestamp": current_time.isoformat(),
                        "status": "new"
                    })
                    
                    # Store the alert in memory
                    await self.store_memory("system", {
                        "type": "agent_inactive_alert",
                        "agent_id": agent_id,
                        "agent_type": info["agent_type"],
                        "time_since_last_seen": time_since_last_seen
                    })
        
        self.state["last_system_check"] = current_time.isoformat()
    
    async def clean_up_old_alerts(self) -> None:
        """Clean up old processed alerts."""
        current_time = datetime.now()
        alerts_to_keep = []
        
        for alert in self.state["system_alerts"]:
            if alert["status"] == "new":
                # Keep all new alerts
                alerts_to_keep.append(alert)
            else:
                # Check if the alert is old (more than 24 hours)
                alert_time = datetime.fromisoformat(alert["timestamp"])
                if (current_time - alert_time).total_seconds() <= 86400:  # 24 hours
                    alerts_to_keep.append(alert)
        
        # Update system alerts
        self.state["system_alerts"] = alerts_to_keep
    
    async def take_action(self) -> None:
        """Take action based on the agent's current state."""
        # Check system health periodically
        last_check = self.state.get("last_system_check")
        if last_check is None or (datetime.now() - datetime.fromisoformat(last_check)).total_seconds() > 60:  # Every minute
            await self.check_system_health()
        
        # Process any pending alerts
        new_alerts = [alert for alert in self.state["system_alerts"] if alert["status"] == "new"]
        for alert in new_alerts:
            await self.process_alert(alert)
        
        # Process any pending conflicts
        pending_conflicts = [conflict for conflict in self.state["conflict_resolution_queue"] if conflict["status"] == "pending"]
        for conflict in pending_conflicts:
            await self.resolve_conflict(conflict)
        
        # Clean up old alerts
        await self.clean_up_old_alerts()
        
        # In a real system, we would also:
        # - Analyze system-wide performance metrics
        # - Identify optimization opportunities
        # - Adjust system parameters
        # - etc.
