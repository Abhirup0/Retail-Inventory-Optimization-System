import ollama
import asyncio
from typing import Dict, List, Any, Optional

class OllamaLLMClient:
    """Client for interacting with Ollama LLM."""
    
    def __init__(self, model_name: str = "mistral"):
        """
        Initialize the Ollama LLM client.
        
        Args:
            model_name: Name of the Ollama model to use.
        """
        self.model_name = model_name
    
    async def generate_response(self, prompt: str, context: Optional[str] = None) -> str:
        """
        Generate a response from the LLM.
        
        Args:
            prompt: The prompt to send to the LLM.
            context: Optional system context to provide.
            
        Returns:
            The generated response.
        """
        messages = [{"role": "user", "content": prompt}]
        if context:
            messages.insert(0, {"role": "system", "content": context})
        
        # Run in an executor to avoid blocking the event loop
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None, 
            lambda: ollama.chat(model=self.model_name, messages=messages)
        )
        
        return response["message"]["content"]
    
    async def analyze_inventory(self, inventory_data: Dict[str, Any], question: str) -> str:
        """
        Analyze inventory data using the LLM.
        
        Args:
            inventory_data: Inventory data to analyze.
            question: Question to ask about the inventory data.
            
        Returns:
            The LLM's analysis.
        """
        prompt = f"""
        You are an AI assistant for a retail inventory management system.
        
        Inventory Data:
        {inventory_data}
        
        Question: {question}
        
        Please provide a detailed analysis based on the inventory data.
        """
        
        return await self.generate_response(prompt)
    
    async def generate_restock_recommendations(self, 
                                              inventory_data: Dict[str, Any], 
                                              sales_data: Dict[str, Any],
                                              lead_times: Dict[str, Any]) -> str:
        """
        Generate restock recommendations using the LLM.
        
        Args:
            inventory_data: Current inventory levels.
            sales_data: Recent sales data.
            lead_times: Supplier lead times.
            
        Returns:
            Restock recommendations.
        """
        prompt = f"""
        You are an AI assistant for a retail inventory management system.
        
        Current Inventory Levels:
        {inventory_data}
        
        Recent Sales Data:
        {sales_data}
        
        Supplier Lead Times:
        {lead_times}
        
        Based on the current inventory levels, recent sales data, and supplier lead times, 
        please provide recommendations for which products to restock, how much to order, 
        and when to place the orders. Consider factors such as:
        
        1. Current stock levels
        2. Sales velocity
        3. Lead times
        4. Safety stock requirements
        5. Seasonal trends (if apparent in the data)
        
        Format your response as a structured list of recommendations.
        """
        
        return await self.generate_response(prompt)
    
    async def optimize_pricing(self, 
                              product_data: Dict[str, Any], 
                              inventory_data: Dict[str, Any],
                              sales_data: Dict[str, Any]) -> str:
        """
        Generate pricing optimization recommendations using the LLM.
        
        Args:
            product_data: Product information.
            inventory_data: Current inventory levels.
            sales_data: Recent sales data.
            
        Returns:
            Pricing optimization recommendations.
        """
        prompt = f"""
        You are an AI assistant for a retail inventory management system.
        
        Product Information:
        {product_data}
        
        Current Inventory Levels:
        {inventory_data}
        
        Recent Sales Data:
        {sales_data}
        
        Based on the product information, current inventory levels, and recent sales data, 
        please provide recommendations for pricing adjustments. Consider factors such as:
        
        1. Current inventory levels (suggest discounts for overstocked items)
        2. Sales velocity
        3. Product margins
        4. Competitive pricing
        5. Seasonal trends (if apparent in the data)
        
        Format your response as a structured list of pricing recommendations.
        """
        
        return await self.generate_response(prompt)

async def test_llm_integration():
    """Test the LLM integration."""
    client = OllamaLLMClient()
    
    # Test basic response generation
    response = await client.generate_response(
        "What are the key factors to consider in retail inventory optimization?"
    )
    print("Basic Response:")
    print(response)
    print("\n" + "-"*50 + "\n")
    
    # Test inventory analysis
    inventory_data = {
        "Product A": {"quantity": 5, "min_level": 10, "max_level": 50},
        "Product B": {"quantity": 25, "min_level": 10, "max_level": 50},
        "Product C": {"quantity": 75, "min_level": 10, "max_level": 50}
    }
    
    analysis = await client.analyze_inventory(
        inventory_data,
        "Which products need restocking and which are overstocked?"
    )
    print("Inventory Analysis:")
    print(analysis)
    print("\n" + "-"*50 + "\n")
    
    # Test restock recommendations
    sales_data = {
        "Product A": {"last_7_days": 15, "last_30_days": 60},
        "Product B": {"last_7_days": 5, "last_30_days": 20},
        "Product C": {"last_7_days": 2, "last_30_days": 10}
    }
    
    lead_times = {
        "Supplier X": {"avg_lead_time": 3, "products": ["Product A", "Product B"]},
        "Supplier Y": {"avg_lead_time": 7, "products": ["Product C"]}
    }
    
    restock_recommendations = await client.generate_restock_recommendations(
        inventory_data,
        sales_data,
        lead_times
    )
    print("Restock Recommendations:")
    print(restock_recommendations)

if __name__ == "__main__":
    asyncio.run(test_llm_integration())
