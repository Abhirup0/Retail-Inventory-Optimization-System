import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import logging
import os

logger = logging.getLogger(__name__)

class DataLoader:
    """
    Class for loading and preprocessing the retail datasets.
    """
    
    def __init__(self, data_path: str = None):
        """
        Initialize the data loader.
        
        Args:
            data_path: Path to the directory containing the datasets.
        """
        self.data_path = data_path or r"C:\Users\abhir\Downloads\Dataset\[use case 1] Inventory Optimization for Retail"
        self.demand_data = None
        self.inventory_data = None
        self.pricing_data = None
        self.combined_data = None
        
        # Create data directory if it doesn't exist
        os.makedirs("data/datasets", exist_ok=True)
    
    def load_datasets(self) -> None:
        """Load all datasets."""
        self.load_demand_data()
        self.load_inventory_data()
        self.load_pricing_data()
        self.combine_datasets()
    
    def load_demand_data(self) -> pd.DataFrame:
        """
        Load and preprocess the demand forecasting dataset.
        
        Returns:
            Preprocessed demand data.
        """
        file_path = os.path.join(self.data_path, "demand_forecasting.csv")
        
        try:
            df = pd.read_csv(file_path)
            
            # Preprocess data
            df['Date'] = pd.to_datetime(df['Date'])
            
            # Convert categorical columns to appropriate types
            if 'Promotions' in df.columns:
                df['Promotions'] = df['Promotions'].map({'Yes': 1, 'No': 0})
            
            # Store the data
            self.demand_data = df
            
            logger.info(f"Loaded demand data: {len(df)} rows, {df.columns.tolist()}")
            
            return df
        
        except Exception as e:
            logger.error(f"Error loading demand data: {e}")
            return pd.DataFrame()
    
    def load_inventory_data(self) -> pd.DataFrame:
        """
        Load and preprocess the inventory monitoring dataset.
        
        Returns:
            Preprocessed inventory data.
        """
        file_path = os.path.join(self.data_path, "inventory_monitoring.csv")
        
        try:
            df = pd.read_csv(file_path)
            
            # Preprocess data
            if 'Expiry Date' in df.columns:
                df['Expiry Date'] = pd.to_datetime(df['Expiry Date'])
            
            # Store the data
            self.inventory_data = df
            
            logger.info(f"Loaded inventory data: {len(df)} rows, {df.columns.tolist()}")
            
            return df
        
        except Exception as e:
            logger.error(f"Error loading inventory data: {e}")
            return pd.DataFrame()
    
    def load_pricing_data(self) -> pd.DataFrame:
        """
        Load and preprocess the pricing optimization dataset.
        
        Returns:
            Preprocessed pricing data.
        """
        file_path = os.path.join(self.data_path, "pricing_optimization.csv")
        
        try:
            df = pd.read_csv(file_path)
            
            # Store the data
            self.pricing_data = df
            
            logger.info(f"Loaded pricing data: {len(df)} rows, {df.columns.tolist()}")
            
            return df
        
        except Exception as e:
            logger.error(f"Error loading pricing data: {e}")
            return pd.DataFrame()
    
    def combine_datasets(self) -> pd.DataFrame:
        """
        Combine all datasets into a single comprehensive dataset.
        
        Returns:
            Combined dataset.
        """
        if self.demand_data is None or self.inventory_data is None or self.pricing_data is None:
            logger.warning("Cannot combine datasets: one or more datasets not loaded")
            return pd.DataFrame()
        
        try:
            # Merge demand and inventory data on Product ID and Store ID
            combined = pd.merge(
                self.demand_data,
                self.inventory_data,
                on=['Product ID', 'Store ID'],
                how='outer',
                suffixes=('_demand', '_inventory')
            )
            
            # Merge with pricing data
            combined = pd.merge(
                combined,
                self.pricing_data,
                on=['Product ID', 'Store ID'],
                how='outer',
                suffixes=('', '_pricing')
            )
            
            # Handle duplicate columns
            # If there are duplicate columns like 'Price', rename them
            duplicate_cols = [col for col in combined.columns if col.endswith('_pricing') and col.replace('_pricing', '') in combined.columns]
            for col in duplicate_cols:
                original_col = col.replace('_pricing', '')
                # If both columns exist, keep both but with clear names
                if original_col in combined.columns:
                    combined.rename(columns={original_col: f"{original_col}_demand", col: f"{original_col}_pricing"}, inplace=True)
            
            # Store the combined data
            self.combined_data = combined
            
            logger.info(f"Combined data: {len(combined)} rows, {combined.columns.tolist()}")
            
            return combined
        
        except Exception as e:
            logger.error(f"Error combining datasets: {e}")
            return pd.DataFrame()
    
    def get_product_data(self) -> Dict[int, Dict[str, Any]]:
        """
        Extract product data from the datasets.
        
        Returns:
            Dictionary mapping product IDs to product data.
        """
        if self.combined_data is None:
            logger.warning("Cannot extract product data: combined dataset not available")
            return {}
        
        product_data = {}
        
        try:
            # Get unique products
            unique_products = self.combined_data['Product ID'].unique()
            
            for product_id in unique_products:
                # Filter data for this product
                product_rows = self.combined_data[self.combined_data['Product ID'] == product_id]
                
                # Get pricing data
                if 'Price_pricing' in product_rows.columns:
                    avg_price = product_rows['Price_pricing'].mean()
                elif 'Price' in product_rows.columns:
                    avg_price = product_rows['Price'].mean()
                else:
                    avg_price = 0.0
                
                # Get inventory data
                if 'Stock Levels' in product_rows.columns:
                    avg_stock = product_rows['Stock Levels'].mean()
                else:
                    avg_stock = 0.0
                
                if 'Reorder Point' in product_rows.columns:
                    avg_reorder_point = product_rows['Reorder Point'].mean()
                else:
                    avg_reorder_point = 0.0
                
                # Get demand data
                if 'Sales Quantity' in product_rows.columns:
                    avg_sales = product_rows['Sales Quantity'].mean()
                else:
                    avg_sales = 0.0
                
                # Calculate cost (assuming 60% of price)
                avg_cost = avg_price * 0.6
                
                # Create product data
                product_data[product_id] = {
                    'product_id': product_id,
                    'name': f'Product {product_id}',
                    'category': self._assign_category(product_id),
                    'base_price': avg_price,
                    'cost': avg_cost,
                    'min_level': int(avg_reorder_point),
                    'max_level': int(avg_stock * 1.5),
                    'avg_sales': avg_sales,
                    'avg_stock': avg_stock
                }
            
            logger.info(f"Extracted data for {len(product_data)} products")
            
            return product_data
        
        except Exception as e:
            logger.error(f"Error extracting product data: {e}")
            return {}
    
    def get_store_inventory(self) -> Dict[int, Dict[int, int]]:
        """
        Extract store inventory data from the datasets.
        
        Returns:
            Dictionary mapping store IDs to inventory data (product_id -> quantity).
        """
        if self.inventory_data is None:
            logger.warning("Cannot extract store inventory: inventory dataset not available")
            return {}
        
        store_inventory = {}
        
        try:
            # Get unique stores
            unique_stores = self.inventory_data['Store ID'].unique()
            
            for store_id in unique_stores:
                # Filter data for this store
                store_rows = self.inventory_data[self.inventory_data['Store ID'] == store_id]
                
                # Create inventory data for this store
                inventory = {}
                for _, row in store_rows.iterrows():
                    product_id = row['Product ID']
                    stock_level = row['Stock Levels']
                    inventory[product_id] = int(stock_level)
                
                store_inventory[store_id] = inventory
            
            logger.info(f"Extracted inventory data for {len(store_inventory)} stores")
            
            return store_inventory
        
        except Exception as e:
            logger.error(f"Error extracting store inventory: {e}")
            return {}
    
    def get_sales_history(self) -> List[Dict[str, Any]]:
        """
        Extract sales history from the datasets.
        
        Returns:
            List of sales records.
        """
        if self.demand_data is None:
            logger.warning("Cannot extract sales history: demand dataset not available")
            return []
        
        sales_history = []
        
        try:
            # Process each row in demand data
            for _, row in self.demand_data.iterrows():
                sale = {
                    'product_id': row['Product ID'],
                    'store_id': row['Store ID'],
                    'date': row['Date'].isoformat(),
                    'quantity': row['Sales Quantity'],
                    'price': row['Price'],
                    'promotion': row['Promotions'] == 1 if isinstance(row['Promotions'], (int, float)) else row['Promotions'] == 'Yes'
                }
                sales_history.append(sale)
            
            logger.info(f"Extracted {len(sales_history)} sales records")
            
            return sales_history
        
        except Exception as e:
            logger.error(f"Error extracting sales history: {e}")
            return []
    
    def get_supplier_data(self) -> Dict[int, Dict[str, Any]]:
        """
        Generate supplier data based on the datasets.
        
        Returns:
            Dictionary mapping supplier IDs to supplier data.
        """
        if self.inventory_data is None:
            logger.warning("Cannot generate supplier data: inventory dataset not available")
            return {}
        
        supplier_data = {}
        
        try:
            # Create synthetic suppliers
            num_suppliers = 5  # We'll create 5 suppliers
            
            # Get unique products
            unique_products = self.inventory_data['Product ID'].unique()
            
            # Distribute products among suppliers
            products_per_supplier = len(unique_products) // num_suppliers
            extra_products = len(unique_products) % num_suppliers
            
            product_index = 0
            for supplier_id in range(1, num_suppliers + 1):
                # Determine how many products this supplier has
                if supplier_id <= extra_products:
                    num_products = products_per_supplier + 1
                else:
                    num_products = products_per_supplier
                
                # Get products for this supplier
                supplier_products = unique_products[product_index:product_index + num_products]
                product_index += num_products
                
                # Get average lead time
                avg_lead_time = self.inventory_data['Supplier Lead Time (days)'].mean()
                
                # Create supplier data
                supplier_data[supplier_id] = {
                    'supplier_id': supplier_id,
                    'name': f'Supplier {supplier_id}',
                    'lead_time': int(avg_lead_time),
                    'products': list(supplier_products)
                }
            
            logger.info(f"Generated data for {len(supplier_data)} suppliers")
            
            return supplier_data
        
        except Exception as e:
            logger.error(f"Error generating supplier data: {e}")
            return {}
    
    def prepare_simulation_data(self) -> Dict[str, Any]:
        """
        Prepare data for simulation.
        
        Returns:
            Dictionary with all data needed for simulation.
        """
        if not all([self.demand_data is not None, self.inventory_data is not None, self.pricing_data is not None]):
            self.load_datasets()
        
        simulation_data = {
            'products': self.get_product_data(),
            'store_inventory': self.get_store_inventory(),
            'sales_history': self.get_sales_history(),
            'suppliers': self.get_supplier_data()
        }
        
        # Add metadata
        simulation_data['metadata'] = {
            'num_products': len(simulation_data['products']),
            'num_stores': len(simulation_data['store_inventory']),
            'num_suppliers': len(simulation_data['suppliers']),
            'date_range': {
                'start': self.demand_data['Date'].min().isoformat() if self.demand_data is not None else None,
                'end': self.demand_data['Date'].max().isoformat() if self.demand_data is not None else None
            }
        }
        
        logger.info(f"Prepared simulation data with {simulation_data['metadata']['num_products']} products, "
                   f"{simulation_data['metadata']['num_stores']} stores, and {len(simulation_data['sales_history'])} sales records")
        
        return simulation_data
    
    def save_processed_data(self, output_path: str = "data/datasets/processed_data.json") -> None:
        """
        Save processed data to a JSON file.
        
        Args:
            output_path: Path to save the processed data.
        """
        import json
        
        simulation_data = self.prepare_simulation_data()
        
        try:
            # Convert sales history dates to strings if they aren't already
            for sale in simulation_data['sales_history']:
                if isinstance(sale['date'], datetime):
                    sale['date'] = sale['date'].isoformat()
            
            # Save to file
            with open(output_path, 'w') as f:
                json.dump(simulation_data, f, indent=2)
            
            logger.info(f"Saved processed data to {output_path}")
        
        except Exception as e:
            logger.error(f"Error saving processed data: {e}")
    
    def _assign_category(self, product_id: int) -> str:
        """
        Assign a category to a product based on its ID.
        
        Args:
            product_id: Product ID.
            
        Returns:
            Category name.
        """
        # Use product ID to deterministically assign a category
        categories = ["Electronics", "Clothing", "Groceries", "Home Goods", "Toys", "Sports", "Beauty", "Books"]
        return categories[product_id % len(categories)]


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Test the data loader
    data_loader = DataLoader()
    data_loader.load_datasets()
    data_loader.save_processed_data()
