import asyncio
from typing import Dict, List, Any, Callable, Awaitable, Optional
import logging
import uuid
from datetime import datetime

logger = logging.getLogger(__name__)

class MessageBus:
    """
    Message bus for agent communication.
    
    Implements a publish-subscribe pattern for asynchronous communication between agents.
    """
    
    def __init__(self):
        """Initialize the message bus."""
        self.subscribers = {}  # topic -> list of callbacks
        self.direct_routes = {}  # agent_id -> callback
        self.message_history = []  # list of messages for debugging
        self.max_history = 1000  # maximum number of messages to keep in history
    
    async def publish(self, topic: str, message: Dict[str, Any]) -> None:
        """
        Publish a message to a topic.
        
        Args:
            topic: The topic to publish to.
            message: The message to publish.
        """
        if not isinstance(message, dict):
            logger.warning(f"Invalid message format: {message}. Messages must be dictionaries.")
            return
        
        # Add message ID and timestamp if not present
        if "message_id" not in message:
            message["message_id"] = str(uuid.uuid4())
        
        if "timestamp" not in message:
            message["timestamp"] = datetime.now().isoformat()
        
        # Add to history
        self.message_history.append({
            "type": "topic",
            "topic": topic,
            "message": message,
            "timestamp": datetime.now().isoformat()
        })
        
        # Trim history if needed
        if len(self.message_history) > self.max_history:
            self.message_history = self.message_history[-self.max_history:]
        
        # Log the message
        logger.debug(f"Publishing message to topic '{topic}': {message}")
        
        # Deliver to subscribers
        if topic in self.subscribers:
            for callback in self.subscribers[topic]:
                try:
                    await callback(message)
                except Exception as e:
                    logger.error(f"Error delivering message to subscriber: {e}")
    
    async def send_direct(self, target_agent_id: str, message: Dict[str, Any]) -> bool:
        """
        Send a message directly to a specific agent.
        
        Args:
            target_agent_id: ID of the target agent.
            message: The message to send.
            
        Returns:
            True if the message was delivered, False otherwise.
        """
        if not isinstance(message, dict):
            logger.warning(f"Invalid message format: {message}. Messages must be dictionaries.")
            return False
        
        # Add message ID and timestamp if not present
        if "message_id" not in message:
            message["message_id"] = str(uuid.uuid4())
        
        if "timestamp" not in message:
            message["timestamp"] = datetime.now().isoformat()
        
        # Add to history
        self.message_history.append({
            "type": "direct",
            "target_agent_id": target_agent_id,
            "message": message,
            "timestamp": datetime.now().isoformat()
        })
        
        # Trim history if needed
        if len(self.message_history) > self.max_history:
            self.message_history = self.message_history[-self.max_history:]
        
        # Log the message
        logger.debug(f"Sending direct message to agent '{target_agent_id}': {message}")
        
        # Deliver to target agent
        if target_agent_id in self.direct_routes:
            try:
                await self.direct_routes[target_agent_id](message)
                return True
            except Exception as e:
                logger.error(f"Error delivering direct message to agent '{target_agent_id}': {e}")
                return False
        else:
            logger.warning(f"No route found for agent '{target_agent_id}'")
            return False
    
    def subscribe(self, topic: str, callback: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
        """
        Subscribe to a topic.
        
        Args:
            topic: The topic to subscribe to.
            callback: The callback function to call when a message is published to the topic.
        """
        if topic not in self.subscribers:
            self.subscribers[topic] = []
        
        self.subscribers[topic].append(callback)
        logger.debug(f"Subscribed to topic '{topic}'")
    
    def unsubscribe(self, topic: str, callback: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
        """
        Unsubscribe from a topic.
        
        Args:
            topic: The topic to unsubscribe from.
            callback: The callback function to remove.
        """
        if topic in self.subscribers and callback in self.subscribers[topic]:
            self.subscribers[topic].remove(callback)
            logger.debug(f"Unsubscribed from topic '{topic}'")
            
            # Clean up empty topic
            if not self.subscribers[topic]:
                del self.subscribers[topic]
    
    def register_agent(self, agent_id: str, callback: Callable[[Dict[str, Any]], Awaitable[None]]) -> None:
        """
        Register an agent to receive direct messages.
        
        Args:
            agent_id: ID of the agent.
            callback: The callback function to call when a message is sent to the agent.
        """
        self.direct_routes[agent_id] = callback
        logger.debug(f"Registered agent '{agent_id}'")
    
    def unregister_agent(self, agent_id: str) -> None:
        """
        Unregister an agent.
        
        Args:
            agent_id: ID of the agent to unregister.
        """
        if agent_id in self.direct_routes:
            del self.direct_routes[agent_id]
            logger.debug(f"Unregistered agent '{agent_id}'")
    
    def get_message_history(self, limit: int = 100, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get message history for debugging.
        
        Args:
            limit: Maximum number of messages to return.
            agent_id: Optional agent ID to filter messages by.
            
        Returns:
            List of messages.
        """
        if agent_id:
            # Filter messages by agent ID
            filtered_history = [
                msg for msg in self.message_history
                if (msg["type"] == "direct" and msg["target_agent_id"] == agent_id) or
                   (msg["type"] == "topic" and "target_agent_id" in msg["message"] and msg["message"]["target_agent_id"] == agent_id) or
                   (msg["type"] == "topic" and "sender_id" in msg["message"] and msg["message"]["sender_id"] == agent_id)
            ]
            return filtered_history[-limit:]
        else:
            # Return all messages
            return self.message_history[-limit:]
