import ollama
import sys
import os
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

def test_ollama_connection():
    """Test the connection to Ollama and run a simple prompt."""
    try:
        # Define the model name (use a lightweight model like "mistral")
        model_name = "mistral"
        
        # Define the user input prompt
        prompt = "You are an AI assistant for a retail inventory management system. What are some key factors to consider when optimizing inventory levels?"
        
        # Run the model and get a response
        print(f"Sending prompt to Ollama ({model_name} model)...")
        response = ollama.chat(model=model_name, messages=[{"role": "user", "content": prompt}])
        
        # Print the response
        print("\nAI Response:")
        print(response["message"]["content"])
        
        print("\nOllama connection test successful!")
        return True
    
    except Exception as e:
        print(f"Error connecting to Ollama: {e}")
        print("\nPlease make sure Ollama is installed and running, and that you have pulled the 'mistral' model.")
        print("Installation instructions: https://ollama.com")
        print("Pull the model with: ollama pull mistral")
        return False

if __name__ == "__main__":
    test_ollama_connection()
