import asyncio
import logging
import random
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import os
import json
from pathlib import Path

from src.agents.store_agent import StoreAgent
from src.agents.warehouse_agent import WarehouseAgent
from src.agents.supplier_agent import SupplierAgent
from src.agents.customer_agent import CustomerAgent
from src.agents.coordinator_agent import CoordinatorAgent
from src.utils.message_bus import MessageBus
from src.models.intelligence_module import IntelligenceModule

logger = logging.getLogger(__name__)

class SimulationEnvironment:
    """
    Environment for simulating a retail inventory system with multiple agents.
    """

    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the simulation environment.

        Args:
            config: Configuration dictionary for the simulation.
        """
        self.config = config or {}
        self.message_bus = MessageBus()
        self.intelligence_module = None
        self.agents = {
            "coordinator": None,
            "stores": [],
            "warehouse": None,
            "suppliers": [],
            "customers": []
        }
        self.tasks = []
        self.simulation_data = {
            "metrics": [],
            "events": [],
            "inventory_levels": [],
            "sales": [],
            "orders": []
        }
        self.simulation_time = datetime.now()
        self.time_acceleration = self.config.get("time_acceleration", 1)  # 1 = real-time, >1 = faster
        self.running = False
        self.real_data = None  # For storing real data from datasets

        # Create data directory if it doesn't exist
        os.makedirs("data/simulation", exist_ok=True)

    async def initialize(self) -> None:
        """Initialize the simulation environment."""
        logger.info("Initializing simulation environment...")

        # Set random seed if provided
        if "random_seed" in self.config:
            random.seed(self.config["random_seed"])
            np.random.seed(self.config["random_seed"])
            logger.info(f"Random seed set to {self.config['random_seed']}")

        # Initialize intelligence module
        if self.config.get("use_intelligence_module", True):
            self.intelligence_module = IntelligenceModule(ollama_model=self.config.get("ollama_model", "mistral"))
            logger.info("Intelligence module initialized")

        # Initialize coordinator agent
        coordinator = CoordinatorAgent(coordinator_id="main_coordinator")
        coordinator.message_bus = self.message_bus
        self.message_bus.register_agent(coordinator.agent_id, coordinator._handle_direct_message)
        self.agents["coordinator"] = coordinator

        # Initialize store agents
        num_stores = self.config.get("num_stores", 3)
        for i in range(1, num_stores + 1):
            store = StoreAgent(
                store_id=i,
                name=f"Store {i}",
                location=f"Location {i}",
                intelligence_module=self.intelligence_module,
                message_bus=self.message_bus
            )
            self.agents["stores"].append(store)

        # Initialize warehouse agent
        warehouse_capacity_multiplier = self.config.get("warehouse_capacity_multiplier", 1.0)
        warehouse = WarehouseAgent(
            warehouse_id=1,
            name="Central Warehouse",
            location="Warehouse Location",
            intelligence_module=self.intelligence_module,
            message_bus=self.message_bus
        )
        # Apply warehouse capacity multiplier to state
        warehouse.state["capacity_multiplier"] = warehouse_capacity_multiplier
        self.agents["warehouse"] = warehouse

        # Initialize supplier agents
        num_suppliers = self.config.get("num_suppliers", 3)
        supplier_lead_time_multiplier = self.config.get("supplier_lead_time_multiplier", 1.0)

        for i in range(1, num_suppliers + 1):
            base_lead_time = random.randint(3, 7)
            adjusted_lead_time = int(base_lead_time * supplier_lead_time_multiplier)

            supplier = SupplierAgent(
                supplier_id=i,
                name=f"Supplier {i}",
                lead_time=adjusted_lead_time,
                message_bus=self.message_bus
            )
            self.agents["suppliers"].append(supplier)

        # Initialize customer agents
        num_customers = self.config.get("num_customers", 10)
        customer_segments = ["Regular", "Premium", "VIP", "New", "Occasional"]
        preferences = ["Electronics", "Clothing", "Groceries", "Home Goods", "Toys", "Sports", "Beauty", "Books"]
        customer_activity_multiplier = self.config.get("customer_activity_multiplier", 1.0)
        price_elasticity_multiplier = self.config.get("price_elasticity_multiplier", 1.0)

        for i in range(1, num_customers + 1):
            segment = random.choice(customer_segments)
            customer_prefs = random.sample(preferences, random.randint(1, 3))  # 1-3 preferences
            customer = CustomerAgent(
                customer_id=i,
                segment=segment,
                preferences=customer_prefs,
                message_bus=self.message_bus
            )
            # Apply customer activity and price elasticity multipliers to state
            customer.state["activity_multiplier"] = customer_activity_multiplier
            customer.state["price_elasticity_multiplier"] = price_elasticity_multiplier
            self.agents["customers"].append(customer)

        # Connect agents
        await self.connect_agents()

        # Initialize inventory
        await self.initialize_inventory()

        # Apply seasonal demand if enabled
        if self.config.get("seasonal_demand_enabled", False):
            await self.initialize_seasonal_demand()

        logger.info(f"Simulation environment initialized with {num_stores} stores, {num_suppliers} suppliers, and {num_customers} customers")

    async def connect_agents(self) -> None:
        """Connect agents to each other."""
        # Register all agents with the coordinator
        for agent_type, agents in self.agents.items():
            if agent_type == "coordinator":
                continue

            if isinstance(agents, list):
                for agent in agents:
                    await self.agents["coordinator"].register_agent(agent)
            elif agents is not None:
                await self.agents["coordinator"].register_agent(agents)

        # Connect stores with warehouse
        for store in self.agents["stores"]:
            await store.connect(self.agents["warehouse"])
            await self.agents["warehouse"].connect(store)

        # Connect warehouse with suppliers
        for supplier in self.agents["suppliers"]:
            await self.agents["warehouse"].connect(supplier)
            await supplier.connect(self.agents["warehouse"])

        # Connect stores with customers
        for store in self.agents["stores"]:
            for customer in self.agents["customers"]:
                await store.connect(customer)
                await customer.connect(store)

    async def initialize_inventory(self) -> None:
        """Initialize inventory for stores and warehouse."""
        # Check if we should use real data
        if self.config.get("use_real_data", False) and self.real_data is not None:
            await self._initialize_from_real_data()
        else:
            await self._initialize_synthetic_inventory()

    async def _initialize_from_real_data(self) -> None:
        """Initialize inventory using real data from datasets."""
        logger.info("Initializing inventory from real data...")

        if not self.real_data:
            logger.warning("No real data available. Using synthetic data instead.")
            await self._initialize_synthetic_inventory()
            return

        # Get product data
        products = []
        for product_id, product_data in self.real_data.get("products", {}).items():
            # Convert product_id to int if it's a string
            if isinstance(product_id, str):
                product_id = int(product_id)

            # Create product object
            product = {
                "product_id": product_id,
                "name": product_data.get("name", f"Product {product_id}"),
                "category": product_data.get("category", "Unknown"),
                "base_price": product_data.get("base_price", 100.0),
                "cost": product_data.get("cost", 60.0),
                "min_level": product_data.get("min_level", 10),
                "max_level": product_data.get("max_level", 100),
                "seasonal_factor": product_data.get("seasonal_factor", False),
                "seasonal_peak_month": product_data.get("seasonal_peak_month", 1)
            }
            products.append(product)

        # Apply warehouse capacity multiplier if set
        warehouse_capacity_multiplier = self.agents["warehouse"].state.get("capacity_multiplier", 1.0)

        # Initialize warehouse inventory
        # Use average stock levels from the data
        for product in products:
            product_id = product["product_id"]
            base_quantity = self.real_data.get("products", {}).get(product_id, {}).get("avg_stock", 100)
            adjusted_quantity = int(base_quantity * warehouse_capacity_multiplier)
            self.agents["warehouse"].state["inventory"][product_id] = adjusted_quantity

        # Initialize store inventory
        store_inventory = self.real_data.get("store_inventory", {})
        for store in self.agents["stores"]:
            store_id = store.store_id

            # Get inventory for this store
            if str(store_id) in store_inventory:
                store_data = store_inventory[str(store_id)]
            elif store_id in store_inventory:
                store_data = store_inventory[store_id]
            else:
                # No data for this store, use default values
                for product in products:
                    store.state["inventory"][product["product_id"]] = random.randint(10, 50)
                continue

            # Set inventory for each product
            for product_id, quantity in store_data.items():
                # Convert product_id to int if it's a string
                if isinstance(product_id, str):
                    product_id = int(product_id)

                store.state["inventory"][product_id] = quantity

        # Initialize supplier products
        supplier_data = self.real_data.get("suppliers", {})
        for supplier in self.agents["suppliers"]:
            supplier_id = supplier.supplier_id

            # Get data for this supplier
            if str(supplier_id) in supplier_data:
                supplier_info = supplier_data[str(supplier_id)]
            elif supplier_id in supplier_data:
                supplier_info = supplier_data[supplier_id]
            else:
                # No data for this supplier, assign random products
                supplier_products = random.sample(products, random.randint(5, 10))

                for product in supplier_products:
                    supplier.state["products"][product["product_id"]] = {
                        "name": product["name"],
                        "price": product["cost"] * 0.9,
                        "stock": random.randint(100, 500),
                        "production_capacity": random.randint(20, 50),
                        "lead_time": supplier.lead_time
                    }
                continue

            # Get products for this supplier
            supplier_product_ids = supplier_info.get("products", [])
            supplier_products = [p for p in products if p["product_id"] in supplier_product_ids]

            # Set supplier products
            for product in supplier_products:
                supplier.state["products"][product["product_id"]] = {
                    "name": product["name"],
                    "price": product["cost"] * 0.9,  # Supplier price is 90% of store cost
                    "stock": random.randint(100, 500),
                    "production_capacity": random.randint(20, 50),
                    "lead_time": supplier.lead_time
                }

        # Initialize sales history
        sales_history = self.real_data.get("sales_history", [])
        for store in self.agents["stores"]:
            # Filter sales for this store
            store_sales = [sale for sale in sales_history if sale.get("store_id") == store.store_id]

            # Add sales to store state
            store.state["sales"] = store_sales

        # Store product data
        self.simulation_data["products"] = products

        logger.info(f"Initialized inventory from real data with {len(products)} products")

    async def _initialize_synthetic_inventory(self) -> None:
        """Initialize inventory with synthetic data."""
        logger.info("Initializing inventory with synthetic data...")

        # Define product categories
        categories = ["Electronics", "Clothing", "Groceries", "Home Goods", "Toys", "Sports", "Beauty", "Books"]

        # Create products
        num_products = self.config.get("num_products", 20)
        products = []

        for i in range(1, num_products + 1):
            category = categories[i % len(categories)]
            base_price = random.uniform(10, 200)

            product = {
                "product_id": i,
                "name": f"Product {i}",
                "category": category,
                "base_price": base_price,
                "cost": base_price * 0.6,  # 60% of base price
                "min_level": random.randint(5, 20),
                "max_level": random.randint(50, 100),
                "seasonal_factor": random.choice([True, False]),  # Whether product has seasonal demand
                "seasonal_peak_month": random.randint(1, 12)  # Peak month for seasonal products
            }
            products.append(product)

        # Apply warehouse capacity multiplier if set
        warehouse_capacity_multiplier = self.agents["warehouse"].state.get("capacity_multiplier", 1.0)

        # Initialize warehouse inventory
        for product in products:
            base_quantity = random.randint(50, 200)
            adjusted_quantity = int(base_quantity * warehouse_capacity_multiplier)
            self.agents["warehouse"].state["inventory"][product["product_id"]] = adjusted_quantity

        # Check if we should optimize initial inventory
        optimize_initial_inventory = self.config.get("optimize_initial_inventory", False)

        # Initialize store inventory
        for store in self.agents["stores"]:
            for product in products:
                if optimize_initial_inventory:
                    # Use product min/max levels for more optimal initial inventory
                    min_level = product["min_level"]
                    max_level = product["max_level"]
                    optimal_level = (min_level + max_level) // 2
                    store.state["inventory"][product["product_id"]] = optimal_level
                else:
                    # Use random initial inventory
                    store.state["inventory"][product["product_id"]] = random.randint(10, 50)

        # Initialize supplier products
        for supplier in self.agents["suppliers"]:
            # Assign a subset of products to each supplier
            supplier_products = random.sample(products, random.randint(5, 10))

            for product in supplier_products:
                supplier.state["products"][product["product_id"]] = {
                    "name": product["name"],
                    "price": product["cost"] * 0.9,  # Supplier price is 90% of store cost
                    "stock": random.randint(100, 500),
                    "production_capacity": random.randint(20, 50),
                    "lead_time": supplier.lead_time
                }

        # Store product data
        self.simulation_data["products"] = products

        logger.info(f"Initialized inventory with synthetic data: {len(products)} products")

    async def initialize_seasonal_demand(self) -> None:
        """Initialize seasonal demand patterns."""
        logger.info("Initializing seasonal demand patterns...")

        # Get seasonal amplitude from config
        seasonal_amplitude = self.config.get("seasonal_amplitude", 0.3)

        # Get current month (1-12)
        current_month = datetime.now().month

        # Initialize seasonal factors for each product
        seasonal_factors = {}

        for product in self.simulation_data["products"]:
            product_id = product["product_id"]

            if product["seasonal_factor"]:
                # Calculate seasonal factor based on distance from peak month
                peak_month = product["seasonal_peak_month"]
                month_distance = min(abs(current_month - peak_month), 12 - abs(current_month - peak_month))
                normalized_distance = month_distance / 6.0  # 6 months is maximum distance

                # Calculate seasonal factor (1.0 + amplitude at peak, 1.0 - amplitude at trough)
                factor = 1.0 + seasonal_amplitude * (1.0 - 2.0 * normalized_distance)
            else:
                # Non-seasonal product has constant factor
                factor = 1.0

            seasonal_factors[product_id] = factor

        # Store seasonal factors in simulation data
        self.simulation_data["seasonal_factors"] = seasonal_factors

        # Apply seasonal factors to customer preferences
        for customer in self.agents["customers"]:
            customer.state["seasonal_factors"] = seasonal_factors

        logger.info(f"Seasonal demand initialized with amplitude {seasonal_amplitude}")

    async def run(self, duration: int = 60) -> None:
        """
        Run the simulation for a specified duration.

        Args:
            duration: Duration in seconds.
        """
        self.running = True
        logger.info(f"Starting simulation for {duration} seconds...")

        # Start agent tasks
        self.tasks = []

        # Start coordinator first
        coordinator_task = asyncio.create_task(self.agents["coordinator"].run())
        self.tasks.append(coordinator_task)

        # Start store agents
        for store in self.agents["stores"]:
            self.tasks.append(asyncio.create_task(store.run()))

        # Start warehouse agent
        self.tasks.append(asyncio.create_task(self.agents["warehouse"].run()))

        # Start supplier agents
        for supplier in self.agents["suppliers"]:
            self.tasks.append(asyncio.create_task(supplier.run()))

        # Start customer agents
        for customer in self.agents["customers"]:
            self.tasks.append(asyncio.create_task(customer.run()))

        # Start metrics collection
        metrics_task = asyncio.create_task(self.collect_metrics())
        self.tasks.append(metrics_task)

        logger.info(f"Started {len(self.tasks)} tasks")

        # Run for specified duration
        try:
            await asyncio.sleep(duration)
        except asyncio.CancelledError:
            logger.info("Simulation cancelled")
        finally:
            self.running = False

            # Cancel all tasks
            for task in self.tasks:
                if not task.done():
                    task.cancel()

            # Wait for tasks to be cancelled
            await asyncio.gather(*self.tasks, return_exceptions=True)

            # Save simulation data
            self.save_simulation_data()

            logger.info("Simulation completed")

    async def collect_metrics(self) -> None:
        """Collect metrics from agents periodically."""
        try:
            while self.running:
                # Collect inventory levels
                inventory_data = {
                    "timestamp": datetime.now().isoformat(),
                    "warehouse": self.agents["warehouse"].state["inventory"].copy(),
                    "stores": {store.store_id: store.state["inventory"].copy() for store in self.agents["stores"]}
                }
                self.simulation_data["inventory_levels"].append(inventory_data)

                # Collect sales data
                sales_data = []
                for store in self.agents["stores"]:
                    for sale in store.state["sales"]:
                        sales_data.append({
                            "store_id": store.store_id,
                            "product_id": sale["product_id"],
                            "quantity": sale["quantity"],
                            "price": sale["price"],
                            "date": sale["date"]
                        })
                self.simulation_data["sales"] = sales_data

                # Collect order data
                order_data = []
                for supplier in self.agents["suppliers"]:
                    for order in supplier.state["pending_orders"]:
                        order_data.append({
                            "order_id": order.get("order_id"),
                            "supplier_id": supplier.supplier_id,
                            "warehouse_id": order.get("warehouse_id"),
                            "products": order.get("products"),
                            "status": order.get("status"),
                            "order_date": order.get("order_date"),
                            "estimated_delivery_date": order.get("estimated_delivery_date")
                        })
                self.simulation_data["orders"] = order_data

                # Collect performance metrics
                metrics = {
                    "timestamp": datetime.now().isoformat(),
                    "warehouse": self.agents["warehouse"].state["performance_metrics"].copy(),
                    "stores": {store.store_id: store.state["performance_metrics"].copy() for store in self.agents["stores"]}
                }
                self.simulation_data["metrics"].append(metrics)

                # Wait before next collection
                await asyncio.sleep(5)
        except asyncio.CancelledError:
            logger.info("Metrics collection cancelled")
        except Exception as e:
            logger.error(f"Error in metrics collection: {e}")

    def save_simulation_data(self) -> None:
        """Save simulation data to files."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Save inventory levels
        inventory_df = pd.DataFrame([
            {
                "timestamp": data["timestamp"],
                "agent_type": "warehouse",
                "agent_id": "warehouse_1",
                "product_id": product_id,
                "quantity": quantity
            }
            for data in self.simulation_data["inventory_levels"]
            for product_id, quantity in data["warehouse"].items()
        ] + [
            {
                "timestamp": data["timestamp"],
                "agent_type": "store",
                "agent_id": f"store_{store_id}",
                "product_id": product_id,
                "quantity": quantity
            }
            for data in self.simulation_data["inventory_levels"]
            for store_id, inventory in data["stores"].items()
            for product_id, quantity in inventory.items()
        ])

        inventory_df.to_csv(f"data/simulation/inventory_{timestamp}.csv", index=False)

        # Save sales data
        if self.simulation_data["sales"]:
            sales_df = pd.DataFrame(self.simulation_data["sales"])
            sales_df.to_csv(f"data/simulation/sales_{timestamp}.csv", index=False)

        # Save order data
        if self.simulation_data["orders"]:
            order_df = pd.DataFrame(self.simulation_data["orders"])
            order_df.to_csv(f"data/simulation/orders_{timestamp}.csv", index=False)

        # Save metrics
        metrics_df = pd.DataFrame([
            {
                "timestamp": data["timestamp"],
                "agent_type": "warehouse",
                "agent_id": "warehouse_1",
                "metric": metric,
                "value": value
            }
            for data in self.simulation_data["metrics"]
            for metric, value in data["warehouse"].items()
        ] + [
            {
                "timestamp": data["timestamp"],
                "agent_type": "store",
                "agent_id": f"store_{store_id}",
                "metric": metric,
                "value": value
            }
            for data in self.simulation_data["metrics"]
            for store_id, metrics in data["stores"].items()
            for metric, value in metrics.items()
        ])

        metrics_df.to_csv(f"data/simulation/metrics_{timestamp}.csv", index=False)

        # Save products
        products_df = pd.DataFrame(self.simulation_data["products"])
        products_df.to_csv(f"data/simulation/products_{timestamp}.csv", index=False)

        logger.info(f"Simulation data saved to data/simulation/ with timestamp {timestamp}")

    def generate_report(self) -> Dict[str, Any]:
        """
        Generate a summary report of the simulation.

        Returns:
            Dictionary with simulation results.
        """
        report = {
            "simulation_config": self.config,
            "duration": (datetime.now() - self.simulation_time).total_seconds(),
            "num_agents": {
                "stores": len(self.agents["stores"]),
                "warehouse": 1,
                "suppliers": len(self.agents["suppliers"]),
                "customers": len(self.agents["customers"])
            },
            "inventory_summary": {},
            "sales_summary": {},
            "order_summary": {},
            "performance_metrics": {}
        }

        # Inventory summary
        if self.simulation_data["inventory_levels"]:
            latest_inventory = self.simulation_data["inventory_levels"][-1]

            # Warehouse inventory
            warehouse_inventory = latest_inventory["warehouse"]
            report["inventory_summary"]["warehouse"] = {
                "total_items": sum(warehouse_inventory.values()),
                "num_products": len(warehouse_inventory),
                "stockouts": len([pid for pid, qty in warehouse_inventory.items() if qty == 0])
            }

            # Store inventory
            store_inventory = {}
            for store_id, inventory in latest_inventory["stores"].items():
                store_inventory[store_id] = {
                    "total_items": sum(inventory.values()),
                    "num_products": len(inventory),
                    "stockouts": len([pid for pid, qty in inventory.items() if qty == 0])
                }
            report["inventory_summary"]["stores"] = store_inventory

        # Sales summary
        if self.simulation_data["sales"]:
            sales_df = pd.DataFrame(self.simulation_data["sales"])

            # Total sales
            report["sales_summary"]["total_quantity"] = int(sales_df["quantity"].sum())
            report["sales_summary"]["total_revenue"] = float(sales_df["price"].sum())

            # Sales by store
            store_sales = sales_df.groupby("store_id").agg({
                "quantity": "sum",
                "price": "sum"
            }).reset_index()

            report["sales_summary"]["by_store"] = {
                row["store_id"]: {
                    "quantity": int(row["quantity"]),
                    "revenue": float(row["price"])
                }
                for _, row in store_sales.iterrows()
            }

            # Sales by product
            product_sales = sales_df.groupby("product_id").agg({
                "quantity": "sum",
                "price": "sum"
            }).reset_index()

            report["sales_summary"]["by_product"] = {
                row["product_id"]: {
                    "quantity": int(row["quantity"]),
                    "revenue": float(row["price"])
                }
                for _, row in product_sales.iterrows()
            }

        # Order summary
        if self.simulation_data["orders"]:
            orders = self.simulation_data["orders"]

            # Order status counts
            status_counts = {}
            for order in orders:
                status = order.get("status", "unknown")
                if status not in status_counts:
                    status_counts[status] = 0
                status_counts[status] += 1

            report["order_summary"]["status_counts"] = status_counts

            # Total orders
            report["order_summary"]["total_orders"] = len(orders)

            # Orders by supplier
            supplier_orders = {}
            for order in orders:
                supplier_id = order.get("supplier_id")
                if supplier_id not in supplier_orders:
                    supplier_orders[supplier_id] = 0
                supplier_orders[supplier_id] += 1

            report["order_summary"]["by_supplier"] = supplier_orders

        # Performance metrics
        if self.simulation_data["metrics"]:
            latest_metrics = self.simulation_data["metrics"][-1]

            # Warehouse metrics
            report["performance_metrics"]["warehouse"] = latest_metrics["warehouse"]

            # Store metrics
            report["performance_metrics"]["stores"] = latest_metrics["stores"]

        return report
