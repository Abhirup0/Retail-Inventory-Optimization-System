import random
import datetime
import sys
import os
from pathlib import Path
from sqlalchemy.orm import Session

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.database.database import SessionLocal
from src.database.models import Store, Supplier, Product, Inventory, Customer, Sales, Order, OrderItem

def generate_data():
    """Generate synthetic data for the retail inventory database."""
    db = SessionLocal()

    try:
        # Generate stores
        stores = generate_stores()
        db.add_all(stores)
        db.commit()

        # Generate suppliers
        suppliers = generate_suppliers()
        db.add_all(suppliers)
        db.commit()

        # Generate products
        products = generate_products(suppliers)
        db.add_all(products)
        db.commit()

        # Generate inventory
        inventory = generate_inventory(stores, products)
        db.add_all(inventory)
        db.commit()

        # Generate customers
        customers = generate_customers()
        db.add_all(customers)
        db.commit()

        # Generate sales
        sales = generate_sales(stores, products, customers)
        db.add_all(sales)
        db.commit()

        # Generate orders
        orders, order_items = generate_orders(stores, suppliers, products)
        db.add_all(orders)
        db.commit()

        db.add_all(order_items)
        db.commit()

        print("Data generation completed successfully.")

    except Exception as e:
        db.rollback()
        print(f"Error generating data: {e}")

    finally:
        db.close()

def generate_stores(num_stores=5):
    """Generate store data."""
    locations = ["New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego"]
    managers = ["John Smith", "Jane Doe", "Robert Johnson", "Emily Davis", "Michael Wilson", "Sarah Brown", "David Miller", "Jessica Taylor"]

    stores = []
    for i in range(1, num_stores + 1):
        store = Store(
            store_id=i,
            name=f"Store {i}",
            location=random.choice(locations),
            size=random.randint(5000, 20000),  # Store size in square feet
            manager=random.choice(managers)
        )
        stores.append(store)

    return stores

def generate_suppliers(num_suppliers=10):
    """Generate supplier data."""
    supplier_names = [
        "Global Supplies Inc.", "Quality Products Co.", "Premium Goods Ltd.",
        "Wholesale Distributors", "Prime Suppliers", "Elite Merchandise",
        "Superior Products", "Reliable Goods", "Top-Tier Supply Co.",
        "Best Value Distributors", "Excellent Supplies", "First-Rate Products"
    ]

    suppliers = []
    for i in range(1, num_suppliers + 1):
        supplier = Supplier(
            supplier_id=i,
            name=supplier_names[i-1] if i <= len(supplier_names) else f"Supplier {i}",
            contact=f"contact{i}@supplier{i}.com",
            lead_time=random.randint(1, 14)  # Lead time in days
        )
        suppliers.append(supplier)

    return suppliers

def generate_products(suppliers, num_products=50):
    """Generate product data."""
    categories = ["Electronics", "Clothing", "Groceries", "Home Goods", "Toys", "Sports", "Beauty", "Books"]
    product_names = {
        "Electronics": ["Smartphone", "Laptop", "Tablet", "Headphones", "TV", "Camera", "Speaker"],
        "Clothing": ["T-shirt", "Jeans", "Dress", "Jacket", "Shoes", "Hat", "Socks"],
        "Groceries": ["Milk", "Bread", "Eggs", "Cheese", "Fruit", "Vegetables", "Meat"],
        "Home Goods": ["Sofa", "Table", "Chair", "Lamp", "Bed", "Rug", "Curtains"],
        "Toys": ["Action Figure", "Doll", "Board Game", "Puzzle", "Stuffed Animal", "Building Blocks"],
        "Sports": ["Basketball", "Football", "Tennis Racket", "Golf Clubs", "Yoga Mat", "Weights"],
        "Beauty": ["Shampoo", "Conditioner", "Lotion", "Makeup", "Perfume", "Soap"],
        "Books": ["Fiction", "Non-fiction", "Biography", "Cookbook", "Self-help", "Children's Book"]
    }

    products = []
    for i in range(1, num_products + 1):
        category = random.choice(categories)
        product_name = random.choice(product_names[category])
        supplier = random.choice(suppliers)

        product = Product(
            product_id=i,
            name=f"{product_name} {i}",
            category=category,
            supplier_id=supplier.supplier_id,
            price=round(random.uniform(5.99, 199.99), 2),
            lead_time=random.randint(1, 10)  # Product-specific lead time in days
        )
        products.append(product)

    return products

def generate_inventory(stores, products):
    """Generate inventory data."""
    inventory = []
    inventory_id = 1

    for store in stores:
        # Each store has a subset of products
        store_products = random.sample(products, random.randint(30, len(products)))

        for product in store_products:
            quantity = random.randint(0, 100)
            min_level = random.randint(5, 20)
            max_level = random.randint(50, 150)

            inventory_item = Inventory(
                inventory_id=inventory_id,
                store_id=store.store_id,
                product_id=product.product_id,
                quantity=quantity,
                min_level=min_level,
                max_level=max_level,
                last_updated=datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 30))
            )
            inventory.append(inventory_item)
            inventory_id += 1

    return inventory

def generate_customers(num_customers=100):
    """Generate customer data."""
    segments = ["Regular", "Premium", "VIP", "New", "Occasional"]
    preferences = ["Electronics", "Clothing", "Groceries", "Home Goods", "Toys", "Sports", "Beauty", "Books"]

    customers = []
    for i in range(1, num_customers + 1):
        customer = Customer(
            customer_id=i,
            segment=random.choice(segments),
            preferences=random.choice(preferences)
        )
        customers.append(customer)

    return customers

def generate_sales(stores, products, customers, num_sales=1000):
    """Generate sales data."""
    sales = []
    for i in range(1, num_sales + 1):
        store = random.choice(stores)
        product = random.choice(products)
        customer = random.choice(customers)
        quantity = random.randint(1, 5)
        price = product.price * (1 - random.uniform(0, 0.2))  # Apply random discount
        date = datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 365))

        sale = Sales(
            sale_id=i,
            store_id=store.store_id,
            product_id=product.product_id,
            customer_id=customer.customer_id,
            quantity=quantity,
            price=round(price, 2),
            date=date
        )
        sales.append(sale)

    return sales

def generate_orders(stores, suppliers, products, num_orders=100):
    """Generate order data."""
    statuses = ["pending", "shipped", "delivered", "cancelled"]

    orders = []
    order_items = []
    order_item_id = 1

    for i in range(1, num_orders + 1):
        store = random.choice(stores)
        supplier = random.choice(suppliers)
        status = random.choice(statuses)
        order_date = datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 60))

        # Calculate delivery date based on status and order date
        if status == "pending":
            delivery_date = None
        elif status == "shipped":
            delivery_date = order_date + datetime.timedelta(days=random.randint(1, 5))
        elif status == "delivered":
            delivery_date = order_date + datetime.timedelta(days=random.randint(1, 10))
        else:  # cancelled
            delivery_date = None

        order = Order(
            order_id=i,
            store_id=store.store_id,
            supplier_id=supplier.supplier_id,
            status=status,
            order_date=order_date,
            delivery_date=delivery_date
        )
        orders.append(order)

        # Generate order items for this order
        num_items = random.randint(1, 10)
        supplier_products = [p for p in products if p.supplier_id == supplier.supplier_id]

        if supplier_products:
            order_products = random.sample(supplier_products, min(num_items, len(supplier_products)))

            for product in order_products:
                quantity = random.randint(10, 100)
                price = product.price * 0.7  # Wholesale price

                order_item = OrderItem(
                    item_id=order_item_id,
                    order_id=order.order_id,
                    product_id=product.product_id,
                    quantity=quantity,
                    price=round(price, 2)
                )
                order_items.append(order_item)
                order_item_id += 1

    return orders, order_items

if __name__ == "__main__":
    generate_data()
