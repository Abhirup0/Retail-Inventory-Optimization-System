from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, create_engine, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import datetime

Base = declarative_base()

class Store(Base):
    __tablename__ = 'store'
    
    store_id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    location = Column(String, nullable=False)
    size = Column(Integer)
    manager = Column(String)
    
    # Relationships
    inventory = relationship("Inventory", back_populates="store")
    sales = relationship("Sales", back_populates="store")
    orders = relationship("Order", back_populates="store")

class Supplier(Base):
    __tablename__ = 'supplier'
    
    supplier_id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    contact = Column(String)
    lead_time = Column(Integer)  # Average lead time in days
    
    # Relationships
    products = relationship("Product", back_populates="supplier")
    orders = relationship("Order", back_populates="supplier")

class Product(Base):
    __tablename__ = 'product'
    
    product_id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    category = Column(String)
    supplier_id = Column(Integer, ForeignKey('supplier.supplier_id'))
    price = Column(Float, nullable=False)
    lead_time = Column(Integer)  # Product-specific lead time in days
    
    # Relationships
    supplier = relationship("Supplier", back_populates="products")
    inventory = relationship("Inventory", back_populates="product")
    sales = relationship("Sales", back_populates="product")
    order_items = relationship("OrderItem", back_populates="product")

class Inventory(Base):
    __tablename__ = 'inventory'
    
    inventory_id = Column(Integer, primary_key=True)
    store_id = Column(Integer, ForeignKey('store.store_id'))
    product_id = Column(Integer, ForeignKey('product.product_id'))
    quantity = Column(Integer, nullable=False)
    min_level = Column(Integer)
    max_level = Column(Integer)
    last_updated = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    store = relationship("Store", back_populates="inventory")
    product = relationship("Product", back_populates="inventory")

class Customer(Base):
    __tablename__ = 'customer'
    
    customer_id = Column(Integer, primary_key=True)
    segment = Column(String)
    preferences = Column(String)
    
    # Relationships
    sales = relationship("Sales", back_populates="customer")

class Sales(Base):
    __tablename__ = 'sales'
    
    sale_id = Column(Integer, primary_key=True)
    store_id = Column(Integer, ForeignKey('store.store_id'))
    product_id = Column(Integer, ForeignKey('product.product_id'))
    customer_id = Column(Integer, ForeignKey('customer.customer_id'))
    quantity = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)
    date = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    store = relationship("Store", back_populates="sales")
    product = relationship("Product", back_populates="sales")
    customer = relationship("Customer", back_populates="sales")

class Order(Base):
    __tablename__ = 'order'
    
    order_id = Column(Integer, primary_key=True)
    store_id = Column(Integer, ForeignKey('store.store_id'))
    supplier_id = Column(Integer, ForeignKey('supplier.supplier_id'))
    status = Column(String)  # e.g., "pending", "shipped", "delivered"
    order_date = Column(DateTime, default=datetime.datetime.utcnow)
    delivery_date = Column(DateTime)
    
    # Relationships
    store = relationship("Store", back_populates="orders")
    supplier = relationship("Supplier", back_populates="orders")
    order_items = relationship("OrderItem", back_populates="order")

class OrderItem(Base):
    __tablename__ = 'order_item'
    
    item_id = Column(Integer, primary_key=True)
    order_id = Column(Integer, ForeignKey('order.order_id'))
    product_id = Column(Integer, ForeignKey('product.product_id'))
    quantity = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)
    
    # Relationships
    order = relationship("Order", back_populates="order_items")
    product = relationship("Product", back_populates="order_items")

class AgentMemory(Base):
    __tablename__ = 'agent_memory'
    
    memory_id = Column(Integer, primary_key=True)
    agent_id = Column(String, nullable=False)
    memory_type = Column(String)
    content = Column(String)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    relevance = Column(Float)
