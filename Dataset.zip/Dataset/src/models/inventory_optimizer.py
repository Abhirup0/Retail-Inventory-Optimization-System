import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
import math
from src.models.forecasting_engine import ForecastingEngine

logger = logging.getLogger(__name__)

class InventoryOptimizer:
    """
    Optimizer for inventory management decisions.
    
    Determines optimal inventory levels, reorder points, and order quantities
    based on demand forecasts, lead times, and business constraints.
    """
    
    def __init__(self, forecasting_engine: Optional[ForecastingEngine] = None):
        """
        Initialize the inventory optimizer.
        
        Args:
            forecasting_engine: Optional forecasting engine for demand predictions.
        """
        self.forecasting_engine = forecasting_engine
        
        # Default parameters
        self.default_service_level = 0.95  # 95% service level
        self.default_holding_cost_rate = 0.25  # 25% annual holding cost rate
        self.default_ordering_cost = 20.0  # $20 per order
        self.default_lead_time_days = 5  # 5 days lead time
        self.default_review_period_days = 7  # 7 days review period
    
    def calculate_reorder_point(self,
                              product_id: int,
                              lead_time_days: int,
                              demand_forecast: List[float],
                              service_level: float = None,
                              safety_stock_factor: float = None) -> int:
        """
        Calculate the reorder point for a product.
        
        Args:
            product_id: ID of the product.
            lead_time_days: Lead time in days.
            demand_forecast: List of daily demand forecasts.
            service_level: Service level (0-1). If None, uses default.
            safety_stock_factor: Manual safety stock factor. If provided, overrides service level.
            
        Returns:
            Reorder point (units).
        """
        if not demand_forecast:
            logger.warning(f"No demand forecast provided for product {product_id}. Using default values.")
            return 0
        
        # Use default service level if not provided
        if service_level is None:
            service_level = self.default_service_level
        
        # Calculate lead time demand
        if lead_time_days <= len(demand_forecast):
            lead_time_demand = sum(demand_forecast[:lead_time_days])
        else:
            # If lead time is longer than forecast horizon, use average
            avg_daily_demand = sum(demand_forecast) / len(demand_forecast)
            lead_time_demand = avg_daily_demand * lead_time_days
        
        # Calculate standard deviation of demand during lead time
        if len(demand_forecast) >= 2:
            daily_demand_std = np.std(demand_forecast)
            lead_time_demand_std = daily_demand_std * math.sqrt(lead_time_days)
        else:
            # If not enough data, use a simple heuristic
            lead_time_demand_std = lead_time_demand * 0.3  # Assume 30% variation
        
        # Calculate safety stock
        if safety_stock_factor is not None:
            # Use manual safety stock factor
            safety_stock = safety_stock_factor * lead_time_demand_std
        else:
            # Calculate safety factor based on service level
            # Using normal distribution approximation
            if service_level <= 0.5:
                safety_factor = 0
            elif service_level >= 0.999:
                safety_factor = 3.09  # Z-score for 99.9% service level
            else:
                # Approximate Z-score for service level
                # This is a simplified approach; in a real system, we would use a more accurate method
                if service_level <= 0.8:
                    safety_factor = 0.84  # Z-score for 80% service level
                elif service_level <= 0.9:
                    safety_factor = 1.28  # Z-score for 90% service level
                elif service_level <= 0.95:
                    safety_factor = 1.645  # Z-score for 95% service level
                elif service_level <= 0.98:
                    safety_factor = 2.05  # Z-score for 98% service level
                else:
                    safety_factor = 2.33  # Z-score for 99% service level
            
            safety_stock = safety_factor * lead_time_demand_std
        
        # Calculate reorder point
        reorder_point = lead_time_demand + safety_stock
        
        # Round up to nearest integer
        return math.ceil(reorder_point)
    
    def calculate_economic_order_quantity(self,
                                        annual_demand: float,
                                        ordering_cost: float = None,
                                        holding_cost_rate: float = None,
                                        unit_cost: float = 1.0) -> int:
        """
        Calculate the Economic Order Quantity (EOQ) for a product.
        
        Args:
            annual_demand: Annual demand for the product.
            ordering_cost: Cost per order. If None, uses default.
            holding_cost_rate: Annual holding cost rate (0-1). If None, uses default.
            unit_cost: Cost per unit.
            
        Returns:
            Economic Order Quantity (units).
        """
        # Use default values if not provided
        if ordering_cost is None:
            ordering_cost = self.default_ordering_cost
        
        if holding_cost_rate is None:
            holding_cost_rate = self.default_holding_cost_rate
        
        # Calculate annual holding cost per unit
        annual_holding_cost_per_unit = unit_cost * holding_cost_rate
        
        # Calculate EOQ using the Wilson formula
        if annual_demand <= 0 or ordering_cost <= 0 or annual_holding_cost_per_unit <= 0:
            logger.warning("Invalid parameters for EOQ calculation. Using default value.")
            return 1
        
        eoq = math.sqrt((2 * annual_demand * ordering_cost) / annual_holding_cost_per_unit)
        
        # Round to nearest integer
        return max(1, round(eoq))
    
    def calculate_order_quantity(self,
                               product_id: int,
                               current_inventory: int,
                               reorder_point: int,
                               max_inventory: int = None,
                               min_order_quantity: int = 1,
                               eoq: int = None) -> int:
        """
        Calculate the order quantity for a product.
        
        Args:
            product_id: ID of the product.
            current_inventory: Current inventory level.
            reorder_point: Reorder point.
            max_inventory: Maximum inventory level. If None, calculated based on EOQ.
            min_order_quantity: Minimum order quantity.
            eoq: Economic Order Quantity. If None, uses a default value.
            
        Returns:
            Order quantity (units).
        """
        # Check if we need to order
        if current_inventory > reorder_point:
            return 0  # No need to order
        
        # Use provided EOQ or a default value
        if eoq is None:
            eoq = 10  # Default EOQ if not provided
        
        # Calculate max inventory if not provided
        if max_inventory is None:
            max_inventory = reorder_point + eoq
        
        # Calculate order quantity (Order-Up-To policy)
        order_quantity = max_inventory - current_inventory
        
        # Ensure minimum order quantity
        order_quantity = max(min_order_quantity, order_quantity)
        
        return order_quantity
    
    def optimize_inventory_levels(self,
                                product_id: int,
                                demand_forecast: List[float],
                                lead_time_days: int = None,
                                service_level: float = None,
                                holding_cost_rate: float = None,
                                ordering_cost: float = None,
                                unit_cost: float = 1.0,
                                current_inventory: int = 0,
                                min_order_quantity: int = 1) -> Dict[str, Any]:
        """
        Optimize inventory levels for a product.
        
        Args:
            product_id: ID of the product.
            demand_forecast: List of daily demand forecasts.
            lead_time_days: Lead time in days. If None, uses default.
            service_level: Service level (0-1). If None, uses default.
            holding_cost_rate: Annual holding cost rate (0-1). If None, uses default.
            ordering_cost: Cost per order. If None, uses default.
            unit_cost: Cost per unit.
            current_inventory: Current inventory level.
            min_order_quantity: Minimum order quantity.
            
        Returns:
            Dictionary with optimization results.
        """
        # Use default values if not provided
        if lead_time_days is None:
            lead_time_days = self.default_lead_time_days
        
        if service_level is None:
            service_level = self.default_service_level
        
        if holding_cost_rate is None:
            holding_cost_rate = self.default_holding_cost_rate
        
        if ordering_cost is None:
            ordering_cost = self.default_ordering_cost
        
        # Calculate annual demand from forecast
        if demand_forecast:
            avg_daily_demand = sum(demand_forecast) / len(demand_forecast)
            annual_demand = avg_daily_demand * 365
        else:
            logger.warning(f"No demand forecast provided for product {product_id}. Using default values.")
            annual_demand = 365  # Default: 1 unit per day
        
        # Calculate EOQ
        eoq = self.calculate_economic_order_quantity(
            annual_demand=annual_demand,
            ordering_cost=ordering_cost,
            holding_cost_rate=holding_cost_rate,
            unit_cost=unit_cost
        )
        
        # Calculate reorder point
        rop = self.calculate_reorder_point(
            product_id=product_id,
            lead_time_days=lead_time_days,
            demand_forecast=demand_forecast,
            service_level=service_level
        )
        
        # Calculate safety stock
        if len(demand_forecast) >= 2:
            daily_demand_std = np.std(demand_forecast)
            lead_time_demand_std = daily_demand_std * math.sqrt(lead_time_days)
            
            # Calculate safety factor based on service level
            if service_level <= 0.5:
                safety_factor = 0
            elif service_level >= 0.999:
                safety_factor = 3.09
            else:
                if service_level <= 0.8:
                    safety_factor = 0.84
                elif service_level <= 0.9:
                    safety_factor = 1.28
                elif service_level <= 0.95:
                    safety_factor = 1.645
                elif service_level <= 0.98:
                    safety_factor = 2.05
                else:
                    safety_factor = 2.33
            
            safety_stock = safety_factor * lead_time_demand_std
        else:
            # If not enough data, use a simple heuristic
            avg_daily_demand = sum(demand_forecast) / len(demand_forecast) if demand_forecast else 1
            lead_time_demand = avg_daily_demand * lead_time_days
            safety_stock = lead_time_demand * 0.3  # Assume 30% safety stock
        
        # Calculate max inventory level
        max_inventory = rop + eoq
        
        # Calculate order quantity
        order_quantity = self.calculate_order_quantity(
            product_id=product_id,
            current_inventory=current_inventory,
            reorder_point=rop,
            max_inventory=max_inventory,
            min_order_quantity=min_order_quantity,
            eoq=eoq
        )
        
        # Calculate expected stockout probability
        if len(demand_forecast) >= 2:
            daily_demand_std = np.std(demand_forecast)
            lead_time_demand_std = daily_demand_std * math.sqrt(lead_time_days)
            avg_daily_demand = sum(demand_forecast) / len(demand_forecast)
            lead_time_demand = avg_daily_demand * lead_time_days
            
            # Z-score for the reorder point
            z_score = (rop - lead_time_demand) / lead_time_demand_std if lead_time_demand_std > 0 else 0
            
            # Approximate stockout probability using normal distribution
            # This is a simplified approach; in a real system, we would use a more accurate method
            if z_score <= -3.09:
                stockout_probability = 0.999
            elif z_score <= -2.33:
                stockout_probability = 0.99
            elif z_score <= -1.645:
                stockout_probability = 0.95
            elif z_score <= -1.28:
                stockout_probability = 0.9
            elif z_score <= -0.84:
                stockout_probability = 0.8
            elif z_score <= 0:
                stockout_probability = 0.5
            elif z_score <= 0.84:
                stockout_probability = 0.2
            elif z_score <= 1.28:
                stockout_probability = 0.1
            elif z_score <= 1.645:
                stockout_probability = 0.05
            elif z_score <= 2.33:
                stockout_probability = 0.01
            else:
                stockout_probability = 0.001
        else:
            stockout_probability = 0.5  # Default if not enough data
        
        # Calculate expected annual costs
        avg_daily_demand = sum(demand_forecast) / len(demand_forecast) if demand_forecast else 1
        annual_demand = avg_daily_demand * 365
        
        # Annual ordering cost
        annual_orders = annual_demand / eoq if eoq > 0 else 0
        annual_ordering_cost = annual_orders * ordering_cost
        
        # Annual holding cost
        avg_inventory = (eoq / 2) + safety_stock
        annual_holding_cost = avg_inventory * unit_cost * holding_cost_rate
        
        # Annual stockout cost (simplified)
        stockout_cost_per_unit = unit_cost * 2  # Assume stockout cost is twice the unit cost
        annual_stockout_units = annual_demand * stockout_probability * 0.1  # Assume 10% of stockouts result in lost sales
        annual_stockout_cost = annual_stockout_units * stockout_cost_per_unit
        
        # Total annual cost
        total_annual_cost = annual_ordering_cost + annual_holding_cost + annual_stockout_cost
        
        return {
            'reorder_point': rop,
            'economic_order_quantity': eoq,
            'safety_stock': math.ceil(safety_stock),
            'max_inventory': max_inventory,
            'order_quantity': order_quantity,
            'stockout_probability': stockout_probability,
            'service_level': service_level,
            'costs': {
                'annual_ordering_cost': annual_ordering_cost,
                'annual_holding_cost': annual_holding_cost,
                'annual_stockout_cost': annual_stockout_cost,
                'total_annual_cost': total_annual_cost
            }
        }
    
    def optimize_multi_echelon_inventory(self,
                                       warehouse_id: int,
                                       store_ids: List[int],
                                       product_id: int,
                                       warehouse_inventory: int,
                                       store_inventories: Dict[int, int],
                                       demand_forecasts: Dict[int, List[float]],
                                       lead_times: Dict[str, int],
                                       service_levels: Dict[int, float] = None) -> Dict[str, Any]:
        """
        Optimize inventory across multiple echelons (warehouse and stores).
        
        Args:
            warehouse_id: ID of the warehouse.
            store_ids: List of store IDs.
            product_id: ID of the product.
            warehouse_inventory: Current warehouse inventory.
            store_inventories: Dictionary mapping store IDs to current inventory levels.
            demand_forecasts: Dictionary mapping store IDs to demand forecasts.
            lead_times: Dictionary with lead times ('warehouse_to_store' and 'supplier_to_warehouse').
            service_levels: Dictionary mapping store IDs to service levels. If None, uses default.
            
        Returns:
            Dictionary with optimization results.
        """
        # Use default service level if not provided
        if service_levels is None:
            service_levels = {store_id: self.default_service_level for store_id in store_ids}
        
        # Get lead times
        warehouse_to_store_lead_time = lead_times.get('warehouse_to_store', 2)  # Default: 2 days
        supplier_to_warehouse_lead_time = lead_times.get('supplier_to_warehouse', 7)  # Default: 7 days
        
        # Optimize inventory for each store
        store_optimizations = {}
        total_store_demand = []
        
        for store_id in store_ids:
            store_forecast = demand_forecasts.get(store_id, [])
            store_inventory = store_inventories.get(store_id, 0)
            service_level = service_levels.get(store_id, self.default_service_level)
            
            # Optimize store inventory
            store_optimization = self.optimize_inventory_levels(
                product_id=product_id,
                demand_forecast=store_forecast,
                lead_time_days=warehouse_to_store_lead_time,
                service_level=service_level,
                current_inventory=store_inventory
            )
            
            store_optimizations[store_id] = store_optimization
            
            # Aggregate store demand for warehouse optimization
            if store_forecast:
                if not total_store_demand:
                    total_store_demand = store_forecast.copy()
                else:
                    # Add store forecast to total (extend if needed)
                    for i in range(len(store_forecast)):
                        if i < len(total_store_demand):
                            total_store_demand[i] += store_forecast[i]
                        else:
                            total_store_demand.append(store_forecast[i])
        
        # Optimize warehouse inventory
        warehouse_optimization = self.optimize_inventory_levels(
            product_id=product_id,
            demand_forecast=total_store_demand,
            lead_time_days=supplier_to_warehouse_lead_time,
            service_level=0.98,  # Higher service level for warehouse
            current_inventory=warehouse_inventory
        )
        
        # Calculate allocation priorities
        allocation_priorities = {}
        for store_id in store_ids:
            store_opt = store_optimizations[store_id]
            store_inventory = store_inventories.get(store_id, 0)
            
            # Calculate days of supply
            store_forecast = demand_forecasts.get(store_id, [])
            avg_daily_demand = sum(store_forecast) / len(store_forecast) if store_forecast else 1
            days_of_supply = store_inventory / avg_daily_demand if avg_daily_demand > 0 else float('inf')
            
            # Calculate priority score (lower is higher priority)
            # Factors: days of supply, service level, stockout probability
            priority_score = days_of_supply * (1 - store_opt['stockout_probability'])
            
            allocation_priorities[store_id] = {
                'priority_score': priority_score,
                'days_of_supply': days_of_supply,
                'stockout_probability': store_opt['stockout_probability']
            }
        
        # Sort stores by priority (lowest score first)
        sorted_stores = sorted(allocation_priorities.items(), key=lambda x: x[1]['priority_score'])
        
        return {
            'warehouse_optimization': warehouse_optimization,
            'store_optimizations': store_optimizations,
            'allocation_priorities': allocation_priorities,
            'sorted_stores': [store_id for store_id, _ in sorted_stores]
        }
    
    def calculate_optimal_allocation(self,
                                   warehouse_inventory: int,
                                   store_requests: Dict[int, int],
                                   store_priorities: Dict[int, float] = None) -> Dict[int, int]:
        """
        Calculate optimal allocation of warehouse inventory to stores.
        
        Args:
            warehouse_inventory: Available warehouse inventory.
            store_requests: Dictionary mapping store IDs to requested quantities.
            store_priorities: Dictionary mapping store IDs to priority scores (higher is higher priority).
                             If None, all stores have equal priority.
            
        Returns:
            Dictionary mapping store IDs to allocated quantities.
        """
        # Use equal priorities if not provided
        if store_priorities is None:
            store_priorities = {store_id: 1.0 for store_id in store_requests}
        
        # Calculate total requested quantity
        total_requested = sum(store_requests.values())
        
        # If we have enough inventory to fulfill all requests, do so
        if warehouse_inventory >= total_requested:
            return store_requests.copy()
        
        # Otherwise, allocate based on priorities
        allocations = {}
        remaining_inventory = warehouse_inventory
        
        # Sort stores by priority (highest first)
        sorted_stores = sorted(store_priorities.items(), key=lambda x: x[1], reverse=True)
        
        # First pass: allocate to high-priority stores
        for store_id, priority in sorted_stores:
            requested = store_requests.get(store_id, 0)
            
            if requested <= 0:
                allocations[store_id] = 0
                continue
            
            # Allocate based on priority
            if priority >= 2.0:  # Very high priority
                # Allocate full request if possible
                allocated = min(requested, remaining_inventory)
            elif priority >= 1.5:  # High priority
                # Allocate up to 90% of request
                allocated = min(int(requested * 0.9), remaining_inventory)
            elif priority >= 1.0:  # Normal priority
                # Allocate up to 70% of request
                allocated = min(int(requested * 0.7), remaining_inventory)
            else:  # Low priority
                # Allocate up to 50% of request
                allocated = min(int(requested * 0.5), remaining_inventory)
            
            allocations[store_id] = allocated
            remaining_inventory -= allocated
        
        # Second pass: allocate remaining inventory proportionally
        if remaining_inventory > 0:
            # Calculate unfulfilled requests
            unfulfilled = {}
            for store_id, requested in store_requests.items():
                allocated = allocations.get(store_id, 0)
                unfulfilled[store_id] = requested - allocated
            
            # Calculate total unfulfilled
            total_unfulfilled = sum(unfulfilled.values())
            
            if total_unfulfilled > 0:
                # Allocate remaining inventory proportionally
                for store_id, unmet in unfulfilled.items():
                    if unmet <= 0:
                        continue
                    
                    proportion = unmet / total_unfulfilled
                    additional = int(remaining_inventory * proportion)
                    allocations[store_id] += additional
                    remaining_inventory -= additional
                
                # Allocate any remaining units (due to rounding) to the store with the highest priority
                if remaining_inventory > 0:
                    for store_id, _ in sorted_stores:
                        if unfulfilled.get(store_id, 0) > allocations.get(store_id, 0):
                            allocations[store_id] += remaining_inventory
                            break
        
        return allocations
    
    def simulate_inventory_policy(self,
                                product_id: int,
                                initial_inventory: int,
                                demand_forecast: List[float],
                                lead_time_days: int,
                                reorder_point: int,
                                order_quantity: int,
                                simulation_days: int = 30) -> Dict[str, Any]:
        """
        Simulate an inventory policy over time.
        
        Args:
            product_id: ID of the product.
            initial_inventory: Initial inventory level.
            demand_forecast: List of daily demand forecasts.
            lead_time_days: Lead time in days.
            reorder_point: Reorder point.
            order_quantity: Order quantity.
            simulation_days: Number of days to simulate.
            
        Returns:
            Dictionary with simulation results.
        """
        # Initialize simulation
        inventory = initial_inventory
        pending_orders = []  # List of (arrival_day, quantity) tuples
        inventory_levels = []
        stockouts = 0
        orders_placed = 0
        
        # Extend demand forecast if needed
        if len(demand_forecast) < simulation_days:
            # Repeat the forecast
            extended_forecast = []
            for i in range(simulation_days):
                extended_forecast.append(demand_forecast[i % len(demand_forecast)])
            demand_forecast = extended_forecast
        
        # Run simulation
        for day in range(simulation_days):
            # Record inventory level at start of day
            inventory_levels.append(inventory)
            
            # Process any arriving orders
            arriving_orders = [(d, q) for d, q in pending_orders if d == day]
            for _, quantity in arriving_orders:
                inventory += quantity
            
            # Remove processed orders
            pending_orders = [(d, q) for d, q in pending_orders if d != day]
            
            # Process demand for the day
            demand = demand_forecast[day]
            if demand <= inventory:
                inventory -= demand
            else:
                # Stockout
                stockouts += 1
                inventory = 0
            
            # Check if we need to place an order
            if inventory <= reorder_point and not pending_orders:
                # Place order
                arrival_day = day + lead_time_days
                pending_orders.append((arrival_day, order_quantity))
                orders_placed += 1
        
        # Calculate metrics
        avg_inventory = sum(inventory_levels) / len(inventory_levels)
        max_inventory = max(inventory_levels)
        min_inventory = min(inventory_levels)
        stockout_rate = stockouts / simulation_days
        service_level = 1 - stockout_rate
        
        return {
            'avg_inventory': avg_inventory,
            'max_inventory': max_inventory,
            'min_inventory': min_inventory,
            'stockouts': stockouts,
            'stockout_rate': stockout_rate,
            'service_level': service_level,
            'orders_placed': orders_placed,
            'inventory_levels': inventory_levels,
            'final_inventory': inventory,
            'pending_orders': pending_orders
        }
