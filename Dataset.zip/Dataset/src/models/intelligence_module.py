import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
import os
from pathlib import Path

from src.models.forecasting_engine import ForecastingEngine
from src.models.inventory_optimizer import InventoryOptimizer
from src.models.pricing_optimizer import PricingOptimizer
from src.utils.llm_integration import OllamaLLMClient

logger = logging.getLogger(__name__)

class IntelligenceModule:
    """
    Central intelligence module that integrates forecasting, inventory optimization,
    and pricing optimization with LLM-based reasoning.
    """
    
    def __init__(self, db_session=None, ollama_model: str = "mistral"):
        """
        Initialize the intelligence module.
        
        Args:
            db_session: Database session for data access.
            ollama_model: Name of the Ollama model to use.
        """
        self.db_session = db_session
        
        # Initialize sub-modules
        self.forecasting_engine = ForecastingEngine()
        self.inventory_optimizer = InventoryOptimizer(forecasting_engine=self.forecasting_engine)
        self.pricing_optimizer = PricingOptimizer(forecasting_engine=self.forecasting_engine)
        
        # Initialize LLM client
        self.llm_client = OllamaLLMClient(model_name=ollama_model)
        
        # Create data directory if it doesn't exist
        os.makedirs("data/models", exist_ok=True)
    
    async def analyze_product_data(self, product_id: int, sales_data: pd.DataFrame) -> Dict[str, Any]:
        """
        Analyze product data to extract insights.
        
        Args:
            product_id: ID of the product.
            sales_data: DataFrame with historical sales data.
            
        Returns:
            Dictionary with analysis results.
        """
        results = {}
        
        # Check if we have enough data
        if sales_data.empty or len(sales_data) < 10:
            logger.warning(f"Insufficient sales data for product {product_id}. Analysis may be limited.")
            results['data_quality'] = 'insufficient'
        else:
            results['data_quality'] = 'sufficient'
        
        # Analyze sales trends
        if not sales_data.empty and 'date' in sales_data.columns and 'quantity' in sales_data.columns:
            # Ensure date is datetime
            sales_data['date'] = pd.to_datetime(sales_data['date'])
            
            # Group by date and sum quantities
            daily_sales = sales_data.groupby('date')['quantity'].sum().reset_index()
            
            # Calculate basic statistics
            results['total_sales'] = int(daily_sales['quantity'].sum())
            results['avg_daily_sales'] = float(daily_sales['quantity'].mean())
            results['max_daily_sales'] = int(daily_sales['quantity'].max())
            results['sales_volatility'] = float(daily_sales['quantity'].std() / daily_sales['quantity'].mean()) if daily_sales['quantity'].mean() > 0 else 0
            
            # Analyze seasonality
            results['seasonality'] = self.forecasting_engine.get_seasonal_patterns(product_id, sales_data)
        
        # Analyze price elasticity
        if not sales_data.empty and 'price' in sales_data.columns and 'quantity' in sales_data.columns:
            results['price_elasticity'] = float(self.pricing_optimizer.estimate_price_elasticity(product_id, sales_data))
        
        # Use LLM to generate insights
        if results:
            insights_prompt = f"""
            Analyze the following data for product {product_id}:
            
            {results}
            
            Please provide 3-5 key insights about this product based on the data.
            Focus on actionable insights related to sales patterns, seasonality, and pricing.
            """
            
            try:
                insights = await self.llm_client.generate_response(insights_prompt)
                results['insights'] = insights
            except Exception as e:
                logger.error(f"Error generating insights with LLM: {e}")
                results['insights'] = "Unable to generate insights due to an error."
        
        return results
    
    async def forecast_demand(self, 
                            product_id: int, 
                            sales_data: pd.DataFrame, 
                            forecast_days: int = 30) -> Dict[str, Any]:
        """
        Forecast demand for a product.
        
        Args:
            product_id: ID of the product.
            sales_data: DataFrame with historical sales data.
            forecast_days: Number of days to forecast.
            
        Returns:
            Dictionary with forecast results.
        """
        # Train forecasting model
        model_info = self.forecasting_engine.train_model(product_id, sales_data)
        
        if not model_info:
            logger.warning(f"Failed to train forecasting model for product {product_id}.")
            return {
                'success': False,
                'error': 'Failed to train forecasting model'
            }
        
        # Generate future dates
        start_date = datetime.now()
        future_dates = [start_date + timedelta(days=i) for i in range(forecast_days)]
        
        # Generate forecast with confidence intervals
        forecast = self.forecasting_engine.forecast_with_confidence(product_id, future_dates)
        
        # Format results
        formatted_forecast = {
            'success': True,
            'product_id': product_id,
            'forecast_days': forecast_days,
            'start_date': start_date.isoformat(),
            'dates': [d.isoformat() for d in future_dates],
            'forecast': forecast['forecast'],
            'lower_bound': forecast['lower_bound'],
            'upper_bound': forecast['upper_bound'],
            'model_performance': model_info['performance']
        }
        
        # Add seasonality information
        seasonality = self.forecasting_engine.get_seasonal_patterns(product_id, sales_data)
        if seasonality:
            formatted_forecast['seasonality'] = seasonality
        
        # Use LLM to generate forecast summary
        summary_prompt = f"""
        Analyze the following demand forecast for product {product_id}:
        
        Forecast period: {forecast_days} days starting from {start_date.strftime('%Y-%m-%d')}
        Average daily demand: {sum(forecast['forecast']) / len(forecast['forecast']):.2f} units
        Peak demand: {max(forecast['forecast']):.2f} units
        Minimum demand: {min(forecast['forecast']):.2f} units
        
        Seasonality information:
        {seasonality}
        
        Please provide a concise summary of this forecast, highlighting key patterns and implications for inventory management.
        """
        
        try:
            summary = await self.llm_client.generate_response(summary_prompt)
            formatted_forecast['summary'] = summary
        except Exception as e:
            logger.error(f"Error generating forecast summary with LLM: {e}")
            formatted_forecast['summary'] = "Unable to generate forecast summary due to an error."
        
        return formatted_forecast
    
    async def optimize_inventory(self,
                               product_id: int,
                               cost: float,
                               current_inventory: int,
                               sales_data: pd.DataFrame,
                               lead_time_days: int = None) -> Dict[str, Any]:
        """
        Optimize inventory for a product.
        
        Args:
            product_id: ID of the product.
            cost: Cost per unit.
            current_inventory: Current inventory level.
            sales_data: DataFrame with historical sales data.
            lead_time_days: Lead time in days. If None, uses default.
            
        Returns:
            Dictionary with optimization results.
        """
        # Generate demand forecast
        start_date = datetime.now()
        forecast_days = 30  # Use 30 days for inventory optimization
        future_dates = [start_date + timedelta(days=i) for i in range(forecast_days)]
        
        # Train forecasting model if needed
        if product_id not in self.forecasting_engine.models:
            self.forecasting_engine.train_model(product_id, sales_data)
        
        # Generate demand forecast
        demand_forecast = self.forecasting_engine.predict_demand(product_id, future_dates)
        
        # Optimize inventory levels
        optimization_results = self.inventory_optimizer.optimize_inventory_levels(
            product_id=product_id,
            demand_forecast=demand_forecast,
            lead_time_days=lead_time_days,
            unit_cost=cost,
            current_inventory=current_inventory
        )
        
        # Simulate inventory policy
        simulation_results = self.inventory_optimizer.simulate_inventory_policy(
            product_id=product_id,
            initial_inventory=current_inventory,
            demand_forecast=demand_forecast,
            lead_time_days=lead_time_days or self.inventory_optimizer.default_lead_time_days,
            reorder_point=optimization_results['reorder_point'],
            order_quantity=optimization_results['economic_order_quantity'],
            simulation_days=forecast_days
        )
        
        # Combine results
        combined_results = {
            'success': True,
            'product_id': product_id,
            'current_inventory': current_inventory,
            'optimization': optimization_results,
            'simulation': simulation_results
        }
        
        # Use LLM to generate recommendations
        recommendation_prompt = f"""
        Analyze the following inventory optimization results for product {product_id}:
        
        Current inventory: {current_inventory} units
        Reorder point: {optimization_results['reorder_point']} units
        Economic order quantity: {optimization_results['economic_order_quantity']} units
        Safety stock: {optimization_results['safety_stock']} units
        
        Simulation results:
        - Average inventory: {simulation_results['avg_inventory']:.2f} units
        - Stockout rate: {simulation_results['stockout_rate'] * 100:.2f}%
        - Service level: {simulation_results['service_level'] * 100:.2f}%
        - Orders placed: {simulation_results['orders_placed']}
        
        Annual costs:
        - Ordering cost: ${optimization_results['costs']['annual_ordering_cost']:.2f}
        - Holding cost: ${optimization_results['costs']['annual_holding_cost']:.2f}
        - Stockout cost: ${optimization_results['costs']['annual_stockout_cost']:.2f}
        - Total cost: ${optimization_results['costs']['total_annual_cost']:.2f}
        
        Please provide specific inventory management recommendations for this product.
        Include when to reorder, how much to order, and any other relevant advice.
        """
        
        try:
            recommendations = await self.llm_client.generate_response(recommendation_prompt)
            combined_results['recommendations'] = recommendations
        except Exception as e:
            logger.error(f"Error generating inventory recommendations with LLM: {e}")
            combined_results['recommendations'] = "Unable to generate recommendations due to an error."
        
        return combined_results
    
    async def optimize_pricing(self,
                             product_id: int,
                             cost: float,
                             current_price: float,
                             current_inventory: int,
                             target_inventory: int,
                             sales_data: pd.DataFrame) -> Dict[str, Any]:
        """
        Optimize pricing for a product.
        
        Args:
            product_id: ID of the product.
            cost: Cost per unit.
            current_price: Current price.
            current_inventory: Current inventory level.
            target_inventory: Target inventory level.
            sales_data: DataFrame with historical sales data.
            
        Returns:
            Dictionary with optimization results.
        """
        # Estimate price elasticity
        price_elasticity = self.pricing_optimizer.estimate_price_elasticity(product_id, sales_data)
        
        # Calculate optimal price
        pricing_results = self.pricing_optimizer.calculate_optimal_price(
            product_id=product_id,
            cost=cost,
            current_price=current_price,
            inventory_level=current_inventory,
            target_inventory=target_inventory,
            price_elasticity=price_elasticity
        )
        
        # Get days in stock (simplified)
        days_in_stock = 30  # Default value
        if 'date' in sales_data.columns:
            sales_data['date'] = pd.to_datetime(sales_data['date'])
            first_sale_date = sales_data['date'].min()
            days_in_stock = (datetime.now() - first_sale_date).days
        
        # Get product category
        product_category = "Unknown"
        if 'category' in sales_data.columns:
            categories = sales_data[sales_data['product_id'] == product_id]['category'].unique()
            if len(categories) > 0:
                product_category = categories[0]
        
        # Get seasonality information
        seasonality = self.forecasting_engine.get_seasonal_patterns(product_id, sales_data)
        
        # Recommend promotions
        promotion_recommendations = self.pricing_optimizer.recommend_promotions(
            product_id=product_id,
            inventory_level=current_inventory,
            target_inventory=target_inventory,
            days_in_stock=days_in_stock,
            product_category=product_category,
            product_seasonality=seasonality
        )
        
        # Simulate pricing strategies
        simulation_days = 30
        
        # Estimate base demand
        avg_daily_demand = 0
        if 'quantity' in sales_data.columns:
            product_sales = sales_data[sales_data['product_id'] == product_id]
            if not product_sales.empty:
                avg_daily_demand = product_sales['quantity'].sum() / len(product_sales['date'].unique())
        
        fixed_price_simulation = self.pricing_optimizer.simulate_pricing_strategy(
            product_id=product_id,
            initial_price=current_price,
            cost=cost,
            initial_inventory=current_inventory,
            daily_demand_base=avg_daily_demand,
            price_elasticity=price_elasticity,
            simulation_days=simulation_days,
            pricing_strategy='fixed'
        )
        
        dynamic_price_simulation = self.pricing_optimizer.simulate_pricing_strategy(
            product_id=product_id,
            initial_price=pricing_results['optimal_price'],
            cost=cost,
            initial_inventory=current_inventory,
            daily_demand_base=avg_daily_demand,
            price_elasticity=price_elasticity,
            simulation_days=simulation_days,
            pricing_strategy='dynamic'
        )
        
        # Combine results
        combined_results = {
            'success': True,
            'product_id': product_id,
            'current_price': current_price,
            'optimal_price': pricing_results['optimal_price'],
            'price_change_pct': pricing_results['price_change_pct'],
            'price_change_reason': pricing_results['price_change_reason'],
            'expected_demand_change_pct': pricing_results['expected_demand_change_pct'],
            'new_margin': pricing_results['new_margin'],
            'price_elasticity': price_elasticity,
            'promotions': promotion_recommendations,
            'simulations': {
                'fixed_price': fixed_price_simulation,
                'dynamic_price': dynamic_price_simulation
            }
        }
        
        # Use LLM to generate recommendations
        recommendation_prompt = f"""
        Analyze the following pricing optimization results for product {product_id}:
        
        Current price: ${current_price:.2f}
        Optimal price: ${pricing_results['optimal_price']:.2f}
        Price change: {pricing_results['price_change_pct']:.2f}%
        Reason: {pricing_results['price_change_reason']}
        
        Expected demand change: {pricing_results['expected_demand_change_pct']:.2f}%
        New margin: {pricing_results['new_margin'] * 100:.2f}%
        Price elasticity: {price_elasticity:.2f}
        
        Promotion recommendations:
        {promotion_recommendations}
        
        Simulation results (30 days):
        - Fixed price strategy: ${fixed_price_simulation['total_profit']:.2f} profit, {fixed_price_simulation['stockout_rate'] * 100:.2f}% stockout rate
        - Dynamic price strategy: ${dynamic_price_simulation['total_profit']:.2f} profit, {dynamic_price_simulation['stockout_rate'] * 100:.2f}% stockout rate
        
        Please provide specific pricing recommendations for this product.
        Include what price to set, whether to run promotions, and which pricing strategy to use.
        """
        
        try:
            recommendations = await self.llm_client.generate_response(recommendation_prompt)
            combined_results['recommendations'] = recommendations
        except Exception as e:
            logger.error(f"Error generating pricing recommendations with LLM: {e}")
            combined_results['recommendations'] = "Unable to generate recommendations due to an error."
        
        return combined_results
    
    async def optimize_store_inventory(self,
                                     store_id: int,
                                     product_data: Dict[int, Dict[str, Any]],
                                     sales_data: pd.DataFrame) -> Dict[str, Any]:
        """
        Optimize inventory across all products in a store.
        
        Args:
            store_id: ID of the store.
            product_data: Dictionary mapping product IDs to product data.
            sales_data: DataFrame with historical sales data.
            
        Returns:
            Dictionary with optimization results.
        """
        results = {
            'store_id': store_id,
            'products': {},
            'summary': {}
        }
        
        total_current_inventory_value = 0
        total_optimal_inventory_value = 0
        total_current_inventory_units = 0
        total_optimal_inventory_units = 0
        stockout_risk_products = []
        excess_inventory_products = []
        
        # Process each product
        for product_id, data in product_data.items():
            # Extract product data
            cost = data.get('cost', 0)
            current_inventory = data.get('current_inventory', 0)
            current_price = data.get('current_price', 0)
            
            # Filter sales data for this product
            product_sales = sales_data[sales_data['product_id'] == product_id].copy()
            
            # Skip if no sales data
            if product_sales.empty:
                continue
            
            # Generate demand forecast
            start_date = datetime.now()
            forecast_days = 30
            future_dates = [start_date + timedelta(days=i) for i in range(forecast_days)]
            
            # Train forecasting model if needed
            if product_id not in self.forecasting_engine.models:
                self.forecasting_engine.train_model(product_id, product_sales)
            
            # Generate demand forecast
            demand_forecast = self.forecasting_engine.predict_demand(product_id, future_dates)
            
            # Optimize inventory levels
            optimization_results = self.inventory_optimizer.optimize_inventory_levels(
                product_id=product_id,
                demand_forecast=demand_forecast,
                unit_cost=cost,
                current_inventory=current_inventory
            )
            
            # Calculate inventory values
            current_inventory_value = current_inventory * cost
            optimal_inventory = optimization_results['reorder_point'] + optimization_results['safety_stock']
            optimal_inventory_value = optimal_inventory * cost
            
            # Update totals
            total_current_inventory_value += current_inventory_value
            total_optimal_inventory_value += optimal_inventory_value
            total_current_inventory_units += current_inventory
            total_optimal_inventory_units += optimal_inventory
            
            # Check for stockout risk or excess inventory
            if current_inventory < optimization_results['reorder_point']:
                stockout_risk_products.append({
                    'product_id': product_id,
                    'current_inventory': current_inventory,
                    'reorder_point': optimization_results['reorder_point'],
                    'order_quantity': optimization_results['order_quantity']
                })
            elif current_inventory > optimal_inventory * 1.5:
                excess_inventory_products.append({
                    'product_id': product_id,
                    'current_inventory': current_inventory,
                    'optimal_inventory': optimal_inventory,
                    'excess_units': current_inventory - optimal_inventory
                })
            
            # Store results for this product
            results['products'][product_id] = {
                'current_inventory': current_inventory,
                'optimal_inventory': optimal_inventory,
                'reorder_point': optimization_results['reorder_point'],
                'safety_stock': optimization_results['safety_stock'],
                'order_quantity': optimization_results['order_quantity'],
                'current_inventory_value': current_inventory_value,
                'optimal_inventory_value': optimal_inventory_value
            }
        
        # Calculate summary metrics
        inventory_value_change = total_optimal_inventory_value - total_current_inventory_value
        inventory_value_change_pct = (inventory_value_change / total_current_inventory_value * 100) if total_current_inventory_value > 0 else 0
        
        results['summary'] = {
            'total_products': len(results['products']),
            'total_current_inventory_value': total_current_inventory_value,
            'total_optimal_inventory_value': total_optimal_inventory_value,
            'inventory_value_change': inventory_value_change,
            'inventory_value_change_pct': inventory_value_change_pct,
            'total_current_inventory_units': total_current_inventory_units,
            'total_optimal_inventory_units': total_optimal_inventory_units,
            'stockout_risk_products': len(stockout_risk_products),
            'excess_inventory_products': len(excess_inventory_products)
        }
        
        # Use LLM to generate recommendations
        recommendation_prompt = f"""
        Analyze the following store-wide inventory optimization results for store {store_id}:
        
        Summary:
        - Total products analyzed: {len(results['products'])}
        - Current inventory value: ${total_current_inventory_value:.2f}
        - Optimal inventory value: ${total_optimal_inventory_value:.2f}
        - Inventory value change: ${inventory_value_change:.2f} ({inventory_value_change_pct:.2f}%)
        - Products at stockout risk: {len(stockout_risk_products)}
        - Products with excess inventory: {len(excess_inventory_products)}
        
        Stockout risk products:
        {stockout_risk_products[:5]}  # Showing first 5
        
        Excess inventory products:
        {excess_inventory_products[:5]}  # Showing first 5
        
        Please provide store-wide inventory management recommendations.
        Focus on addressing stockout risks, reducing excess inventory, and optimizing overall inventory value.
        """
        
        try:
            recommendations = await self.llm_client.generate_response(recommendation_prompt)
            results['recommendations'] = recommendations
        except Exception as e:
            logger.error(f"Error generating store-wide recommendations with LLM: {e}")
            results['recommendations'] = "Unable to generate recommendations due to an error."
        
        return results
    
    async def optimize_multi_store_inventory(self,
                                          warehouse_id: int,
                                          store_ids: List[int],
                                          product_id: int,
                                          warehouse_inventory: int,
                                          store_inventories: Dict[int, int],
                                          sales_data: pd.DataFrame) -> Dict[str, Any]:
        """
        Optimize inventory for a product across multiple stores.
        
        Args:
            warehouse_id: ID of the warehouse.
            store_ids: List of store IDs.
            product_id: ID of the product.
            warehouse_inventory: Current warehouse inventory.
            store_inventories: Dictionary mapping store IDs to current inventory levels.
            sales_data: DataFrame with historical sales data.
            
        Returns:
            Dictionary with optimization results.
        """
        # Prepare demand forecasts for each store
        demand_forecasts = {}
        forecast_days = 30
        start_date = datetime.now()
        future_dates = [start_date + timedelta(days=i) for i in range(forecast_days)]
        
        for store_id in store_ids:
            # Filter sales data for this store and product
            store_sales = sales_data[(sales_data['store_id'] == store_id) & 
                                    (sales_data['product_id'] == product_id)].copy()
            
            # Skip if no sales data
            if store_sales.empty:
                demand_forecasts[store_id] = [0] * forecast_days
                continue
            
            # Train forecasting model if needed
            model_key = f"store_{store_id}_product_{product_id}"
            if model_key not in self.forecasting_engine.models:
                self.forecasting_engine.train_model(model_key, store_sales)
            
            # Generate demand forecast
            demand_forecasts[store_id] = self.forecasting_engine.predict_demand(model_key, future_dates)
        
        # Define lead times
        lead_times = {
            'warehouse_to_store': 2,  # 2 days from warehouse to store
            'supplier_to_warehouse': 7  # 7 days from supplier to warehouse
        }
        
        # Optimize multi-echelon inventory
        optimization_results = self.inventory_optimizer.optimize_multi_echelon_inventory(
            warehouse_id=warehouse_id,
            store_ids=store_ids,
            product_id=product_id,
            warehouse_inventory=warehouse_inventory,
            store_inventories=store_inventories,
            demand_forecasts=demand_forecasts,
            lead_times=lead_times
        )
        
        # Calculate allocation if warehouse inventory is limited
        total_requested = 0
        store_requests = {}
        
        for store_id in store_ids:
            store_opt = optimization_results['store_optimizations'].get(store_id, {})
            current_inventory = store_inventories.get(store_id, 0)
            order_quantity = store_opt.get('order_quantity', 0)
            
            if order_quantity > 0:
                store_requests[store_id] = order_quantity
                total_requested += order_quantity
        
        # Calculate allocation priorities
        store_priorities = {
            store_id: 1.0 / optimization_results['allocation_priorities'].get(store_id, {}).get('priority_score', 1.0)
            for store_id in store_ids
        }
        
        # Calculate optimal allocation
        allocations = self.inventory_optimizer.calculate_optimal_allocation(
            warehouse_inventory=warehouse_inventory,
            store_requests=store_requests,
            store_priorities=store_priorities
        )
        
        # Add allocations to results
        optimization_results['allocations'] = allocations
        optimization_results['total_requested'] = total_requested
        optimization_results['warehouse_inventory'] = warehouse_inventory
        
        # Use LLM to generate recommendations
        recommendation_prompt = f"""
        Analyze the following multi-store inventory optimization results for product {product_id}:
        
        Warehouse:
        - Current inventory: {warehouse_inventory} units
        - Reorder point: {optimization_results['warehouse_optimization']['reorder_point']} units
        - Order quantity: {optimization_results['warehouse_optimization']['order_quantity']} units
        
        Store requests:
        {store_requests}
        
        Allocations:
        {allocations}
        
        Total requested: {total_requested} units
        Available in warehouse: {warehouse_inventory} units
        
        Please provide recommendations for:
        1. How to allocate the warehouse inventory to stores
        2. Whether the warehouse should order more inventory
        3. How to handle any shortages or excess inventory
        """
        
        try:
            recommendations = await self.llm_client.generate_response(recommendation_prompt)
            optimization_results['recommendations'] = recommendations
        except Exception as e:
            logger.error(f"Error generating multi-store recommendations with LLM: {e}")
            optimization_results['recommendations'] = "Unable to generate recommendations due to an error."
        
        return optimization_results
