import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
import math
from src.models.forecasting_engine import ForecastingEngine

logger = logging.getLogger(__name__)

class PricingOptimizer:
    """
    Optimizer for product pricing decisions.
    
    Determines optimal prices based on inventory levels, demand elasticity,
    competitor pricing, and business constraints.
    """
    
    def __init__(self, forecasting_engine: Optional[ForecastingEngine] = None):
        """
        Initialize the pricing optimizer.
        
        Args:
            forecasting_engine: Optional forecasting engine for demand predictions.
        """
        self.forecasting_engine = forecasting_engine
        
        # Default parameters
        self.default_margin = 0.3  # 30% margin
        self.default_price_elasticity = -1.5  # Price elasticity of demand
        self.default_min_margin = 0.1  # 10% minimum margin
        self.default_max_discount = 0.5  # 50% maximum discount
    
    def estimate_price_elasticity(self, 
                                product_id: int, 
                                sales_data: pd.DataFrame) -> float:
        """
        Estimate price elasticity of demand for a product.
        
        Args:
            product_id: ID of the product.
            sales_data: DataFrame with historical sales data including price and quantity.
            
        Returns:
            Estimated price elasticity (negative value).
        """
        if sales_data.empty:
            logger.warning(f"No sales data provided for product {product_id}. Using default price elasticity.")
            return self.default_price_elasticity
        
        # Filter for this product
        product_sales = sales_data[sales_data['product_id'] == product_id].copy()
        
        if len(product_sales) < 5:
            logger.warning(f"Insufficient sales data for product {product_id}. Using default price elasticity.")
            return self.default_price_elasticity
        
        # Check if we have price and quantity columns
        if 'price' not in product_sales.columns or 'quantity' not in product_sales.columns:
            logger.warning(f"Price or quantity column not found in sales data for product {product_id}. Using default price elasticity.")
            return self.default_price_elasticity
        
        try:
            # Calculate log values
            product_sales['log_price'] = np.log(product_sales['price'])
            product_sales['log_quantity'] = np.log(product_sales['quantity'])
            
            # Calculate price elasticity using linear regression
            # This is a simplified approach; in a real system, we would use a more sophisticated method
            price_var = product_sales['log_price'].var()
            if price_var == 0:
                logger.warning(f"No price variation in sales data for product {product_id}. Using default price elasticity.")
                return self.default_price_elasticity
            
            price_qty_cov = np.cov(product_sales['log_price'], product_sales['log_quantity'])[0, 1]
            elasticity = price_qty_cov / price_var
            
            # Ensure elasticity is negative (normal goods)
            elasticity = min(elasticity, -0.1)
            
            # Limit to reasonable range
            elasticity = max(elasticity, -5.0)
            
            logger.info(f"Estimated price elasticity for product {product_id}: {elasticity:.2f}")
            return elasticity
            
        except Exception as e:
            logger.error(f"Error estimating price elasticity for product {product_id}: {e}")
            return self.default_price_elasticity
    
    def calculate_optimal_price(self,
                              product_id: int,
                              cost: float,
                              current_price: float,
                              inventory_level: int,
                              target_inventory: int,
                              price_elasticity: float = None,
                              min_margin: float = None,
                              max_discount: float = None,
                              competitor_prices: List[float] = None) -> Dict[str, Any]:
        """
        Calculate the optimal price for a product.
        
        Args:
            product_id: ID of the product.
            cost: Cost per unit.
            current_price: Current price.
            inventory_level: Current inventory level.
            target_inventory: Target inventory level.
            price_elasticity: Price elasticity of demand. If None, uses default.
            min_margin: Minimum margin (0-1). If None, uses default.
            max_discount: Maximum discount (0-1). If None, uses default.
            competitor_prices: List of competitor prices.
            
        Returns:
            Dictionary with pricing recommendations.
        """
        # Use default values if not provided
        if price_elasticity is None:
            price_elasticity = self.default_price_elasticity
        
        if min_margin is None:
            min_margin = self.default_min_margin
        
        if max_discount is None:
            max_discount = self.default_max_discount
        
        # Calculate inventory ratio
        inventory_ratio = inventory_level / target_inventory if target_inventory > 0 else float('inf')
        
        # Calculate minimum price based on cost and minimum margin
        min_price = cost / (1 - min_margin)
        
        # Calculate maximum discount
        max_discounted_price = current_price * (1 - max_discount)
        
        # Ensure minimum price doesn't go below the maximum discounted price
        min_price = max(min_price, max_discounted_price)
        
        # Calculate optimal price based on inventory level
        if inventory_ratio >= 1.5:
            # Excess inventory: apply discount
            excess_ratio = min(inventory_ratio - 1, 2)  # Cap at 2x excess
            discount_factor = excess_ratio / 4  # Convert to discount factor (max 50% discount)
            optimal_price = current_price * (1 - discount_factor)
            price_change_reason = "Excess inventory"
        elif inventory_ratio <= 0.5:
            # Low inventory: increase price
            shortage_ratio = 1 - inventory_ratio  # 0.5 -> 0.5, 0 -> 1
            increase_factor = shortage_ratio / 5  # Convert to increase factor (max 20% increase)
            optimal_price = current_price * (1 + increase_factor)
            price_change_reason = "Low inventory"
        else:
            # Normal inventory: adjust based on elasticity for profit maximization
            # For profit maximization with constant elasticity, optimal markup is |e|/(|e|-1)
            if abs(price_elasticity) > 1:
                optimal_markup = abs(price_elasticity) / (abs(price_elasticity) - 1)
                optimal_price = cost * optimal_markup
                price_change_reason = "Profit maximization"
            else:
                # If elasticity is too low, use default margin
                optimal_price = cost / (1 - self.default_margin)
                price_change_reason = "Default margin"
        
        # Consider competitor prices if provided
        if competitor_prices and len(competitor_prices) > 0:
            avg_competitor_price = sum(competitor_prices) / len(competitor_prices)
            min_competitor_price = min(competitor_prices)
            
            # Adjust price based on competitive position
            if optimal_price > avg_competitor_price * 1.2:
                # Our price is significantly higher than competitors
                competitive_price = avg_competitor_price * 1.1  # Price slightly above average
                optimal_price = min(optimal_price, competitive_price)
                price_change_reason += ", competitive adjustment"
            elif optimal_price < min_competitor_price * 0.9 and inventory_ratio < 1.2:
                # Our price is significantly lower than competitors and we don't have excess inventory
                competitive_price = min_competitor_price * 0.95  # Price slightly below minimum
                optimal_price = max(optimal_price, competitive_price)
                price_change_reason += ", competitive adjustment"
        
        # Ensure price is within bounds
        optimal_price = max(optimal_price, min_price)
        optimal_price = max(optimal_price, cost)  # Never price below cost
        
        # Calculate expected impact
        price_change_pct = (optimal_price - current_price) / current_price * 100
        
        # Estimate demand change using price elasticity
        demand_change_pct = price_change_pct * price_elasticity
        
        # Calculate new margin
        new_margin = (optimal_price - cost) / optimal_price
        
        return {
            'current_price': current_price,
            'optimal_price': round(optimal_price, 2),
            'price_change_pct': round(price_change_pct, 2),
            'price_change_reason': price_change_reason,
            'expected_demand_change_pct': round(demand_change_pct, 2),
            'new_margin': round(new_margin, 4),
            'min_price': round(min_price, 2),
            'inventory_ratio': round(inventory_ratio, 2)
        }
    
    def recommend_promotions(self,
                           product_id: int,
                           inventory_level: int,
                           target_inventory: int,
                           days_in_stock: int,
                           product_category: str,
                           product_seasonality: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Recommend promotions for a product.
        
        Args:
            product_id: ID of the product.
            inventory_level: Current inventory level.
            target_inventory: Target inventory level.
            days_in_stock: Number of days the product has been in stock.
            product_category: Category of the product.
            product_seasonality: Dictionary with seasonality information.
            
        Returns:
            List of promotion recommendations.
        """
        promotions = []
        
        # Calculate inventory ratio
        inventory_ratio = inventory_level / target_inventory if target_inventory > 0 else float('inf')
        
        # Check if product is overstocked
        if inventory_ratio >= 1.5:
            # Significant excess inventory
            if inventory_ratio >= 2.5:
                # Severe excess
                promotions.append({
                    'type': 'discount',
                    'discount_percentage': 40,
                    'reason': 'Severe excess inventory',
                    'priority': 'high'
                })
                
                promotions.append({
                    'type': 'bundle',
                    'discount_percentage': 25,
                    'bundle_with': 'complementary_products',
                    'reason': 'Severe excess inventory',
                    'priority': 'high'
                })
            elif inventory_ratio >= 2.0:
                # High excess
                promotions.append({
                    'type': 'discount',
                    'discount_percentage': 30,
                    'reason': 'High excess inventory',
                    'priority': 'medium'
                })
            else:
                # Moderate excess
                promotions.append({
                    'type': 'discount',
                    'discount_percentage': 20,
                    'reason': 'Moderate excess inventory',
                    'priority': 'medium'
                })
        
        # Check if product has been in stock for a long time
        if days_in_stock > 90:
            # Product has been in stock for more than 3 months
            promotions.append({
                'type': 'clearance',
                'discount_percentage': 50,
                'reason': 'Aging inventory',
                'priority': 'high'
            })
        elif days_in_stock > 60:
            # Product has been in stock for more than 2 months
            promotions.append({
                'type': 'discount',
                'discount_percentage': 25,
                'reason': 'Aging inventory',
                'priority': 'medium'
            })
        
        # Check seasonality if provided
        if product_seasonality:
            current_month = datetime.now().month
            peak_month = product_seasonality.get('peak_month')
            
            if peak_month and abs(current_month - peak_month) >= 5:
                # We're far from the peak season
                promotions.append({
                    'type': 'off_season_sale',
                    'discount_percentage': 35,
                    'reason': 'Off-season product',
                    'priority': 'medium'
                })
        
        # Category-specific promotions
        if product_category == 'Electronics':
            promotions.append({
                'type': 'bundle',
                'discount_percentage': 15,
                'bundle_with': 'accessories',
                'reason': 'Electronics bundle promotion',
                'priority': 'low'
            })
        elif product_category == 'Clothing':
            promotions.append({
                'type': 'buy_one_get_one',
                'discount_percentage': 50,
                'reason': 'Clothing BOGO promotion',
                'priority': 'low'
            })
        elif product_category == 'Groceries':
            promotions.append({
                'type': 'multi_buy',
                'discount_percentage': 20,
                'quantity': 3,
                'reason': 'Grocery multi-buy promotion',
                'priority': 'low'
            })
        
        # Sort promotions by priority
        priority_map = {'high': 3, 'medium': 2, 'low': 1}
        promotions.sort(key=lambda p: priority_map.get(p.get('priority', 'low'), 0), reverse=True)
        
        return promotions
    
    def optimize_category_pricing(self,
                                category: str,
                                products: List[Dict[str, Any]],
                                inventory_levels: Dict[int, int],
                                target_inventories: Dict[int, int],
                                sales_data: pd.DataFrame = None) -> Dict[int, Dict[str, Any]]:
        """
        Optimize pricing across a product category.
        
        Args:
            category: Product category.
            products: List of product dictionaries with 'product_id', 'cost', and 'current_price'.
            inventory_levels: Dictionary mapping product IDs to inventory levels.
            target_inventories: Dictionary mapping product IDs to target inventory levels.
            sales_data: Optional DataFrame with historical sales data.
            
        Returns:
            Dictionary mapping product IDs to pricing recommendations.
        """
        recommendations = {}
        
        # Estimate price elasticities if sales data is provided
        elasticities = {}
        if sales_data is not None and not sales_data.empty:
            for product in products:
                product_id = product.get('product_id')
                elasticities[product_id] = self.estimate_price_elasticity(product_id, sales_data)
        
        # Calculate average category price
        category_prices = [p.get('current_price', 0) for p in products]
        avg_category_price = sum(category_prices) / len(category_prices) if category_prices else 0
        
        # Optimize pricing for each product
        for product in products:
            product_id = product.get('product_id')
            cost = product.get('cost', 0)
            current_price = product.get('current_price', 0)
            
            if product_id is None or cost <= 0 or current_price <= 0:
                logger.warning(f"Invalid product data: {product}. Skipping.")
                continue
            
            inventory_level = inventory_levels.get(product_id, 0)
            target_inventory = target_inventories.get(product_id, 0)
            
            # Get price elasticity
            price_elasticity = elasticities.get(product_id, self.default_price_elasticity)
            
            # Calculate optimal price
            recommendation = self.calculate_optimal_price(
                product_id=product_id,
                cost=cost,
                current_price=current_price,
                inventory_level=inventory_level,
                target_inventory=target_inventory,
                price_elasticity=price_elasticity
            )
            
            # Add category context
            recommendation['category'] = category
            recommendation['category_avg_price'] = avg_category_price
            recommendation['price_relative_to_category'] = current_price / avg_category_price if avg_category_price > 0 else 1
            
            recommendations[product_id] = recommendation
        
        # Adjust recommendations for category coherence
        for product_id, recommendation in recommendations.items():
            optimal_price = recommendation.get('optimal_price', 0)
            current_price = recommendation.get('current_price', 0)
            
            # Check if price change is significant
            price_change_pct = abs((optimal_price - current_price) / current_price) if current_price > 0 else 0
            
            if price_change_pct < 0.05:
                # Price change is less than 5%, keep current price for consistency
                recommendations[product_id]['optimal_price'] = current_price
                recommendations[product_id]['price_change_pct'] = 0
                recommendations[product_id]['price_change_reason'] += ", minimal change"
        
        return recommendations
    
    def simulate_pricing_strategy(self,
                                product_id: int,
                                initial_price: float,
                                cost: float,
                                initial_inventory: int,
                                daily_demand_base: float,
                                price_elasticity: float,
                                simulation_days: int = 30,
                                pricing_strategy: str = 'dynamic') -> Dict[str, Any]:
        """
        Simulate a pricing strategy over time.
        
        Args:
            product_id: ID of the product.
            initial_price: Initial price.
            cost: Cost per unit.
            initial_inventory: Initial inventory level.
            daily_demand_base: Base daily demand at initial price.
            price_elasticity: Price elasticity of demand.
            simulation_days: Number of days to simulate.
            pricing_strategy: Pricing strategy ('fixed', 'dynamic', 'clearance').
            
        Returns:
            Dictionary with simulation results.
        """
        # Initialize simulation
        inventory = initial_inventory
        price = initial_price
        prices = []
        inventory_levels = []
        daily_demand = []
        daily_revenue = []
        daily_profit = []
        stockouts = 0
        
        # Run simulation
        for day in range(simulation_days):
            # Record price and inventory at start of day
            prices.append(price)
            inventory_levels.append(inventory)
            
            # Calculate demand based on price elasticity
            price_ratio = price / initial_price
            demand = daily_demand_base * (price_ratio ** price_elasticity)
            
            # Add some randomness to demand
            demand = max(0, demand * (1 + np.random.normal(0, 0.2)))
            
            # Round demand to integer
            demand = round(demand)
            
            # Record demand
            daily_demand.append(demand)
            
            # Process demand
            if demand <= inventory:
                sales = demand
                inventory -= sales
            else:
                # Stockout
                sales = inventory
                inventory = 0
                stockouts += 1
            
            # Calculate revenue and profit
            revenue = sales * price
            profit = sales * (price - cost)
            
            daily_revenue.append(revenue)
            daily_profit.append(profit)
            
            # Update price based on strategy
            if pricing_strategy == 'fixed':
                # Keep price fixed
                pass
            elif pricing_strategy == 'dynamic':
                # Adjust price based on inventory
                inventory_ratio = inventory / initial_inventory if initial_inventory > 0 else 0
                
                if inventory_ratio <= 0.2:
                    # Low inventory: increase price
                    price = min(price * 1.05, initial_price * 1.2)
                elif inventory_ratio >= 0.8:
                    # High inventory: decrease price
                    price = max(price * 0.95, cost * 1.1)
            elif pricing_strategy == 'clearance':
                # Gradually decrease price to clear inventory
                days_remaining = simulation_days - day
                if days_remaining > 0:
                    target_daily_sales = inventory / days_remaining
                    
                    if demand < target_daily_sales * 0.8:
                        # Demand too low: decrease price
                        price = max(price * 0.9, cost * 1.05)
        
        # Calculate metrics
        total_revenue = sum(daily_revenue)
        total_profit = sum(daily_profit)
        total_sales = sum(daily_demand) - sum([daily_demand[i] - daily_revenue[i] / prices[i] for i in range(simulation_days)])
        avg_price = sum(prices) / len(prices)
        final_inventory = inventory
        stockout_rate = stockouts / simulation_days
        
        return {
            'total_revenue': total_revenue,
            'total_profit': total_profit,
            'total_sales': total_sales,
            'avg_price': avg_price,
            'final_inventory': final_inventory,
            'stockouts': stockouts,
            'stockout_rate': stockout_rate,
            'prices': prices,
            'inventory_levels': inventory_levels,
            'daily_demand': daily_demand,
            'daily_revenue': daily_revenue,
            'daily_profit': daily_profit
        }
