import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error
import joblib
import os
from pathlib import Path

logger = logging.getLogger(__name__)

class ForecastingEngine:
    """
    Engine for forecasting product demand based on historical sales data.
    
    Supports multiple forecasting models and automatically selects the best one for each product.
    """
    
    def __init__(self, models_dir: str = "data/models"):
        """
        Initialize the forecasting engine.
        
        Args:
            models_dir: Directory to save trained models.
        """
        self.models_dir = models_dir
        self.models = {}  # product_id -> {model, scaler, features, performance}
        self.default_features = ['day_of_week', 'day_of_month', 'month', 'is_weekend', 'is_holiday']
        self.seasonal_features = ['season', 'quarter']
        self.trend_features = ['days_since_start']
        self.price_features = ['price', 'discount_percentage']
        self.inventory_features = ['inventory_level', 'days_since_restock']
        
        # Create models directory if it doesn't exist
        os.makedirs(models_dir, exist_ok=True)
    
    def _prepare_features(self, 
                         sales_data: pd.DataFrame, 
                         include_price: bool = True,
                         include_inventory: bool = True,
                         include_seasonal: bool = True,
                         include_trend: bool = True) -> pd.DataFrame:
        """
        Prepare features for forecasting models.
        
        Args:
            sales_data: DataFrame with sales data.
            include_price: Whether to include price-related features.
            include_inventory: Whether to include inventory-related features.
            include_seasonal: Whether to include seasonal features.
            include_trend: Whether to include trend features.
            
        Returns:
            DataFrame with prepared features.
        """
        # Ensure date column is datetime
        if 'date' in sales_data.columns:
            sales_data['date'] = pd.to_datetime(sales_data['date'])
        
        # Create basic time features
        features = sales_data.copy()
        if 'date' in features.columns:
            features['day_of_week'] = features['date'].dt.dayofweek
            features['day_of_month'] = features['date'].dt.day
            features['month'] = features['date'].dt.month
            features['is_weekend'] = (features['day_of_week'] >= 5).astype(int)
            
            # Simple holiday detection (major US holidays)
            # In a real system, this would be more sophisticated and use a holiday calendar
            features['is_holiday'] = 0
            for date in features['date']:
                month, day = date.month, date.day
                # New Year's, Memorial Day, Independence Day, Labor Day, Thanksgiving, Christmas
                if (month == 1 and day == 1) or \
                   (month == 5 and day >= 25 and date.dayofweek == 0) or \
                   (month == 7 and day == 4) or \
                   (month == 9 and day <= 7 and date.dayofweek == 0) or \
                   (month == 11 and date.dayofweek == 3 and day >= 22 and day <= 28) or \
                   (month == 12 and day == 25):
                    features.loc[features['date'] == date, 'is_holiday'] = 1
        
        # Add seasonal features
        if include_seasonal and 'date' in features.columns:
            # Season (1=Spring, 2=Summer, 3=Fall, 4=Winter)
            features['season'] = features['month'].apply(lambda m: 1 if m in [3, 4, 5] else 
                                                                 2 if m in [6, 7, 8] else 
                                                                 3 if m in [9, 10, 11] else 4)
            # Quarter
            features['quarter'] = ((features['month'] - 1) // 3) + 1
        
        # Add trend features
        if include_trend and 'date' in features.columns:
            min_date = features['date'].min()
            features['days_since_start'] = (features['date'] - min_date).dt.days
        
        # Add price features
        if include_price:
            if 'price' not in features.columns:
                logger.warning("Price column not found in sales data. Price features will not be included.")
            else:
                # Calculate discount percentage if original_price is available
                if 'original_price' in features.columns:
                    features['discount_percentage'] = ((features['original_price'] - features['price']) / 
                                                     features['original_price'] * 100)
                else:
                    # Use average price as a proxy for original price
                    avg_price = features['price'].mean()
                    features['discount_percentage'] = ((avg_price - features['price']) / avg_price * 100)
                    features['discount_percentage'] = features['discount_percentage'].clip(lower=0)
        
        # Add inventory features
        if include_inventory:
            if 'inventory_level' not in features.columns:
                logger.warning("Inventory level column not found in sales data. Inventory features will not be included.")
            elif 'last_restock_date' in features.columns:
                features['days_since_restock'] = (features['date'] - pd.to_datetime(features['last_restock_date'])).dt.days
        
        # Drop non-feature columns
        columns_to_drop = ['date', 'sale_id', 'store_id', 'customer_id', 'last_restock_date', 'original_price']
        for col in columns_to_drop:
            if col in features.columns:
                features = features.drop(col, axis=1)
        
        return features
    
    def train_model(self, 
                   product_id: int, 
                   sales_data: pd.DataFrame,
                   model_type: str = 'random_forest') -> Dict[str, Any]:
        """
        Train a forecasting model for a specific product.
        
        Args:
            product_id: ID of the product.
            sales_data: DataFrame with historical sales data.
            model_type: Type of model to train ('random_forest' or 'linear_regression').
            
        Returns:
            Dictionary with model information.
        """
        if sales_data.empty:
            logger.warning(f"No sales data provided for product {product_id}. Cannot train model.")
            return None
        
        # Prepare features
        features_df = self._prepare_features(sales_data)
        
        # Separate features and target
        if 'quantity' not in features_df.columns:
            logger.warning(f"Quantity column not found in sales data for product {product_id}. Cannot train model.")
            return None
        
        X = features_df.drop('quantity', axis=1)
        y = features_df['quantity']
        
        # Scale features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Train model
        if model_type == 'random_forest':
            model = RandomForestRegressor(n_estimators=100, random_state=42)
        elif model_type == 'linear_regression':
            model = LinearRegression()
        else:
            logger.warning(f"Unknown model type: {model_type}. Using random forest instead.")
            model = RandomForestRegressor(n_estimators=100, random_state=42)
        
        model.fit(X_scaled, y)
        
        # Evaluate model
        y_pred = model.predict(X_scaled)
        mae = mean_absolute_error(y, y_pred)
        rmse = np.sqrt(mean_squared_error(y, y_pred))
        
        # Save model information
        model_info = {
            'model': model,
            'scaler': scaler,
            'features': list(X.columns),
            'performance': {
                'mae': mae,
                'rmse': rmse,
                'training_samples': len(y)
            },
            'last_trained': datetime.now().isoformat()
        }
        
        self.models[product_id] = model_info
        
        # Save model to disk
        model_path = os.path.join(self.models_dir, f"product_{product_id}_model.joblib")
        scaler_path = os.path.join(self.models_dir, f"product_{product_id}_scaler.joblib")
        
        joblib.dump(model, model_path)
        joblib.dump(scaler, scaler_path)
        
        logger.info(f"Trained {model_type} model for product {product_id}. MAE: {mae:.2f}, RMSE: {rmse:.2f}")
        
        return model_info
    
    def load_model(self, product_id: int) -> bool:
        """
        Load a trained model from disk.
        
        Args:
            product_id: ID of the product.
            
        Returns:
            True if model was loaded successfully, False otherwise.
        """
        model_path = os.path.join(self.models_dir, f"product_{product_id}_model.joblib")
        scaler_path = os.path.join(self.models_dir, f"product_{product_id}_scaler.joblib")
        
        if not os.path.exists(model_path) or not os.path.exists(scaler_path):
            logger.warning(f"Model files for product {product_id} not found.")
            return False
        
        try:
            model = joblib.load(model_path)
            scaler = joblib.load(scaler_path)
            
            # Load model information (features and performance metrics would be stored separately in a real system)
            self.models[product_id] = {
                'model': model,
                'scaler': scaler,
                'features': self.default_features,  # Simplified for this example
                'performance': {
                    'mae': 0,
                    'rmse': 0,
                    'training_samples': 0
                },
                'last_trained': None
            }
            
            logger.info(f"Loaded model for product {product_id} from disk.")
            return True
            
        except Exception as e:
            logger.error(f"Error loading model for product {product_id}: {e}")
            return False
    
    def predict_demand(self, 
                      product_id: int, 
                      future_dates: List[datetime],
                      price: Optional[float] = None,
                      inventory_level: Optional[int] = None,
                      last_restock_date: Optional[datetime] = None) -> List[float]:
        """
        Predict demand for a product on future dates.
        
        Args:
            product_id: ID of the product.
            future_dates: List of future dates to predict demand for.
            price: Optional price to use for prediction.
            inventory_level: Optional inventory level to use for prediction.
            last_restock_date: Optional last restock date to use for prediction.
            
        Returns:
            List of predicted demand values for each date.
        """
        # Check if model exists
        if product_id not in self.models:
            # Try to load model from disk
            if not self.load_model(product_id):
                logger.warning(f"No model found for product {product_id}. Cannot predict demand.")
                return [0] * len(future_dates)  # Return zeros as fallback
        
        model_info = self.models[product_id]
        model = model_info['model']
        scaler = model_info['scaler']
        features = model_info['features']
        
        # Prepare feature data for future dates
        future_data = []
        for date in future_dates:
            data_point = {
                'date': date,
                'day_of_week': date.weekday(),
                'day_of_month': date.day,
                'month': date.month,
                'is_weekend': 1 if date.weekday() >= 5 else 0
            }
            
            # Add holiday feature
            month, day = date.month, date.day
            is_holiday = 0
            if (month == 1 and day == 1) or \
               (month == 5 and day >= 25 and date.weekday() == 0) or \
               (month == 7 and day == 4) or \
               (month == 9 and day <= 7 and date.weekday() == 0) or \
               (month == 11 and date.weekday() == 3 and day >= 22 and day <= 28) or \
               (month == 12 and day == 25):
                is_holiday = 1
            data_point['is_holiday'] = is_holiday
            
            # Add seasonal features if needed
            if 'season' in features:
                data_point['season'] = 1 if month in [3, 4, 5] else \
                                      2 if month in [6, 7, 8] else \
                                      3 if month in [9, 10, 11] else 4
            if 'quarter' in features:
                data_point['quarter'] = ((month - 1) // 3) + 1
            
            # Add trend features if needed
            if 'days_since_start' in features:
                # Use a reference date (this would be stored with the model in a real system)
                reference_date = datetime(2023, 1, 1)
                data_point['days_since_start'] = (date - reference_date).days
            
            # Add price features if needed
            if 'price' in features and price is not None:
                data_point['price'] = price
                if 'discount_percentage' in features:
                    # Use a reference price (this would be stored with the model in a real system)
                    reference_price = 100.0
                    data_point['discount_percentage'] = max(0, (reference_price - price) / reference_price * 100)
            
            # Add inventory features if needed
            if 'inventory_level' in features and inventory_level is not None:
                data_point['inventory_level'] = inventory_level
                if 'days_since_restock' in features and last_restock_date is not None:
                    data_point['days_since_restock'] = (date - last_restock_date).days
            
            future_data.append(data_point)
        
        # Convert to DataFrame
        future_df = pd.DataFrame(future_data)
        
        # Select and order features to match the model
        X = pd.DataFrame()
        for feature in features:
            if feature in future_df.columns:
                X[feature] = future_df[feature]
            else:
                logger.warning(f"Feature {feature} not found in future data. Using zeros.")
                X[feature] = 0
        
        # Scale features
        X_scaled = scaler.transform(X)
        
        # Make predictions
        predictions = model.predict(X_scaled)
        
        # Ensure predictions are non-negative
        predictions = np.maximum(predictions, 0)
        
        return predictions.tolist()
    
    def train_multiple_models(self, 
                             product_ids: List[int], 
                             sales_data: pd.DataFrame) -> Dict[int, Dict[str, Any]]:
        """
        Train forecasting models for multiple products.
        
        Args:
            product_ids: List of product IDs.
            sales_data: DataFrame with historical sales data for all products.
            
        Returns:
            Dictionary mapping product IDs to model information.
        """
        results = {}
        
        for product_id in product_ids:
            # Filter sales data for this product
            product_sales = sales_data[sales_data['product_id'] == product_id].copy()
            
            if len(product_sales) < 10:
                logger.warning(f"Insufficient sales data for product {product_id}. Skipping model training.")
                continue
            
            # Train both model types
            rf_model = self.train_model(product_id, product_sales, model_type='random_forest')
            lr_model = self.train_model(product_id, product_sales, model_type='linear_regression')
            
            # Select the better model based on MAE
            if rf_model and lr_model:
                if rf_model['performance']['mae'] <= lr_model['performance']['mae']:
                    self.models[product_id] = rf_model
                    results[product_id] = {'model_type': 'random_forest', 'performance': rf_model['performance']}
                else:
                    self.models[product_id] = lr_model
                    results[product_id] = {'model_type': 'linear_regression', 'performance': lr_model['performance']}
            elif rf_model:
                self.models[product_id] = rf_model
                results[product_id] = {'model_type': 'random_forest', 'performance': rf_model['performance']}
            elif lr_model:
                self.models[product_id] = lr_model
                results[product_id] = {'model_type': 'linear_regression', 'performance': lr_model['performance']}
        
        return results
    
    def evaluate_forecast_accuracy(self, 
                                 product_id: int, 
                                 test_data: pd.DataFrame) -> Dict[str, float]:
        """
        Evaluate the accuracy of forecasts for a product using test data.
        
        Args:
            product_id: ID of the product.
            test_data: DataFrame with test data.
            
        Returns:
            Dictionary with accuracy metrics.
        """
        if product_id not in self.models:
            logger.warning(f"No model found for product {product_id}. Cannot evaluate accuracy.")
            return {'mae': float('inf'), 'rmse': float('inf'), 'mape': float('inf')}
        
        # Prepare features
        features_df = self._prepare_features(test_data)
        
        # Separate features and target
        if 'quantity' not in features_df.columns:
            logger.warning(f"Quantity column not found in test data for product {product_id}. Cannot evaluate accuracy.")
            return {'mae': float('inf'), 'rmse': float('inf'), 'mape': float('inf')}
        
        X = features_df.drop('quantity', axis=1)
        y_true = features_df['quantity']
        
        # Ensure we have all required features
        model_features = self.models[product_id]['features']
        for feature in model_features:
            if feature not in X.columns:
                logger.warning(f"Feature {feature} not found in test data. Using zeros.")
                X[feature] = 0
        
        # Select and order features to match the model
        X = X[model_features]
        
        # Scale features
        scaler = self.models[product_id]['scaler']
        X_scaled = scaler.transform(X)
        
        # Make predictions
        model = self.models[product_id]['model']
        y_pred = model.predict(X_scaled)
        
        # Calculate metrics
        mae = mean_absolute_error(y_true, y_pred)
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        
        # Calculate MAPE (Mean Absolute Percentage Error)
        # Avoid division by zero
        mask = y_true != 0
        mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100 if any(mask) else float('inf')
        
        return {'mae': mae, 'rmse': rmse, 'mape': mape}
    
    def get_seasonal_patterns(self, product_id: int, sales_data: pd.DataFrame) -> Dict[str, Any]:
        """
        Analyze seasonal patterns in sales data for a product.
        
        Args:
            product_id: ID of the product.
            sales_data: DataFrame with historical sales data.
            
        Returns:
            Dictionary with seasonal patterns.
        """
        if sales_data.empty:
            logger.warning(f"No sales data provided for product {product_id}. Cannot analyze seasonal patterns.")
            return {}
        
        # Ensure date column is datetime
        if 'date' in sales_data.columns:
            sales_data['date'] = pd.to_datetime(sales_data['date'])
        else:
            logger.warning(f"Date column not found in sales data for product {product_id}. Cannot analyze seasonal patterns.")
            return {}
        
        # Filter for this product
        product_sales = sales_data[sales_data['product_id'] == product_id].copy()
        
        if product_sales.empty:
            logger.warning(f"No sales data found for product {product_id}. Cannot analyze seasonal patterns.")
            return {}
        
        # Extract time components
        product_sales['day_of_week'] = product_sales['date'].dt.dayofweek
        product_sales['month'] = product_sales['date'].dt.month
        product_sales['quarter'] = ((product_sales['month'] - 1) // 3) + 1
        product_sales['season'] = product_sales['month'].apply(lambda m: 1 if m in [3, 4, 5] else 
                                                                      2 if m in [6, 7, 8] else 
                                                                      3 if m in [9, 10, 11] else 4)
        
        # Aggregate by different time periods
        day_of_week_pattern = product_sales.groupby('day_of_week')['quantity'].mean().to_dict()
        month_pattern = product_sales.groupby('month')['quantity'].mean().to_dict()
        quarter_pattern = product_sales.groupby('quarter')['quantity'].mean().to_dict()
        season_pattern = product_sales.groupby('season')['quantity'].mean().to_dict()
        
        # Find peak periods
        peak_day = max(day_of_week_pattern.items(), key=lambda x: x[1])[0]
        peak_month = max(month_pattern.items(), key=lambda x: x[1])[0]
        peak_quarter = max(quarter_pattern.items(), key=lambda x: x[1])[0]
        peak_season = max(season_pattern.items(), key=lambda x: x[1])[0]
        
        # Map day of week to name
        day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        peak_day_name = day_names[peak_day]
        
        # Map season to name
        season_names = ['Spring', 'Summer', 'Fall', 'Winter']
        peak_season_name = season_names[peak_season - 1]
        
        return {
            'day_of_week_pattern': day_of_week_pattern,
            'month_pattern': month_pattern,
            'quarter_pattern': quarter_pattern,
            'season_pattern': season_pattern,
            'peak_day': peak_day_name,
            'peak_month': peak_month,
            'peak_quarter': peak_quarter,
            'peak_season': peak_season_name
        }
    
    def forecast_with_confidence(self, 
                               product_id: int, 
                               future_dates: List[datetime],
                               confidence_level: float = 0.95) -> Dict[str, List[float]]:
        """
        Generate forecasts with confidence intervals.
        
        Args:
            product_id: ID of the product.
            future_dates: List of future dates to predict demand for.
            confidence_level: Confidence level for intervals (0-1).
            
        Returns:
            Dictionary with point forecasts and confidence intervals.
        """
        # Check if model exists
        if product_id not in self.models:
            # Try to load model from disk
            if not self.load_model(product_id):
                logger.warning(f"No model found for product {product_id}. Cannot predict demand.")
                return {
                    'forecast': [0] * len(future_dates),
                    'lower_bound': [0] * len(future_dates),
                    'upper_bound': [0] * len(future_dates)
                }
        
        # Get point forecasts
        point_forecasts = self.predict_demand(product_id, future_dates)
        
        # For Random Forest, we can use the prediction intervals
        model_info = self.models[product_id]
        model = model_info['model']
        
        # Simple approach: use historical error to estimate confidence intervals
        # In a real system, this would be more sophisticated
        if 'performance' in model_info and 'rmse' in model_info['performance']:
            rmse = model_info['performance']['rmse']
            # Z-score for the confidence level (e.g., 1.96 for 95% confidence)
            z = 1.96 if confidence_level == 0.95 else 1.645 if confidence_level == 0.90 else 2.576 if confidence_level == 0.99 else 1.96
            
            # Calculate confidence intervals
            margin = z * rmse
            lower_bound = [max(0, forecast - margin) for forecast in point_forecasts]
            upper_bound = [forecast + margin for forecast in point_forecasts]
        else:
            # Fallback: use a simple percentage-based approach
            lower_bound = [max(0, forecast * 0.8) for forecast in point_forecasts]
            upper_bound = [forecast * 1.2 for forecast in point_forecasts]
        
        return {
            'forecast': point_forecasts,
            'lower_bound': lower_bound,
            'upper_bound': upper_bound
        }
