import asyncio
import logging
from typing import Dict, List, Any, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
import uvicorn
import json
import os
from datetime import datetime
from pathlib import Path

# Add the project root directory to the Python path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.utils.message_bus import MessageBus

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(title="Retail Inventory Optimization Dashboard")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables
message_bus: Optional[MessageBus] = None
connected_websockets: List[WebSocket] = []
system_state: Dict[str, Any] = {
    "agents": {},
    "metrics": {
        "stockout_rate": 0,
        "inventory_turnover": 0,
        "order_fill_rate": 0,
        "average_lead_time": 0
    },
    "alerts": [],
    "last_updated": datetime.now().isoformat()
}

# HTML for simple dashboard
HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Retail Inventory Optimization Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            flex: 1;
            min-width: 300px;
        }
        h1, h2, h3 {
            color: #333;
        }
        .metrics {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .metric {
            background-color: #e9f5ff;
            border-radius: 4px;
            padding: 10px;
            flex: 1;
            min-width: 150px;
            text-align: center;
        }
        .metric h3 {
            margin-top: 0;
            font-size: 16px;
        }
        .metric p {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0 0 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .alert {
            background-color: #ffebee;
            color: #c62828;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .messages {
            height: 300px;
            overflow-y: auto;
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .message {
            margin-bottom: 8px;
            padding: 8px;
            background-color: white;
            border-radius: 4px;
            border-left: 3px solid #2196F3;
        }
        .message-time {
            font-size: 12px;
            color: #666;
        }
        .message-content {
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <h1>Retail Inventory Optimization Dashboard</h1>
    
    <div class="container">
        <div class="card">
            <h2>System Metrics</h2>
            <div class="metrics">
                <div class="metric">
                    <h3>Stockout Rate</h3>
                    <p id="stockout-rate">0%</p>
                </div>
                <div class="metric">
                    <h3>Inventory Turnover</h3>
                    <p id="inventory-turnover">0</p>
                </div>
                <div class="metric">
                    <h3>Order Fill Rate</h3>
                    <p id="order-fill-rate">0%</p>
                </div>
                <div class="metric">
                    <h3>Avg Lead Time</h3>
                    <p id="avg-lead-time">0 days</p>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>Alerts</h2>
            <div id="alerts">
                <p>No alerts</p>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="card">
            <h2>Agents</h2>
            <table id="agents-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Last Seen</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Agent rows will be added here -->
                </tbody>
            </table>
        </div>
        
        <div class="card">
            <h2>Recent Messages</h2>
            <div id="messages" class="messages">
                <!-- Messages will be added here -->
            </div>
        </div>
    </div>
    
    <script>
        const ws = new WebSocket(`ws://${window.location.host}/ws`);
        
        ws.onmessage = function(event) {
            const data = JSON.parse(event.data);
            
            // Update metrics
            if (data.metrics) {
                document.getElementById('stockout-rate').textContent = (data.metrics.stockout_rate * 100).toFixed(1) + '%';
                document.getElementById('inventory-turnover').textContent = data.metrics.inventory_turnover.toFixed(2);
                document.getElementById('order-fill-rate').textContent = (data.metrics.order_fill_rate * 100).toFixed(1) + '%';
                document.getElementById('avg-lead-time').textContent = data.metrics.average_lead_time.toFixed(1) + ' days';
            }
            
            // Update alerts
            if (data.alerts) {
                const alertsContainer = document.getElementById('alerts');
                alertsContainer.innerHTML = '';
                
                if (data.alerts.length === 0) {
                    alertsContainer.innerHTML = '<p>No alerts</p>';
                } else {
                    data.alerts.forEach(alert => {
                        const alertDiv = document.createElement('div');
                        alertDiv.className = 'alert';
                        alertDiv.textContent = `${alert.alert_type}: ${alert.details}`;
                        alertsContainer.appendChild(alertDiv);
                    });
                }
            }
            
            // Update agents
            if (data.agents) {
                const tbody = document.querySelector('#agents-table tbody');
                tbody.innerHTML = '';
                
                Object.entries(data.agents).forEach(([agentId, agentInfo]) => {
                    const row = document.createElement('tr');
                    
                    const idCell = document.createElement('td');
                    idCell.textContent = agentId;
                    row.appendChild(idCell);
                    
                    const typeCell = document.createElement('td');
                    typeCell.textContent = agentInfo.agent_type;
                    row.appendChild(typeCell);
                    
                    const statusCell = document.createElement('td');
                    statusCell.textContent = agentInfo.status;
                    row.appendChild(statusCell);
                    
                    const lastSeenCell = document.createElement('td');
                    const lastSeen = new Date(agentInfo.last_seen);
                    lastSeenCell.textContent = lastSeen.toLocaleTimeString();
                    row.appendChild(lastSeenCell);
                    
                    tbody.appendChild(row);
                });
            }
            
            // Update messages
            if (data.message) {
                const messagesContainer = document.getElementById('messages');
                
                const messageDiv = document.createElement('div');
                messageDiv.className = 'message';
                
                const timeDiv = document.createElement('div');
                timeDiv.className = 'message-time';
                const messageTime = new Date(data.message.timestamp);
                timeDiv.textContent = messageTime.toLocaleTimeString();
                messageDiv.appendChild(timeDiv);
                
                const contentDiv = document.createElement('div');
                contentDiv.className = 'message-content';
                contentDiv.textContent = `${data.message.sender_type} → ${data.message.message_type}`;
                messageDiv.appendChild(contentDiv);
                
                messagesContainer.appendChild(messageDiv);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
                
                // Limit to 100 messages
                while (messagesContainer.children.length > 100) {
                    messagesContainer.removeChild(messagesContainer.firstChild);
                }
            }
        };
        
        ws.onclose = function(event) {
            console.log('Connection closed');
            // Try to reconnect after 5 seconds
            setTimeout(() => {
                window.location.reload();
            }, 5000);
        };
        
        ws.onerror = function(error) {
            console.error('WebSocket error:', error);
        };
    </script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def get_dashboard():
    """Return the dashboard HTML."""
    return HTML

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time updates."""
    await websocket.accept()
    connected_websockets.append(websocket)
    
    try:
        # Send initial state
        await websocket.send_text(json.dumps(system_state))
        
        # Keep connection open
        while True:
            # Wait for client messages (not used currently)
            data = await websocket.receive_text()
            # Just echo back for now
            await websocket.send_text(f"Message received: {data}")
    except WebSocketDisconnect:
        connected_websockets.remove(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}", exc_info=True)
        if websocket in connected_websockets:
            connected_websockets.remove(websocket)

async def broadcast_message(message: Dict[str, Any]):
    """Broadcast a message to all connected WebSocket clients."""
    if not connected_websockets:
        return
    
    for websocket in connected_websockets:
        try:
            await websocket.send_text(json.dumps(message))
        except Exception as e:
            logger.error(f"Error broadcasting message: {e}")
            # Remove disconnected websockets
            if websocket in connected_websockets:
                connected_websockets.remove(websocket)

async def message_handler(message: Dict[str, Any]):
    """Handle messages from the message bus."""
    # Update system state
    if "sender_id" in message and "sender_type" in message:
        system_state["agents"][message["sender_id"]] = {
            "agent_type": message["sender_type"],
            "status": "active",
            "last_seen": datetime.now().isoformat()
        }
    
    # Broadcast message to all connected clients
    await broadcast_message({
        "message": message,
        "agents": system_state["agents"],
        "metrics": system_state["metrics"],
        "alerts": system_state["alerts"]
    })

async def update_system_state():
    """Periodically update system state."""
    while True:
        try:
            # Update last_updated timestamp
            system_state["last_updated"] = datetime.now().isoformat()
            
            # Check for inactive agents
            current_time = datetime.now()
            for agent_id, agent_info in list(system_state["agents"].items()):
                last_seen = datetime.fromisoformat(agent_info["last_seen"])
                if (current_time - last_seen).total_seconds() > 60:  # 1 minute
                    agent_info["status"] = "inactive"
            
            # Broadcast updated state
            await broadcast_message({
                "agents": system_state["agents"],
                "metrics": system_state["metrics"],
                "alerts": system_state["alerts"]
            })
            
            # Wait for next update
            await asyncio.sleep(5)  # Update every 5 seconds
        except Exception as e:
            logger.error(f"Error updating system state: {e}", exc_info=True)
            await asyncio.sleep(5)  # Wait before retrying

import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime

# Dashboard theme configuration
st.set_page_config(
    page_title="Retail Inventory Dashboard",
    page_icon="🛒",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for styling
st.markdown("""
<style>
    .main {
        background-color: #f8f9fa;
    }
    .stButton>button {
        background-color: #4CAF50;
        color: white;
    }
    .css-1d391kg {
        padding-top: 1.5rem;
    }
</style>
""", unsafe_allow_html=True)

def setup_message_bus(bus: MessageBus):
    """Set up the message bus for the dashboard."""
    global message_bus
    message_bus = bus
    
    # Subscribe to all messages
    message_bus.subscribe("dashboard", message_handler)

# Dashboard layout
def render_dashboard():
    """Render the Streamlit dashboard UI."""
    st.title("🛒 Retail Inventory Optimization Dashboard")
    
    # Create tabs
    tab1, tab2, tab3 = st.tabs(["Overview", "Inventory", "Performance"])
    
    with tab1:
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Inventory Turnover", "5.2", "+0.3 from last week")
        with col2:
            st.metric("Stockout Rate", "3.5%", "-1.2% from last week")
        with col3:
            st.metric("Order Fill Rate", "98.7%", "+0.5% from last week")
        
        st.subheader("Sales Trend")
        sales_data = pd.DataFrame({
            'Date': pd.date_range('2023-01-01', periods=30),
            'Sales': [100, 120, 110, 130, 125, 140, 150, 145, 160, 170, 
                     165, 180, 175, 190, 185, 200, 195, 210, 205, 220, 
                     215, 230, 225, 240, 235, 250, 245, 260, 255, 270]
        })
        fig = px.line(sales_data, x='Date', y='Sales', title='30-Day Sales Trend')
        st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.subheader("Inventory Levels")
        inventory_data = pd.DataFrame({
            'Product': ['A', 'B', 'C', 'D', 'E'],
            'Current': [120, 85, 150, 90, 110],
            'Optimal': [100, 100, 100, 100, 100]
        })
        fig = px.bar(inventory_data, x='Product', y=['Current', 'Optimal'], 
                    barmode='group', title='Current vs Optimal Inventory')
        st.plotly_chart(fig, use_container_width=True)
    
    with tab3:
        st.subheader("Agent Performance")
        agent_data = pd.DataFrame({
            'Agent': ['Procurement', 'Sales', 'Logistics', 'Pricing'],
            'Score': [92, 88, 95, 85]
        })
        fig = px.bar(agent_data, x='Agent', y='Score', color='Score',
                    title='Agent Performance Scores')
        st.plotly_chart(fig, use_container_width=True)
        
        st.subheader("System Status")
        status_data = pd.DataFrame({
            'Metric': ['CPU Usage', 'Memory Usage', 'Network Latency'],
            'Value': [45, 60, 12],
            'Status': ['Normal', 'Warning', 'Normal']
        })
        st.dataframe(status_data.style.applymap(
            lambda x: 'background-color: #ffcccc' if x == 'Warning' else '', 
            subset=['Status']
        ), use_container_width=True)

    # Real-time updates section
    st.sidebar.title("Real-time Updates")
    with st.sidebar:
        st.write("Last update:", datetime.now().strftime("%H:%M:%S"))
        if st.button("Refresh Data"):
            st.experimental_rerun()

def start_dashboard(host: str = "0.0.0.0", port: int = 8000):
    """Start the dashboard server."""
    # Create a new event loop for the dashboard
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    # Start the system state update task
    loop.create_task(update_system_state())
    
    # Start the server
    config = uvicorn.Config(app, host=host, port=port, loop=loop)
    server = uvicorn.Server(config)
    loop.run_until_complete(server.serve())

if __name__ == "__main__":
    # This is for running the dashboard standalone
    # In the main application, use setup_message_bus() and start_dashboard()
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
