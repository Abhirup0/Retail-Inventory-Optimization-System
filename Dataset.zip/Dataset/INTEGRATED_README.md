# Retail Inventory Optimization System with Real Data Integration

This system integrates real retail datasets to provide intelligent inventory optimization using a multi-agent architecture.

## Overview

This enhanced version of the retail inventory optimization system uses real datasets for:
1. Demand forecasting
2. Inventory optimization
3. Price optimization

The system processes the datasets, trains machine learning models on the data, and uses these models to drive intelligent decision-making in the multi-agent simulation.

## Datasets

The system uses three datasets from the retail inventory optimization use case:

1. **Demand Forecasting Dataset**: Contains historical sales data with features like date, product ID, store ID, sales quantity, price, and promotions.
2. **Inventory Monitoring Dataset**: Contains inventory data with features like product ID, store ID, stock levels, reorder points, and supplier lead times.
3. **Pricing Optimization Dataset**: Contains pricing data with features like product ID, store ID, price, and sales.

## Components

The system consists of several key components:

1. **Data Loader**: Processes and integrates the three datasets.
2. **Model Training**: Trains forecasting, inventory optimization, and pricing models on the real data.
3. **Simulation Environment**: Runs a multi-agent simulation using the trained models and real data.
4. **Evaluation Framework**: Analyzes the performance of the system and generates reports.

## Getting Started

### Prerequisites

- Python 3.8 or higher
- Ollama (for LLM integration)
- The three datasets in the specified location

### Installation

1. Create a virtual environment:
   ```
   python -m venv inventory_env
   source inventory_env/bin/activate  # On Windows: inventory_env\\Scripts\\activate
   ```

2. Install dependencies:
   ```
   pip install -r system_requirements.txt
   ```

3. Install Ollama and download the required model:
   ```
   # Follow instructions at https://ollama.ai/
   ollama pull mistral
   ```

### Running the System

#### Option 1: Complete Workflow

Run the complete workflow (data loading, model training, simulation, and evaluation):

```
python run_complete_workflow.py --data "C:\Users\abhir\Downloads\Dataset\[use case 1] Inventory Optimization for Retail" --duration 120
```

This will:
1. Load and process the datasets
2. Train models on the data
3. Run a simulation using the trained models
4. Evaluate the results
5. Generate a comprehensive report

#### Option 2: Step-by-Step

You can also run each step separately:

1. **Data Loading and Processing**:
   ```
   python -c "from src.utils.data_loader import DataLoader; DataLoader().load_datasets(); DataLoader().save_processed_data()"
   ```

2. **Model Training**:
   ```
   python train_models.py --data "C:\Users\abhir\Downloads\Dataset\[use case 1] Inventory Optimization for Retail"
   ```

3. **Simulation with Real Data**:
   ```
   python run_with_real_data.py --data "C:\Users\abhir\Downloads\Dataset\[use case 1] Inventory Optimization for Retail" --models "data/models"
   ```

4. **Evaluation**:
   ```
   python evaluate_simulation.py --data "data/simulation"
   ```

## Understanding the Results

After running the system, you'll find the following results:

1. **Processed Data**: JSON file containing the processed datasets.
2. **Trained Models**: Pickle files containing the trained forecasting, inventory, and pricing models.
3. **Simulation Results**: CSV files with inventory levels, sales, and orders from the simulation.
4. **Evaluation Metrics**: JSON file with performance metrics like stockout rate, inventory turnover, etc.
5. **Visualizations**: PNG files with charts showing inventory levels, sales, stockout rates, etc.
6. **Comprehensive Report**: Markdown file summarizing the entire workflow and results.

## Key Features

1. **Real Data Integration**: Uses real retail datasets for training and simulation.
2. **Intelligent Forecasting**: Trains forecasting models on historical sales data.
3. **Optimal Inventory Management**: Calculates optimal reorder points and order quantities.
4. **Dynamic Pricing**: Estimates price elasticity and calculates optimal prices.
5. **Multi-Agent Simulation**: Simulates interactions between stores, warehouse, suppliers, and customers.
6. **Performance Evaluation**: Calculates KPIs like stockout rate, inventory turnover, and order fill rate.

## Customization

You can customize the system by modifying the following:

1. **Configuration Files**: Edit `simulation_config.json` or `scenario_config.json` to change simulation parameters.
2. **Model Parameters**: Modify the model training parameters in `train_models.py`.
3. **Agent Behavior**: Update the agent classes in the `src/agents` directory.
4. **Intelligence Modules**: Enhance the intelligence modules in the `src/models` directory.

## Troubleshooting

If you encounter issues:

1. Check the log files (`workflow.log`, `training.log`, etc.) for detailed error messages.
2. Verify that the datasets are in the correct location and format.
3. Make sure Ollama is running and the Mistral model is available.
4. Check that all dependencies are installed correctly.

## Acknowledgments

- This project was developed as part of a hackathon focused on multi-agent AI systems.
- Uses real retail datasets for training and simulation.
- Uses Ollama for on-premise LLM capabilities.
