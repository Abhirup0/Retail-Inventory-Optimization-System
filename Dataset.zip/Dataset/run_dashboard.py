import sys
import os
import asyncio
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.api.dashboard import app
import uvicorn

if __name__ == "__main__":
    # Run the dashboard standalone
    uvicorn.run(app, host="0.0.0.0", port=8000)
