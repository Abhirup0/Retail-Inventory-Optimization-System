import sys
import os
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

from src.utils.ollama_test import test_ollama_connection

if __name__ == "__main__":
    test_ollama_connection()
