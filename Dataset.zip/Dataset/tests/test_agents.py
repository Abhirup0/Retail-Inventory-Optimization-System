import sys
import os
import asyncio
import unittest
from pathlib import Path

# Add the project root directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.agents.base_agent import Agent
from src.agents.store_agent import StoreAgent
from src.agents.warehouse_agent import WarehouseAgent

class TestBaseAgent(unittest.TestCase):
    """Test cases for the base Agent class."""
    
    def test_initialization(self):
        """Test agent initialization."""
        agent = Agent(agent_id="test_agent", agent_type="test")
        self.assertEqual(agent.agent_id, "test_agent")
        self.assertEqual(agent.agent_type, "test")
        self.assertEqual(agent.state, {})
        self.assertEqual(agent.connections, [])
    
    def test_update_state(self):
        """Test updating agent state."""
        agent = Agent(agent_id="test_agent", agent_type="test")
        
        async def update_and_get():
            await agent.update_state("key1", "value1")
            return await agent.get_state("key1")
        
        result = asyncio.run(update_and_get())
        self.assertEqual(result, "value1")
    
    def test_store_and_retrieve_memory(self):
        """Test storing and retrieving agent memory."""
        agent = Agent(agent_id="test_agent", agent_type="test")
        
        async def store_and_retrieve():
            await agent.store_memory("test_memory", {"data": "test_data"})
            memories = await agent.retrieve_memories("test_memory")
            return memories
        
        memories = asyncio.run(store_and_retrieve())
        self.assertEqual(len(memories), 1)
        self.assertEqual(memories[0]["content"]["data"], "test_data")

class TestStoreAgent(unittest.TestCase):
    """Test cases for the StoreAgent class."""
    
    def test_initialization(self):
        """Test store agent initialization."""
        agent = StoreAgent(store_id=1, name="Test Store", location="Test Location")
        self.assertEqual(agent.store_id, 1)
        self.assertEqual(agent.name, "Test Store")
        self.assertEqual(agent.location, "Test Location")
        self.assertEqual(agent.agent_type, "store")
        self.assertEqual(agent.state["store_id"], 1)
        self.assertEqual(agent.state["name"], "Test Store")
        self.assertEqual(agent.state["location"], "Test Location")
    
    def test_check_inventory(self):
        """Test inventory checking functionality."""
        agent = StoreAgent(store_id=1, name="Test Store", location="Test Location")
        agent.state["inventory"] = {
            1: 0,    # Stockout
            2: 50,   # Normal
            3: 150   # Overstocked
        }
        
        async def check():
            await agent.check_inventory()
            return agent.state["stockouts"], agent.state["overstocked_items"]
        
        stockouts, overstocked = asyncio.run(check())
        self.assertIn(1, stockouts)
        self.assertIn(3, overstocked)
        self.assertNotIn(2, stockouts)
        self.assertNotIn(2, overstocked)

class TestWarehouseAgent(unittest.TestCase):
    """Test cases for the WarehouseAgent class."""
    
    def test_initialization(self):
        """Test warehouse agent initialization."""
        agent = WarehouseAgent(warehouse_id=1, name="Test Warehouse", location="Test Location")
        self.assertEqual(agent.warehouse_id, 1)
        self.assertEqual(agent.name, "Test Warehouse")
        self.assertEqual(agent.location, "Test Location")
        self.assertEqual(agent.agent_type, "warehouse")
        self.assertEqual(agent.state["warehouse_id"], 1)
        self.assertEqual(agent.state["name"], "Test Warehouse")
        self.assertEqual(agent.state["location"], "Test Location")
    
    def test_check_inventory(self):
        """Test warehouse inventory checking functionality."""
        agent = WarehouseAgent(warehouse_id=1, name="Test Warehouse", location="Test Location")
        agent.state["inventory"] = {
            1: 10,   # Low stock
            2: 50,   # Normal
            3: 5     # Low stock
        }
        
        async def check():
            await agent.check_inventory()
            # Get the memory of the inventory check
            memories = await agent.retrieve_memories("observation")
            inventory_check = next((m for m in memories if m["content"]["type"] == "warehouse_inventory_check"), None)
            return inventory_check["content"]["low_stock_items"] if inventory_check else []
        
        low_stock_items = asyncio.run(check())
        self.assertIn(1, low_stock_items)
        self.assertIn(3, low_stock_items)
        self.assertNotIn(2, low_stock_items)

if __name__ == "__main__":
    unittest.main()
